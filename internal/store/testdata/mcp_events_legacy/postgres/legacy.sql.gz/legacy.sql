--
-- PostgreSQL database dump
--

\restrict v6ZvQ0YTNkdqcGFc8g0pARCkzXZqOnmcoFf373ctyjZLtdBBS0imJ6r94MiYasE

-- Dumped from database version 16.15 (Homebrew)
-- Dumped by pg_dump version 16.15 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: advance_operation_history_membership_revision(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.advance_operation_history_membership_revision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE operation_history_state
    SET membership_revision = membership_revision + 1
    WHERE singleton = 1;
    RETURN NULL;
END;
$$;


--
-- Name: append_embedding_change(text, bigint, text, text, bigint, bigint, timestamp with time zone, timestamp with time zone, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.append_embedding_change(p_kind text, p_message_id bigint, p_old_message_type text, p_new_message_type text, p_old_conversation_id bigint, p_new_conversation_id bigint, p_old_sent_at timestamp with time zone, p_new_sent_at timestamp with time zone, p_participant_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
		 DECLARE
		     next_sequence BIGINT;
		 BEGIN
		     UPDATE embedding_change_clock
		        SET sequence = sequence + 1
		      WHERE singleton = 1 AND enabled
		      RETURNING sequence INTO next_sequence;
		     IF next_sequence IS NULL THEN
		         RETURN;
		     END IF;
		     INSERT INTO embedding_changes (
		         sequence, kind, message_id, old_message_type, new_message_type, old_conversation_id,
		         new_conversation_id, old_sent_at, new_sent_at, participant_id
		     ) VALUES (
		         next_sequence, p_kind, p_message_id,
		         p_old_message_type, p_new_message_type,
		         p_old_conversation_id, p_new_conversation_id,
		         p_old_sent_at, p_new_sent_at, p_participant_id
		     );
		 END;
		 $$;


--
-- Name: bump_document_index_revision_after_message_type_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bump_document_index_revision_after_message_type_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF OLD.message_type IS DISTINCT FROM NEW.message_type
       AND EXISTS (
           SELECT 1
           FROM document_occurrences o
           JOIN document_extraction_heads h
             ON h.canonical_blob_hash = o.canonical_blob_hash
           WHERE o.message_id = NEW.id
       ) THEN
        UPDATE document_index_state
        SET revision = revision + 1, updated_at = CURRENT_TIMESTAMP
        WHERE singleton = 1;
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: bump_document_index_revision_after_occurrence_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bump_document_index_revision_after_occurrence_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE document_index_state
    SET revision = revision + 1, updated_at = CURRENT_TIMESTAMP
    WHERE singleton = 1;
    RETURN OLD;
END;
$$;


--
-- Name: bump_message_content_changed_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bump_message_content_changed_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     UPDATE messages SET content_changed_at = clock_timestamp() WHERE id = NEW.message_id;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: bump_message_content_changed_at_del(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bump_message_content_changed_at_del() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     UPDATE messages SET content_changed_at = clock_timestamp() WHERE id = OLD.message_id;
		     RETURN OLD;
		 END;
		 $$;


--
-- Name: bump_message_last_modified(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bump_message_last_modified() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     UPDATE messages SET last_modified = CURRENT_TIMESTAMP WHERE id = NEW.message_id;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: capture_attachment_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.capture_attachment_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF NOT EXISTS (SELECT 1 FROM attachment_change_consumers) THEN
		         IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		     END IF;
		     IF TG_OP = 'INSERT' THEN
		         INSERT INTO attachment_change_log
		             (event_kind, new_message_id, new_attachment_id,
		              new_content_hash, new_source_part_key, new_role)
		         VALUES ('attachment_insert', NEW.message_id, NEW.id,
		                 NEW.content_hash, NEW.source_part_key, NEW.attachment_role);
		         RETURN NEW;
		     ELSIF TG_OP = 'UPDATE' THEN
		         INSERT INTO attachment_change_log
		             (event_kind, old_message_id, new_message_id,
		              old_attachment_id, new_attachment_id,
		              old_content_hash, new_content_hash,
		              old_source_part_key, new_source_part_key,
		              old_role, new_role)
		         VALUES ('attachment_update', OLD.message_id, NEW.message_id,
		                 OLD.id, NEW.id, OLD.content_hash, NEW.content_hash,
		                 OLD.source_part_key, NEW.source_part_key,
		                 OLD.attachment_role, NEW.attachment_role);
		         RETURN NEW;
		     ELSE
		         INSERT INTO attachment_change_log
		             (event_kind, old_message_id, old_attachment_id,
		              old_content_hash, old_source_part_key, old_role)
		         VALUES ('attachment_delete', OLD.message_id, OLD.id,
		                 OLD.content_hash, OLD.source_part_key, OLD.attachment_role);
		         RETURN OLD;
		     END IF;
		 END;
		 $$;


--
-- Name: capture_attachment_message_live_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.capture_attachment_message_live_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF NOT EXISTS (SELECT 1 FROM attachment_change_consumers) THEN
		         RETURN NEW;
		     END IF;
		     INSERT INTO attachment_change_log
		         (event_kind, old_message_id, new_message_id,
		          old_attachment_id, new_attachment_id,
		          old_content_hash, new_content_hash,
		          old_source_part_key, new_source_part_key,
		          old_role, new_role)
		     SELECT
		         CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		              THEN 'message_live_enter' ELSE 'message_live_exit' END,
		         CASE WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		              THEN OLD.id END,
		         CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		              THEN NEW.id END,
		         CASE WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		              THEN a.id END,
		         CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		              THEN a.id END,
		         CASE WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		              THEN a.content_hash END,
		         CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		              THEN a.content_hash END,
		         CASE WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		              THEN a.source_part_key END,
		         CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		              THEN a.source_part_key END,
		         CASE WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		              THEN a.attachment_role END,
		         CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		              THEN a.attachment_role END
		     FROM attachments a WHERE a.message_id = NEW.id;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: directory_projection_mark_dirty(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.directory_projection_mark_dirty() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
			BEGIN
				IF TG_OP = 'UPDATE' THEN
					INSERT INTO directory_projection_dirty(person_id)
					VALUES ((to_jsonb(OLD)->>TG_ARGV[0])::bigint), ((to_jsonb(NEW)->>TG_ARGV[0])::bigint)
					ON CONFLICT DO NOTHING;
				ELSIF TG_OP = 'DELETE' THEN
					INSERT INTO directory_projection_dirty(person_id)
					VALUES ((to_jsonb(OLD)->>TG_ARGV[0])::bigint) ON CONFLICT DO NOTHING;
				ELSE
					INSERT INTO directory_projection_dirty(person_id)
					VALUES ((to_jsonb(NEW)->>TG_ARGV[0])::bigint) ON CONFLICT DO NOTHING;
				END IF;
				RETURN NULL;
			END $$;


--
-- Name: directory_projection_mark_organization_dirty(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.directory_projection_mark_organization_dirty() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
			DECLARE organization bigint;
			BEGIN
				IF TG_OP = 'DELETE' THEN organization := OLD.id; ELSE organization := NEW.id; END IF;
				INSERT INTO directory_projection_dirty(person_id)
				SELECT person_id FROM employments WHERE organization_id = organization
				ON CONFLICT DO NOTHING;
				RETURN NULL;
			END $$;


--
-- Name: dirty_activity_direct_link_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.dirty_activity_direct_link_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF OLD.evidence = 'direct' THEN
		         UPDATE person_contact_state
		         SET dirty_at = CURRENT_TIMESTAMP
		         WHERE person_id = OLD.person_id;
		     END IF;
		     RETURN OLD;
		 END;
		 $$;


--
-- Name: enqueue_activity_projection_conversation(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enqueue_activity_projection_conversation(p_conversation_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
		 DECLARE
		     message_record RECORD;
		 BEGIN
		     FOR message_record IN
		         SELECT id FROM messages WHERE conversation_id = p_conversation_id
		     LOOP
		         PERFORM enqueue_activity_projection_message(message_record.id);
		     END LOOP;
		 END;
		 $$;


--
-- Name: enqueue_activity_projection_message(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enqueue_activity_projection_message(p_message_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF p_message_id IS NULL OR NOT EXISTS (
		         SELECT 1 FROM messages WHERE id = p_message_id
		     ) THEN
		         RETURN;
		     END IF;
		     INSERT INTO activity_projection_queue (message_id, revision, queued_at)
		     VALUES (p_message_id, 1, CURRENT_TIMESTAMP)
		     ON CONFLICT (message_id) DO UPDATE SET
		         revision = activity_projection_queue.revision + 1,
		         queued_at = CURRENT_TIMESTAMP;
		 END;
		 $$;


--
-- Name: invalidate_visual_publication_attachment(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_visual_publication_attachment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF TG_OP <> 'INSERT' THEN
		         INSERT INTO visual_obsolete_tokens (generation_id, vector_token)
		         SELECT vp.generation_id, vp.pending_vector_token FROM visual_publications vp
		         WHERE vp.pending_vector_token IS NOT NULL
		           AND vp.message_id = OLD.message_id
		           AND (vp.blob_hash = LOWER(COALESCE(OLD.content_hash, ''))
		                OR ((OLD.content_hash IS NULL OR OLD.content_hash = '')
		                    AND LOWER(OLD.storage_path) =
		                        SUBSTRING(vp.blob_hash FROM 1 FOR 2) || '/' || vp.blob_hash))
		         ON CONFLICT (generation_id, vector_token) DO NOTHING;
		         UPDATE visual_publications vp
		         SET state = CASE WHEN EXISTS (
		                 SELECT 1 FROM attachments a
		                 JOIN messages m ON m.id = a.message_id
		                 WHERE a.message_id = vp.message_id
		                   AND m.deleted_at IS NULL AND m.deleted_from_source_at IS NULL
		                   AND a.attachment_role = 'standalone'
		                   AND a.role_source IN ('mime_disposition', 'provider_explicit',
		                                         'importer_semantics', 'raw_mime_repair')
		                   AND (LOWER(COALESCE(a.content_hash, '')) = vp.blob_hash
		                        OR ((a.content_hash IS NULL OR a.content_hash = '')
		                            AND LOWER(a.storage_path) =
		                                SUBSTRING(vp.blob_hash FROM 1 FOR 2) || '/' || vp.blob_hash))
		             ) THEN 'stale' ELSE 'tombstoned' END,
		             pending_vector_token = NULL,
		             updated_at = CURRENT_TIMESTAMP
		         WHERE vp.message_id = OLD.message_id
		           AND (vp.blob_hash = LOWER(COALESCE(OLD.content_hash, ''))
		                OR ((OLD.content_hash IS NULL OR OLD.content_hash = '')
		                    AND LOWER(OLD.storage_path) =
		                        SUBSTRING(vp.blob_hash FROM 1 FOR 2) || '/' || vp.blob_hash));
		     END IF;
		     IF TG_OP <> 'DELETE'
		        AND NEW.attachment_role = 'standalone'
		        AND NEW.role_source IN ('mime_disposition', 'provider_explicit',
		                                'importer_semantics', 'raw_mime_repair')
		        AND EXISTS (SELECT 1 FROM messages m WHERE m.id = NEW.message_id
		                    AND m.deleted_at IS NULL AND m.deleted_from_source_at IS NULL) THEN
		         INSERT INTO visual_obsolete_tokens (generation_id, vector_token)
		         SELECT vp.generation_id, vp.pending_vector_token FROM visual_publications vp
		         WHERE vp.pending_vector_token IS NOT NULL
		           AND vp.message_id = NEW.message_id
		           AND (vp.blob_hash = LOWER(COALESCE(NEW.content_hash, ''))
		                OR ((NEW.content_hash IS NULL OR NEW.content_hash = '')
		                    AND LOWER(NEW.storage_path) =
		                        SUBSTRING(vp.blob_hash FROM 1 FOR 2) || '/' || vp.blob_hash))
		         ON CONFLICT (generation_id, vector_token) DO NOTHING;
		         UPDATE visual_publications vp
		         SET state = 'stale', pending_vector_token = NULL, updated_at = CURRENT_TIMESTAMP
		         WHERE vp.message_id = NEW.message_id
		           AND (vp.blob_hash = LOWER(COALESCE(NEW.content_hash, ''))
		                OR ((NEW.content_hash IS NULL OR NEW.content_hash = '')
		                    AND LOWER(NEW.storage_path) =
		                        SUBSTRING(vp.blob_hash FROM 1 FOR 2) || '/' || vp.blob_hash));
		     END IF;
		     IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		 END;
		 $$;


--
-- Name: invalidate_visual_publication_message_body(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_visual_publication_message_body() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 DECLARE target_message_id BIGINT;
		 BEGIN
		     IF TG_OP = 'DELETE' THEN
		         target_message_id := OLD.message_id;
		     ELSE
		         target_message_id := NEW.message_id;
		     END IF;
		     INSERT INTO visual_obsolete_tokens (generation_id, vector_token)
		     SELECT generation_id, pending_vector_token FROM visual_publications
		     WHERE pending_vector_token IS NOT NULL AND message_id = target_message_id
		     ON CONFLICT (generation_id, vector_token) DO NOTHING;
		     UPDATE visual_publications
		     SET state = CASE WHEN state = 'current' THEN 'stale' ELSE state END,
		         prepared_revision = NULL, outcome_kind = NULL, outcome_reason = NULL,
		         pending_vector_token = NULL,
		         updated_at = CURRENT_TIMESTAMP
		     WHERE message_id = target_message_id AND state <> 'tombstoned'
		       AND (state = 'current' OR prepared_revision IS NOT NULL
		            OR pending_vector_token IS NOT NULL OR outcome_kind IS NOT NULL);
		     IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		 END;
		 $$;


--
-- Name: invalidate_visual_publication_message_content(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_visual_publication_message_content() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     INSERT INTO visual_obsolete_tokens (generation_id, vector_token)
		     SELECT generation_id, pending_vector_token FROM visual_publications
		     WHERE pending_vector_token IS NOT NULL AND message_id = NEW.id
		     ON CONFLICT (generation_id, vector_token) DO NOTHING;
		     UPDATE visual_publications
		     SET state = CASE WHEN state = 'current' THEN 'stale' ELSE state END,
		         prepared_revision = NULL, outcome_kind = NULL, outcome_reason = NULL,
		         pending_vector_token = NULL,
		         updated_at = CURRENT_TIMESTAMP
		     WHERE message_id = NEW.id AND state <> 'tombstoned'
		       AND (state = 'current' OR prepared_revision IS NOT NULL
		            OR pending_vector_token IS NOT NULL OR outcome_kind IS NOT NULL);
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: invalidate_visual_publication_message_live(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.invalidate_visual_publication_message_live() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     INSERT INTO visual_obsolete_tokens (generation_id, vector_token)
		     SELECT generation_id, pending_vector_token FROM visual_publications
		     WHERE pending_vector_token IS NOT NULL AND message_id = NEW.id
		     ON CONFLICT (generation_id, vector_token) DO NOTHING;
		     UPDATE visual_publications
		     SET state = CASE WHEN NEW.deleted_at IS NULL
		                               AND NEW.deleted_from_source_at IS NULL
		                          THEN 'stale' ELSE 'tombstoned' END,
		         pending_vector_token = NULL,
		         updated_at = CURRENT_TIMESTAMP
		     WHERE message_id = NEW.id;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: journal_beeper_conversation_title(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.journal_beeper_conversation_title() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF OLD.title IS DISTINCT FROM NEW.title
		        AND EXISTS (
		            SELECT 1 FROM messages m
		            JOIN message_bodies mb ON mb.message_id = m.id
		             WHERE m.conversation_id = NEW.id
		               AND m.message_type = 'beeper'
		               AND m.deleted_at IS NULL
		               AND m.deleted_from_source_at IS NULL
		        ) THEN
		         PERFORM append_embedding_change(
		             'conversation_title', NULL, NULL, NULL,
		             OLD.id, NEW.id, NULL, NULL, NULL);
		     END IF;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: journal_beeper_membership_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.journal_beeper_membership_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 DECLARE
		     old_conversation BIGINT;
		     new_conversation BIGINT;
		     change_participant BIGINT;
		     affects_context BOOLEAN;
		 BEGIN
		     IF TG_OP = 'INSERT' THEN
		         old_conversation := NEW.conversation_id;
		         new_conversation := NEW.conversation_id;
		         change_participant := NEW.participant_id;
		     ELSIF TG_OP = 'DELETE' THEN
		         old_conversation := OLD.conversation_id;
		         new_conversation := OLD.conversation_id;
		         change_participant := OLD.participant_id;
		     ELSE
		         IF OLD.conversation_id IS NOT DISTINCT FROM NEW.conversation_id
		            AND OLD.participant_id IS NOT DISTINCT FROM NEW.participant_id
		            AND OLD.role IS NOT DISTINCT FROM NEW.role
		            AND OLD.joined_at IS NOT DISTINCT FROM NEW.joined_at
		            AND OLD.left_at IS NOT DISTINCT FROM NEW.left_at THEN
		             RETURN NEW;
		         END IF;
		         old_conversation := OLD.conversation_id;
		         new_conversation := NEW.conversation_id;
		         change_participant := NEW.participant_id;
		     END IF;
		     SELECT EXISTS (
		         SELECT 1 FROM messages m
		         JOIN message_bodies mb ON mb.message_id = m.id
		          WHERE m.conversation_id IN (old_conversation, new_conversation)
		            AND m.message_type = 'beeper'
		            AND m.deleted_at IS NULL
		     ) INTO affects_context;
		     IF affects_context THEN
		         PERFORM append_embedding_change(
		             'conversation_participant', NULL, NULL, NULL,
		             old_conversation, new_conversation,
		             NULL, NULL, change_participant);
		     END IF;
		     IF TG_OP = 'DELETE' THEN
		         RETURN OLD;
		     END IF;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: journal_beeper_participant_display_name(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.journal_beeper_participant_display_name() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF COALESCE(NULLIF(TRIM(OLD.display_name), ''),
		                 NULLIF(OLD.email_address, ''), NULLIF(OLD.phone_number, ''), '')
		        IS DISTINCT FROM COALESCE(NULLIF(TRIM(NEW.display_name), ''),
		                                  NULLIF(NEW.email_address, ''), NULLIF(NEW.phone_number, ''), '')
		        AND (
		            EXISTS (
		                SELECT 1
		                  FROM conversation_participants cp
		                  JOIN messages m ON m.conversation_id = cp.conversation_id
		                  JOIN message_bodies mb ON mb.message_id = m.id
		                 WHERE cp.participant_id = NEW.id
		                   AND m.message_type = 'beeper'
		                   AND m.deleted_at IS NULL
		            ) OR EXISTS (
		                SELECT 1
		                  FROM messages m
		                  JOIN message_bodies mb ON mb.message_id = m.id
		                 WHERE m.sender_id = NEW.id
		                   AND m.message_type = 'beeper'
		                   AND m.deleted_at IS NULL
		            )
		        ) THEN
		         PERFORM append_embedding_change(
		             'participant_display_name', NULL, NULL, NULL,
		             NULL, NULL, NULL, NULL, NEW.id);
		     END IF;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: journal_contextual_body_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.journal_contextual_body_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 DECLARE
		     change_message_id BIGINT;
		     change_message_type TEXT;
		     change_conversation_id BIGINT;
		     change_sent_at TIMESTAMPTZ;
		     body_message_id BIGINT;
		 BEGIN
		     IF TG_OP = 'DELETE' THEN
		         body_message_id := OLD.message_id;
		     ELSE
		         body_message_id := NEW.message_id;
		     END IF;
		     IF TG_OP = 'UPDATE'
		        AND OLD.body_text IS NOT DISTINCT FROM NEW.body_text
		        AND OLD.body_html IS NOT DISTINCT FROM NEW.body_html THEN
		         RETURN NEW;
		     END IF;
		     SELECT id, message_type, conversation_id, COALESCE(sent_at, received_at, internal_date)
		       INTO change_message_id, change_message_type, change_conversation_id, change_sent_at
		       FROM messages
		      WHERE id = body_message_id
		        AND deleted_at IS NULL
		        AND deleted_from_source_at IS NULL;
		     IF FOUND THEN
		         IF TG_OP = 'INSERT' THEN
		             PERFORM append_embedding_change(
		                 'message_insert', change_message_id, NULL, change_message_type,
		                 NULL, change_conversation_id,
		                 NULL, change_sent_at, NULL);
		         ELSIF TG_OP = 'DELETE' THEN
		             PERFORM append_embedding_change(
		                 'message_body', change_message_id, change_message_type, NULL,
		                 change_conversation_id, NULL,
		                 change_sent_at, NULL, NULL);
		         ELSE
		             PERFORM append_embedding_change(
		                 'message_body', change_message_id, change_message_type, change_message_type,
		                 change_conversation_id, change_conversation_id,
		                 change_sent_at, change_sent_at, NULL);
		         END IF;
		     END IF;
		     IF TG_OP = 'DELETE' THEN
		         RETURN OLD;
		     END IF;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: journal_contextual_message_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.journal_contextual_message_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF TG_OP = 'DELETE' THEN
		         IF OLD.deleted_at IS NULL
		            AND OLD.deleted_from_source_at IS NULL
		            AND (
		                COALESCE(OLD.message_type, '') NOT IN ('beeper', 'meeting_transcript')
		                OR EXISTS (SELECT 1 FROM message_bodies WHERE message_id = OLD.id)
		            ) THEN
		             PERFORM append_embedding_change(
		                 'message_delete', OLD.id, OLD.message_type, NULL,
		                 OLD.conversation_id, NULL,
		                 COALESCE(OLD.sent_at, OLD.received_at, OLD.internal_date), NULL, NULL);
		         END IF;
		         RETURN OLD;
		     END IF;

		     IF (EXISTS (
		         SELECT 1 FROM message_bodies WHERE message_id = NEW.id
		     ) AND (
		         (
		             (
		                 (OLD.message_type IN ('beeper', 'meeting_transcript') AND OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL)
		                 OR (NEW.message_type IN ('beeper', 'meeting_transcript') AND NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL)
		                 OR (
		                     OLD.message_type IS DISTINCT FROM NEW.message_type
		                     AND (
		                         (OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL)
		                         OR (NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL)
		                     )
		                 )
		             ) AND (
		                 OLD.message_type IS DISTINCT FROM NEW.message_type
		                 OR OLD.conversation_id IS DISTINCT FROM NEW.conversation_id
		                 OR OLD.sent_at IS DISTINCT FROM NEW.sent_at
		                 OR OLD.received_at IS DISTINCT FROM NEW.received_at
		                 OR OLD.internal_date IS DISTINCT FROM NEW.internal_date
		                 OR OLD.sender_id IS DISTINCT FROM NEW.sender_id
		                 OR OLD.deleted_at IS DISTINCT FROM NEW.deleted_at
		                 OR OLD.deleted_from_source_at IS DISTINCT FROM NEW.deleted_from_source_at
		             )
		         ) OR (
		             COALESCE(OLD.message_type, '') NOT IN ('beeper', 'meeting_transcript')
		             AND COALESCE(NEW.message_type, '') NOT IN ('beeper', 'meeting_transcript')
		             AND (
		                 (OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL)
		                 OR (NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL)
		             ) AND (
		                 OLD.message_type IS DISTINCT FROM NEW.message_type
		                 OR OLD.conversation_id IS DISTINCT FROM NEW.conversation_id
		                 OR OLD.subject IS DISTINCT FROM NEW.subject
		                 OR OLD.deleted_at IS DISTINCT FROM NEW.deleted_at
		                 OR OLD.deleted_from_source_at IS DISTINCT FROM NEW.deleted_from_source_at
		             )
		         )
		     )) OR (
		         OLD.message_type IS DISTINCT FROM NEW.message_type
		         AND (
		             (OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL)
		             OR (NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL)
		         )
		     ) OR (
		         COALESCE(OLD.message_type, '') NOT IN ('beeper', 'meeting_transcript')
		         AND COALESCE(NEW.message_type, '') NOT IN ('beeper', 'meeting_transcript')
		         AND (
		             OLD.deleted_at IS DISTINCT FROM NEW.deleted_at
		             OR OLD.deleted_from_source_at IS DISTINCT FROM NEW.deleted_from_source_at
		         )
		     ) OR (
		         OLD.embed_gen IS NOT NULL
		         AND NEW.embed_gen IS NULL
		         AND COALESCE(NEW.message_type, '') NOT IN ('beeper', 'meeting_transcript')
		         AND NEW.deleted_at IS NULL
		         AND NEW.deleted_from_source_at IS NULL
		         AND NOT EXISTS (SELECT 1 FROM message_bodies WHERE message_id = NEW.id)
		     ) THEN
		         PERFORM append_embedding_change(
		             'message_update', NEW.id,
		             CASE WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		                  THEN OLD.message_type END,
		             CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		                  THEN NEW.message_type END,
		             CASE WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		                  THEN OLD.conversation_id END,
		             CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		                  THEN NEW.conversation_id END,
		             CASE WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		                  THEN COALESCE(OLD.sent_at, OLD.received_at, OLD.internal_date) END,
		             CASE WHEN NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		                  THEN COALESCE(NEW.sent_at, NEW.received_at, NEW.internal_date) END,
		             NULL);
		     END IF;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: ledger_visual_publication_tokens(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ledger_visual_publication_tokens() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF OLD.current_vector_token IS NOT NULL THEN
		         INSERT INTO visual_obsolete_tokens (generation_id, vector_token)
		         VALUES (OLD.generation_id, OLD.current_vector_token)
		         ON CONFLICT (generation_id, vector_token) DO NOTHING;
		     END IF;
		     IF OLD.pending_vector_token IS NOT NULL THEN
		         INSERT INTO visual_obsolete_tokens (generation_id, vector_token)
		         VALUES (OLD.generation_id, OLD.pending_vector_token)
		         ON CONFLICT (generation_id, vector_token) DO NOTHING;
		     END IF;
		     RETURN OLD;
		 END;
		 $$;


--
-- Name: lock_embedding_change_clock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.lock_embedding_change_clock() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     PERFORM pg_advisory_xact_lock_shared(
		         hashtextextended('msgvault.embedding_change_clock', 0));
		     RETURN NULL;
		 END;
		 $$;


--
-- Name: msgvault_append_person_sweep_change(bigint, text, text, text, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_append_person_sweep_change(_person_id bigint, _source_lane text, _change_kind text, _evidence_effect text, _source_id bigint, _message_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
		 DECLARE next_sequence BIGINT;
		 BEGIN
		     UPDATE person_sweep_change_clock
		        SET sequence = sequence + 1
		      WHERE singleton = TRUE AND enabled = TRUE
		      RETURNING sequence INTO next_sequence;
		     IF next_sequence IS NOT NULL THEN
		         INSERT INTO person_sweep_changes
		             (sequence, person_id, source_lane, change_kind,
		              evidence_effect, source_id, message_id, recorded_at)
		         VALUES (next_sequence, _person_id, _source_lane, _change_kind,
		                 _evidence_effect, _source_id, _message_id, CURRENT_TIMESTAMP);
		     END IF;
		 END;
		 $$;


--
-- Name: msgvault_append_person_sweep_document_changes(bigint, bigint, bigint, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_append_person_sweep_document_changes(_person_id bigint, _source_id bigint, _message_id bigint, _change_kind text, _evidence_effect text) RETURNS void
    LANGUAGE plpgsql
    AS $$
		 DECLARE occurrence RECORD;
		 DECLARE next_sequence BIGINT;
		 BEGIN
		     FOR occurrence IN
		         SELECT source_id, attachment_id, occurrence_key
		           FROM document_occurrences
		          WHERE message_id = _message_id
		          ORDER BY attachment_id, occurrence_key
		     LOOP
		         next_sequence := NULL;
		         UPDATE person_sweep_change_clock
		            SET sequence = sequence + 1
		          WHERE singleton = TRUE AND enabled = TRUE
		          RETURNING sequence INTO next_sequence;
		         IF next_sequence IS NOT NULL THEN
		             INSERT INTO person_sweep_changes
		                 (sequence, person_id, source_lane, change_kind,
		                  evidence_effect, source_id, message_id, attachment_id,
		                  occurrence_key, recorded_at)
		             VALUES (next_sequence, _person_id, 'document_text', _change_kind,
		                     _evidence_effect, occurrence.source_id, _message_id,
		                     occurrence.attachment_id, occurrence.occurrence_key,
		                     CURRENT_TIMESTAMP);
		         END IF;
		     END LOOP;
		 END;
		 $$;


--
-- Name: msgvault_person_sweep_binding_scope(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_binding_scope(_person_id bigint, _participant_id bigint) RETURNS TABLE(person_id bigint, source_lane text, source_id bigint, message_id bigint)
    LANGUAGE sql STABLE
    AS $$
		     SELECT _person_id,
		            CASE WHEN m.message_type = 'meeting_transcript'
		                 THEN 'meeting_text' ELSE 'conversation_text' END,
		            m.source_id, m.id
		       FROM messages m
		       JOIN person_tracking pt ON pt.person_id = _person_id
		      WHERE m.deleted_at IS NULL AND m.deleted_from_source_at IS NULL
		        AND (m.sender_id = _participant_id
		             OR EXISTS (SELECT 1 FROM message_recipients mr
		                         WHERE mr.message_id = m.id
		                           AND mr.participant_id = _participant_id
		                           AND LOWER(mr.recipient_type) IN ('from', 'to', 'cc', 'bcc'))
		             OR EXISTS (SELECT 1 FROM conversations c
		                         JOIN conversation_participants cp
		                           ON cp.conversation_id = c.id
		                         WHERE c.id = m.conversation_id
		                           AND (
		(LOWER(COALESCE(c.conversation_type, '')) = 'direct_chat'
		 AND (m.is_from_me = TRUE OR m.sender_id IS NOT NULL OR EXISTS (
		SELECT 1 FROM message_recipients known_from
		WHERE known_from.message_id = m.id
		  AND LOWER(known_from.recipient_type) = 'from'))
		 AND NOT EXISTS (
			 SELECT 1 FROM person_participants sender_person
			 WHERE sender_person.person_id = _person_id
			   AND (sender_person.participant_id = m.sender_id OR (
				 m.sender_id IS NULL AND EXISTS (
					 SELECT 1 FROM message_recipients scoped_sender
					 WHERE scoped_sender.message_id = m.id
					   AND LOWER(scoped_sender.recipient_type) = 'from'
					   AND scoped_sender.participant_id = sender_person.participant_id)))))
		OR (LOWER(COALESCE(c.conversation_type, '')) <> 'direct_chat' OR NOT (m.is_from_me = TRUE OR m.sender_id IS NOT NULL OR EXISTS (
		SELECT 1 FROM message_recipients known_from
		WHERE known_from.message_id = m.id
		  AND LOWER(known_from.recipient_type) = 'from'))))
		                           AND cp.participant_id = _participant_id))
		 $$;


--
-- Name: msgvault_person_sweep_changes_bindings(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_changes_bindings() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 DECLARE affected RECORD;
		 BEGIN
		     IF NOT EXISTS (SELECT 1 FROM person_tracking) THEN
		         IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		     END IF;
		     IF TG_OP = 'INSERT' THEN
		         FOR affected IN SELECT * FROM msgvault_person_sweep_binding_scope(
		             NEW.person_id, NEW.participant_id) LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, 'scope', 'scope-relinked', affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, 'scope', 'scope-relinked');
		         END LOOP;
		     ELSIF TG_OP = 'DELETE' THEN
		         FOR affected IN SELECT * FROM msgvault_person_sweep_binding_scope(
		             OLD.person_id, OLD.participant_id) LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, 'scope', 'scope-unlinked', affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, 'scope', 'scope-unlinked');
		         END LOOP;
		     ELSIF OLD.person_id IS DISTINCT FROM NEW.person_id
		        OR OLD.participant_id IS DISTINCT FROM NEW.participant_id THEN
		         FOR affected IN
		             SELECT * FROM msgvault_person_sweep_binding_scope(OLD.person_id, OLD.participant_id)
		             UNION
		             SELECT * FROM msgvault_person_sweep_binding_scope(NEW.person_id, NEW.participant_id)
		         LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, 'scope', 'identity-reassigned', affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, 'scope', 'identity-reassigned');
		         END LOOP;
		     END IF;
		     IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		 END;
		 $$;


--
-- Name: msgvault_person_sweep_changes_bodies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_changes_bodies() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 DECLARE affected RECORD;
		 DECLARE target_message_id BIGINT;
		 BEGIN
		     IF NOT EXISTS (SELECT 1 FROM person_tracking) THEN
		         IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		     END IF;
		     target_message_id := CASE WHEN TG_OP = 'DELETE' THEN OLD.message_id ELSE NEW.message_id END;
		     IF TG_OP <> 'UPDATE' OR OLD.body_text IS DISTINCT FROM NEW.body_text
		                           OR OLD.body_html IS DISTINCT FROM NEW.body_html THEN
		         FOR affected IN
		             SELECT scope.* FROM messages m
		             CROSS JOIN LATERAL msgvault_person_sweep_message_scope(
		                 m.id, m.conversation_id, m.sender_id, m.is_from_me,
		                 m.message_type, m.source_id) scope
		             WHERE m.id = target_message_id AND m.deleted_at IS NULL
		               AND m.deleted_from_source_at IS NULL
		         LOOP
		             PERFORM msgvault_append_person_sweep_change(
		                 affected.person_id, affected.source_lane, 'upsert',
		                 CASE WHEN TG_OP = 'INSERT' THEN '' ELSE 'source-edited' END,
		                 affected.source_id, affected.message_id);
		         END LOOP;
		     END IF;
		     IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		 END;
		 $$;


--
-- Name: msgvault_person_sweep_changes_messages(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_changes_messages() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 DECLARE affected RECORD;
		 DECLARE kind TEXT;
		 DECLARE effect TEXT;
		 BEGIN
		     IF NOT EXISTS (SELECT 1 FROM person_tracking) THEN
		         IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		     END IF;
		     IF TG_OP = 'INSERT' THEN
		         IF NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL THEN
		             FOR affected IN SELECT * FROM msgvault_person_sweep_message_scope(
		                 NEW.id, NEW.conversation_id, NEW.sender_id, NEW.is_from_me,
		                 NEW.message_type, NEW.source_id)
		             LOOP
		                 PERFORM msgvault_append_person_sweep_change(
		                     affected.person_id, affected.source_lane, 'upsert', '',
		                     affected.source_id, affected.message_id);
		             END LOOP;
		         END IF;
		     ELSIF TG_OP = 'DELETE' THEN
		         IF OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL THEN
		             FOR affected IN SELECT * FROM msgvault_person_sweep_message_scope(
		                 OLD.id, OLD.conversation_id, OLD.sender_id, OLD.is_from_me,
		                 OLD.message_type, OLD.source_id)
		             LOOP
			         PERFORM msgvault_append_person_sweep_change(
			             affected.person_id, affected.source_lane, 'delete', 'source-deleted',
			             affected.source_id, affected.message_id);
			         PERFORM msgvault_append_person_sweep_document_changes(
			             affected.person_id, affected.source_id, affected.message_id,
			             'delete', 'source-deleted');
		             END LOOP;
		         END IF;
		     ELSE
		         kind := CASE
		             WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		                  AND (NEW.deleted_at IS NOT NULL OR NEW.deleted_from_source_at IS NOT NULL)
		                 THEN 'delete'
		             WHEN OLD.sender_id IS DISTINCT FROM NEW.sender_id
		               OR OLD.conversation_id IS DISTINCT FROM NEW.conversation_id THEN 'scope'
		             ELSE 'upsert' END;
		         effect := CASE
		             WHEN OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		                  AND (NEW.deleted_at IS NOT NULL OR NEW.deleted_from_source_at IS NOT NULL)
		                 THEN 'source-deleted'
		             WHEN (OLD.deleted_at IS NOT NULL OR OLD.deleted_from_source_at IS NOT NULL)
		                  AND NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		                 THEN 'source-reimported'
		             WHEN OLD.sender_id IS DISTINCT FROM NEW.sender_id
		               OR OLD.conversation_id IS DISTINCT FROM NEW.conversation_id THEN 'identity-reassigned'
		             ELSE 'source-edited' END;
		         FOR affected IN
		             SELECT * FROM msgvault_person_sweep_message_scope(
		                 OLD.id, OLD.conversation_id, OLD.sender_id, OLD.is_from_me,
		                 OLD.message_type, OLD.source_id)
		              WHERE OLD.deleted_at IS NULL AND OLD.deleted_from_source_at IS NULL
		             UNION
		             SELECT * FROM msgvault_person_sweep_message_scope(
		                 NEW.id, NEW.conversation_id, NEW.sender_id, NEW.is_from_me,
		                 NEW.message_type, NEW.source_id)
		              WHERE NEW.deleted_at IS NULL AND NEW.deleted_from_source_at IS NULL
		         LOOP
			     PERFORM msgvault_append_person_sweep_change(
			         affected.person_id, affected.source_lane, kind, effect,
			         affected.source_id, affected.message_id);
			     IF OLD.sender_id IS DISTINCT FROM NEW.sender_id
			        OR OLD.conversation_id IS DISTINCT FROM NEW.conversation_id
			        OR OLD.deleted_at IS DISTINCT FROM NEW.deleted_at
			        OR OLD.deleted_from_source_at IS DISTINCT FROM NEW.deleted_from_source_at THEN
			         PERFORM msgvault_append_person_sweep_document_changes(
			             affected.person_id, affected.source_id, affected.message_id,
			             kind, effect);
			     END IF;
		         END LOOP;
		     END IF;
		     IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		 END;
		 $$;


--
-- Name: msgvault_person_sweep_changes_recipients(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_changes_recipients() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 DECLARE affected RECORD;
		 BEGIN
		     IF NOT EXISTS (SELECT 1 FROM person_tracking) THEN
		         IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		     END IF;
		     IF TG_OP = 'INSERT' AND LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc') THEN
		         FOR affected IN SELECT * FROM msgvault_person_sweep_participant_message_scope(
		             NEW.message_id, NEW.participant_id) LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, 'scope', 'scope-relinked', affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, 'scope', 'scope-relinked');
		         END LOOP;
		     ELSIF TG_OP = 'DELETE' AND LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc') THEN
		         FOR affected IN SELECT * FROM msgvault_person_sweep_participant_message_scope(
		             OLD.message_id, OLD.participant_id) LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, 'scope', 'scope-unlinked', affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, 'scope', 'scope-unlinked');
		         END LOOP;
		     ELSIF TG_OP = 'UPDATE' AND (
		        OLD.message_id IS DISTINCT FROM NEW.message_id
		        OR OLD.participant_id IS DISTINCT FROM NEW.participant_id) THEN
		         FOR affected IN
		             SELECT * FROM msgvault_person_sweep_participant_message_scope(OLD.message_id, OLD.participant_id)
		              WHERE LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc')
		             UNION
		             SELECT * FROM msgvault_person_sweep_participant_message_scope(NEW.message_id, NEW.participant_id)
		              WHERE LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc')
		         LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, 'scope', 'identity-reassigned',
			         affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, 'scope', 'identity-reassigned');
		         END LOOP;
		     ELSIF TG_OP = 'UPDATE' AND OLD.recipient_type IS DISTINCT FROM NEW.recipient_type THEN
		         FOR affected IN
		             SELECT * FROM msgvault_person_sweep_participant_message_scope(OLD.message_id, OLD.participant_id)
		              WHERE LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc')
		             UNION
		             SELECT * FROM msgvault_person_sweep_participant_message_scope(NEW.message_id, NEW.participant_id)
		              WHERE LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc')
		         LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, CASE WHEN (COALESCE(LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) = (COALESCE(LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) THEN 'upsert' ELSE 'scope' END, CASE WHEN NOT (COALESCE(LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) AND (COALESCE(LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) THEN 'scope-relinked'
		WHEN (COALESCE(LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) AND NOT (COALESCE(LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) THEN 'scope-unlinked'
		ELSE 'source-edited' END, affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, CASE WHEN (COALESCE(LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) = (COALESCE(LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) THEN 'upsert' ELSE 'scope' END, CASE WHEN NOT (COALESCE(LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) AND (COALESCE(LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) THEN 'scope-relinked'
		WHEN (COALESCE(LOWER(OLD.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) AND NOT (COALESCE(LOWER(NEW.recipient_type) IN ('from', 'to', 'cc', 'bcc'), FALSE)) THEN 'scope-unlinked'
		ELSE 'source-edited' END);
		         END LOOP;
		     END IF;
		     IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		 END;
		 $$;


--
-- Name: msgvault_person_sweep_changes_roster(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_changes_roster() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 DECLARE affected RECORD;
		 BEGIN
		     IF NOT EXISTS (SELECT 1 FROM person_tracking) THEN
		         IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		     END IF;
		     IF TG_OP = 'INSERT' THEN
		         FOR affected IN SELECT * FROM msgvault_person_sweep_roster_scope(
		             NEW.conversation_id, NEW.participant_id) LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, 'scope', 'scope-relinked', affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, 'scope', 'scope-relinked');
		         END LOOP;
		     ELSIF TG_OP = 'DELETE' THEN
		         FOR affected IN SELECT * FROM msgvault_person_sweep_roster_scope(
		             OLD.conversation_id, OLD.participant_id) LOOP
			     PERFORM msgvault_append_person_sweep_change(affected.person_id,
			         affected.source_lane, 'scope', 'scope-unlinked', affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id, 'scope', 'scope-unlinked');
		         END LOOP;
		     ELSIF OLD.conversation_id IS DISTINCT FROM NEW.conversation_id
		        OR OLD.participant_id IS DISTINCT FROM NEW.participant_id
		        OR OLD.role IS DISTINCT FROM NEW.role OR OLD.joined_at IS DISTINCT FROM NEW.joined_at
		        OR OLD.left_at IS DISTINCT FROM NEW.left_at THEN
		         FOR affected IN
		             SELECT * FROM msgvault_person_sweep_roster_scope(OLD.conversation_id, OLD.participant_id)
		             UNION
		             SELECT * FROM msgvault_person_sweep_roster_scope(NEW.conversation_id, NEW.participant_id)
		         LOOP
		             PERFORM msgvault_append_person_sweep_change(affected.person_id,
		                 affected.source_lane,
		                 CASE WHEN OLD.conversation_id IS DISTINCT FROM NEW.conversation_id
		                            OR OLD.participant_id IS DISTINCT FROM NEW.participant_id
		                      THEN 'scope' ELSE 'upsert' END,
		                 CASE WHEN OLD.conversation_id IS DISTINCT FROM NEW.conversation_id
		                            OR OLD.participant_id IS DISTINCT FROM NEW.participant_id
		                      THEN 'identity-reassigned' ELSE 'source-edited' END,
			         affected.source_id, affected.message_id);
			     PERFORM msgvault_append_person_sweep_document_changes(affected.person_id,
			         affected.source_id, affected.message_id,
			         CASE WHEN OLD.conversation_id IS DISTINCT FROM NEW.conversation_id
			                    OR OLD.participant_id IS DISTINCT FROM NEW.participant_id
			              THEN 'scope' ELSE 'upsert' END,
			         CASE WHEN OLD.conversation_id IS DISTINCT FROM NEW.conversation_id
			                    OR OLD.participant_id IS DISTINCT FROM NEW.participant_id
			              THEN 'identity-reassigned' ELSE 'source-edited' END);
		         END LOOP;
		     END IF;
		     IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
		 END;
		 $$;


--
-- Name: msgvault_person_sweep_message_scope(bigint, bigint, bigint, boolean, text, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_message_scope(_message_id bigint, _conversation_id bigint, _sender_id bigint, _is_from_me boolean, _message_type text, _source_id bigint) RETURNS TABLE(person_id bigint, source_lane text, source_id bigint, message_id bigint)
    LANGUAGE sql STABLE
    AS $$
		     SELECT pp.person_id,
		            CASE WHEN _message_type = 'meeting_transcript'
		                 THEN 'meeting_text' ELSE 'conversation_text' END,
		            _source_id, _message_id
		       FROM person_participants pp
		       JOIN person_tracking pt ON pt.person_id = pp.person_id
		      WHERE pp.participant_id = _sender_id
		     UNION
		     SELECT pp.person_id,
		            CASE WHEN _message_type = 'meeting_transcript'
		                 THEN 'meeting_text' ELSE 'conversation_text' END,
		            _source_id, _message_id
		       FROM message_recipients mr
		       JOIN person_participants pp ON pp.participant_id = mr.participant_id
		       JOIN person_tracking pt ON pt.person_id = pp.person_id
		      WHERE mr.message_id = _message_id AND LOWER(mr.recipient_type) IN ('from', 'to', 'cc', 'bcc')
		     UNION
		     SELECT pp.person_id,
		            CASE WHEN _message_type = 'meeting_transcript'
		                 THEN 'meeting_text' ELSE 'conversation_text' END,
		            _source_id, _message_id
		       FROM conversations c
		       JOIN conversation_participants cp ON cp.conversation_id = c.id
		       JOIN person_participants pp ON pp.participant_id = cp.participant_id
		       JOIN person_tracking pt ON pt.person_id = pp.person_id
		      WHERE c.id = _conversation_id AND (
		(LOWER(COALESCE(c.conversation_type, '')) = 'direct_chat'
		 AND (_is_from_me = TRUE OR _sender_id IS NOT NULL OR EXISTS (
		SELECT 1 FROM message_recipients known_from
		WHERE known_from.message_id = _message_id
		  AND LOWER(known_from.recipient_type) = 'from'))
		 AND NOT EXISTS (
			 SELECT 1 FROM person_participants sender_person
			 WHERE sender_person.person_id = pp.person_id
			   AND (sender_person.participant_id = _sender_id OR (
				 _sender_id IS NULL AND EXISTS (
					 SELECT 1 FROM message_recipients scoped_sender
					 WHERE scoped_sender.message_id = _message_id
					   AND LOWER(scoped_sender.recipient_type) = 'from'
					   AND scoped_sender.participant_id = sender_person.participant_id)))))
		OR (LOWER(COALESCE(c.conversation_type, '')) <> 'direct_chat' OR NOT (_is_from_me = TRUE OR _sender_id IS NOT NULL OR EXISTS (
		SELECT 1 FROM message_recipients known_from
		WHERE known_from.message_id = _message_id
		  AND LOWER(known_from.recipient_type) = 'from'))))
		 $$;


--
-- Name: msgvault_person_sweep_participant_message_scope(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_participant_message_scope(_message_id bigint, _participant_id bigint) RETURNS TABLE(person_id bigint, source_lane text, source_id bigint, message_id bigint)
    LANGUAGE sql STABLE
    AS $$
		     SELECT pp.person_id,
		            CASE WHEN m.message_type = 'meeting_transcript'
		                 THEN 'meeting_text' ELSE 'conversation_text' END,
		            m.source_id, m.id
		       FROM messages m
		       JOIN person_participants pp ON pp.participant_id = _participant_id
		       JOIN person_tracking pt ON pt.person_id = pp.person_id
		      WHERE m.id = _message_id AND m.deleted_at IS NULL
		        AND m.deleted_from_source_at IS NULL
		 $$;


--
-- Name: msgvault_person_sweep_roster_scope(bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.msgvault_person_sweep_roster_scope(_conversation_id bigint, _participant_id bigint) RETURNS TABLE(person_id bigint, source_lane text, source_id bigint, message_id bigint)
    LANGUAGE sql STABLE
    AS $$
		     SELECT pp.person_id,
		            CASE WHEN m.message_type = 'meeting_transcript'
		                 THEN 'meeting_text' ELSE 'conversation_text' END,
		            m.source_id, m.id
		       FROM conversations c
		       JOIN messages m ON m.conversation_id = c.id
		       JOIN person_participants pp ON pp.participant_id = _participant_id
		       JOIN person_tracking pt ON pt.person_id = pp.person_id
		      WHERE c.id = _conversation_id AND (
		(LOWER(COALESCE(c.conversation_type, '')) = 'direct_chat'
		 AND (m.is_from_me = TRUE OR m.sender_id IS NOT NULL OR EXISTS (
		SELECT 1 FROM message_recipients known_from
		WHERE known_from.message_id = m.id
		  AND LOWER(known_from.recipient_type) = 'from'))
		 AND NOT EXISTS (
			 SELECT 1 FROM person_participants sender_person
			 WHERE sender_person.person_id = pp.person_id
			   AND (sender_person.participant_id = m.sender_id OR (
				 m.sender_id IS NULL AND EXISTS (
					 SELECT 1 FROM message_recipients scoped_sender
					 WHERE scoped_sender.message_id = m.id
					   AND LOWER(scoped_sender.recipient_type) = 'from'
					   AND scoped_sender.participant_id = sender_person.participant_id)))))
		OR (LOWER(COALESCE(c.conversation_type, '')) <> 'direct_chat' OR NOT (m.is_from_me = TRUE OR m.sender_id IS NOT NULL OR EXISTS (
		SELECT 1 FROM message_recipients known_from
		WHERE known_from.message_id = m.id
		  AND LOWER(known_from.recipient_type) = 'from'))))
		        AND m.deleted_at IS NULL AND m.deleted_from_source_at IS NULL
		 $$;


--
-- Name: queue_activity_conversation_people_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_activity_conversation_people_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     PERFORM enqueue_activity_projection_conversation(OLD.conversation_id);
		     RETURN OLD;
		 END;
		 $$;


--
-- Name: queue_activity_conversation_people_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_activity_conversation_people_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     PERFORM enqueue_activity_projection_conversation(NEW.conversation_id);
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: queue_activity_conversation_people_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_activity_conversation_people_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     PERFORM enqueue_activity_projection_conversation(OLD.conversation_id);
		     PERFORM enqueue_activity_projection_conversation(NEW.conversation_id);
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: queue_activity_conversation_type_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_activity_conversation_type_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF OLD.conversation_type IS DISTINCT FROM NEW.conversation_type THEN
		         PERFORM enqueue_activity_projection_conversation(NEW.id);
		     END IF;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: queue_activity_messages(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_activity_messages() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     IF (OLD.source_id IS DISTINCT FROM NEW.source_id OR OLD.conversation_id IS DISTINCT FROM NEW.conversation_id OR OLD.sender_id IS DISTINCT FROM NEW.sender_id OR OLD.message_type IS DISTINCT FROM NEW.message_type OR OLD.sent_at IS DISTINCT FROM NEW.sent_at OR OLD.received_at IS DISTINCT FROM NEW.received_at OR OLD.internal_date IS DISTINCT FROM NEW.internal_date OR OLD.deleted_at IS DISTINCT FROM NEW.deleted_at OR OLD.deleted_from_source_at IS DISTINCT FROM NEW.deleted_from_source_at OR OLD.metadata IS DISTINCT FROM NEW.metadata OR OLD.source_is_from_me IS DISTINCT FROM NEW.source_is_from_me) THEN
		         PERFORM enqueue_activity_projection_message(NEW.id);
		     END IF;
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: queue_activity_recipient_delete(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_activity_recipient_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     PERFORM enqueue_activity_projection_message(OLD.message_id);
		     RETURN OLD;
		 END;
		 $$;


--
-- Name: queue_activity_recipient_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_activity_recipient_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     PERFORM enqueue_activity_projection_message(NEW.message_id);
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: queue_activity_recipient_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.queue_activity_recipient_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     PERFORM enqueue_activity_projection_message(OLD.message_id);
		     PERFORM enqueue_activity_projection_message(NEW.message_id);
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: reject_terminal_operation_invocation_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_terminal_operation_invocation_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF OLD.state <> 'running' AND to_jsonb(OLD) IS DISTINCT FROM to_jsonb(NEW) THEN
        RAISE EXCEPTION 'terminal operation invocation is immutable';
    END IF;
    RETURN NEW;
END;
$$;


--
-- Name: seed_visual_publication_scope_entry(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.seed_visual_publication_scope_entry() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
		 BEGIN
		     INSERT INTO visual_publications
		         (generation_id, message_id, blob_hash, media_input_key,
		          source_fence, attachment_role, role_source, state)
     SELECT vg.id, a.message_id,
		            CASE WHEN LOWER(COALESCE(a.content_hash, '')) ~ '^[0-9a-f]{64}$'
		                 THEN LOWER(a.content_hash)
		                 ELSE SUBSTRING(a.storage_path FROM 4) END,
		            'original', 0, 'unknown', 'unknown', 'stale'
		     FROM attachments a JOIN visual_generations vg
		          ON vg.state IN ('building', 'active')
		     WHERE a.message_id = NEW.id
		       AND a.attachment_role = 'standalone'
		       AND a.role_source IN ('mime_disposition', 'provider_explicit',
		                             'importer_semantics', 'raw_mime_repair')
		       AND (LOWER(COALESCE(a.content_hash, '')) ~ '^[0-9a-f]{64}$'
		            OR (COALESCE(a.content_hash, '') = ''
		                AND COALESCE(a.storage_path, '') ~ '^[0-9a-f]{2}/[0-9a-f]{64}$'
		                AND SUBSTRING(a.storage_path FROM 1 FOR 2) = SUBSTRING(a.storage_path FROM 4 FOR 2)))
		     ON CONFLICT (generation_id, message_id, blob_hash, media_input_key) DO UPDATE SET
		         state = 'stale',
		         outcome_kind = NULL, outcome_reason = NULL,
		         prepared_revision = NULL,
		         updated_at = CURRENT_TIMESTAMP
		     WHERE visual_publications.state = 'tombstoned';
		     RETURN NEW;
		 END;
		 $_$;


--
-- Name: set_messages_content_changed_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_messages_content_changed_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     NEW.content_changed_at := clock_timestamp();
		     RETURN NEW;
		 END;
		 $$;


--
-- Name: set_messages_last_modified(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_messages_last_modified() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		 BEGIN
		     NEW.last_modified := CURRENT_TIMESTAMP;
		     RETURN NEW;
		 END;
		 $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_identities (
    source_id bigint NOT NULL,
    address text NOT NULL,
    address_key text DEFAULT ''::text NOT NULL,
    source_signal text DEFAULT ''::text NOT NULL,
    confirmed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: activity_event_persons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_event_persons (
    message_id bigint NOT NULL,
    person_id bigint NOT NULL,
    role text NOT NULL,
    evidence text NOT NULL,
    local_date text NOT NULL,
    CONSTRAINT activity_event_persons_evidence_check CHECK ((evidence = ANY (ARRAY['direct'::text, 'co_presence'::text]))),
    CONSTRAINT activity_event_persons_local_date_check CHECK (((length(local_date) = 10) AND (substr(local_date, 1, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 2, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 3, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 4, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 5, 1) = '-'::text) AND (substr(local_date, 6, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 7, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 8, 1) = '-'::text) AND (substr(local_date, 9, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 10, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])))),
    CONSTRAINT activity_event_persons_role_check CHECK ((role = ANY (ARRAY['sender'::text, 'addressed'::text, 'organizer'::text, 'attendee'::text, 'member'::text])))
);


--
-- Name: activity_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_events (
    message_id bigint NOT NULL,
    ref_kind text NOT NULL,
    source_id bigint NOT NULL,
    conversation_id bigint,
    channel text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    date_origin text NOT NULL,
    date_precision text NOT NULL,
    timezone text NOT NULL,
    utc_offset_minutes integer NOT NULL,
    local_date text NOT NULL,
    direction text NOT NULL,
    owner_source_id bigint,
    owner_address text DEFAULT ''::text NOT NULL,
    projected_last_modified timestamp with time zone NOT NULL,
    projected_identity_revision bigint NOT NULL,
    projected_account_identity_revision bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT activity_events_channel_check CHECK ((channel = ANY (ARRAY['email'::text, 'chat'::text, 'meeting'::text, 'other'::text]))),
    CONSTRAINT activity_events_date_origin_check CHECK ((date_origin = ANY (ARRAY['sent_at'::text, 'received_at'::text, 'internal_date'::text]))),
    CONSTRAINT activity_events_date_precision_check CHECK ((date_precision = ANY (ARRAY['timestamp'::text, 'day'::text]))),
    CONSTRAINT activity_events_direction_check CHECK ((direction = ANY (ARRAY['inbound'::text, 'outbound'::text, 'observed'::text]))),
    CONSTRAINT activity_events_local_date_check CHECK (((length(local_date) = 10) AND (substr(local_date, 1, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 2, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 3, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 4, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 5, 1) = '-'::text) AND (substr(local_date, 6, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 7, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 8, 1) = '-'::text) AND (substr(local_date, 9, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 10, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])))),
    CONSTRAINT activity_events_projected_account_identity_revision_check CHECK ((projected_account_identity_revision >= 0)),
    CONSTRAINT activity_events_projected_identity_revision_check CHECK ((projected_identity_revision >= 0)),
    CONSTRAINT activity_events_ref_kind_check CHECK ((ref_kind = ANY (ARRAY['message'::text, 'meeting'::text]))),
    CONSTRAINT activity_events_timezone_check CHECK ((length(timezone) > 0)),
    CONSTRAINT activity_events_utc_offset_minutes_check CHECK (((utc_offset_minutes >= '-840'::integer) AND (utc_offset_minutes <= 840)))
);


--
-- Name: activity_projection_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_projection_queue (
    message_id bigint NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    processed_revision bigint DEFAULT 0 NOT NULL,
    queued_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT activity_projection_queue_check CHECK (((processed_revision >= 0) AND (processed_revision <= revision))),
    CONSTRAINT activity_projection_queue_revision_check CHECK ((revision >= 1))
);


--
-- Name: applied_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.applied_migrations (
    name text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    applied_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: archive_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.archive_metadata (
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: attachment_change_consumers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachment_change_consumers (
    consumer_key text NOT NULL,
    baseline_sequence bigint NOT NULL,
    last_sequence bigint NOT NULL,
    reconciliation_complete boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT attachment_change_consumers_baseline_sequence_check CHECK ((baseline_sequence >= 0)),
    CONSTRAINT attachment_change_consumers_check CHECK ((last_sequence >= baseline_sequence))
);


--
-- Name: attachment_change_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachment_change_log (
    sequence bigint NOT NULL,
    event_kind text NOT NULL,
    old_message_id bigint,
    new_message_id bigint,
    old_attachment_id bigint,
    new_attachment_id bigint,
    old_content_hash text,
    new_content_hash text,
    old_source_part_key text,
    new_source_part_key text,
    old_role text,
    new_role text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT attachment_change_log_event_kind_check CHECK ((event_kind = ANY (ARRAY['attachment_insert'::text, 'attachment_update'::text, 'attachment_delete'::text, 'message_live_enter'::text, 'message_live_exit'::text])))
);


--
-- Name: attachment_change_log_sequence_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.attachment_change_log ALTER COLUMN sequence ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.attachment_change_log_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: attachment_pack_index; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachment_pack_index (
    blob_hash text NOT NULL,
    pack_id text NOT NULL,
    pack_offset bigint NOT NULL,
    stored_len bigint NOT NULL,
    raw_len bigint NOT NULL,
    flags integer NOT NULL,
    crc32c bigint NOT NULL
);


--
-- Name: attachment_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachment_packs (
    pack_id text NOT NULL,
    entry_count bigint NOT NULL,
    stored_bytes bigint NOT NULL,
    created_at text NOT NULL
);


--
-- Name: attachment_role_repair_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachment_role_repair_progress (
    singleton integer NOT NULL,
    last_message_id bigint DEFAULT 0 NOT NULL,
    completed integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT attachment_role_repair_progress_completed_check CHECK ((completed = ANY (ARRAY[0, 1]))),
    CONSTRAINT attachment_role_repair_progress_singleton_check CHECK ((singleton = 1))
);


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    message_id bigint NOT NULL,
    filename text,
    mime_type text,
    size bigint,
    content_hash text,
    storage_path text DEFAULT ''::text NOT NULL,
    media_type text,
    width integer,
    height integer,
    duration_ms integer,
    thumbnail_hash text,
    thumbnail_path text,
    source_attachment_id text,
    attachment_metadata jsonb,
    attachment_state text,
    attachment_skip_reason text,
    attachment_role text DEFAULT 'unknown'::text NOT NULL,
    role_source text DEFAULT 'unknown'::text NOT NULL,
    source_part_key text,
    content_id text,
    encryption_version integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT attachments_attachment_role_check CHECK ((attachment_role = ANY (ARRAY['standalone'::text, 'inline'::text, 'avatar'::text, 'thumbnail'::text, 'preview'::text, 'sticker'::text, 'ui_asset'::text, 'unknown'::text]))),
    CONSTRAINT attachments_role_source_check CHECK ((role_source = ANY (ARRAY['mime_disposition'::text, 'provider_explicit'::text, 'importer_semantics'::text, 'legacy_api'::text, 'raw_mime_repair'::text, 'unknown'::text]))),
    CONSTRAINT attachments_source_part_key_check CHECK (((source_part_key IS NULL) OR (source_part_key <> ''::text)))
);


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.attachments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: attribute_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attribute_definitions (
    id bigint NOT NULL,
    universal_id text NOT NULL,
    object_type text NOT NULL,
    slug text NOT NULL,
    label text NOT NULL,
    description text,
    value_type text NOT NULL,
    field_type text NOT NULL,
    record_target text,
    cardinality text DEFAULT 'single'::text NOT NULL,
    display_order bigint DEFAULT 0 NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    ownership text DEFAULT 'user'::text NOT NULL,
    ui_creatable boolean DEFAULT true NOT NULL,
    ui_editable boolean DEFAULT true NOT NULL,
    api_mutable boolean DEFAULT true NOT NULL,
    is_searchable boolean DEFAULT false NOT NULL,
    is_sensitive boolean DEFAULT false NOT NULL,
    is_audited boolean DEFAULT true NOT NULL,
    is_deletable boolean DEFAULT true NOT NULL,
    history_exempt boolean DEFAULT false NOT NULL,
    derived_source text,
    options jsonb,
    vcard_property text,
    is_active boolean DEFAULT true NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT attribute_definitions_display_order_check CHECK ((display_order >= 0)),
    CONSTRAINT attribute_definitions_label_check CHECK ((length(label) > 0)),
    CONSTRAINT attribute_definitions_slug_check CHECK ((length(slug) > 0)),
    CONSTRAINT attribute_definitions_universal_id_check CHECK ((length(universal_id) > 0))
);


--
-- Name: attribute_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.attribute_definitions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.attribute_definitions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: beeper_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.beeper_drafts (
    draft_id text NOT NULL,
    source_id bigint NOT NULL,
    chat_id text NOT NULL,
    text text,
    revision bigint NOT NULL,
    discarded_at timestamp with time zone,
    pending_operation text,
    pending_original_message_id bigint,
    pending_raw bytea,
    pending_code text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by_principal text,
    CONSTRAINT beeper_drafts_chat_id_check CHECK ((length(TRIM(BOTH FROM chat_id)) > 0)),
    CONSTRAINT beeper_drafts_check CHECK (((pending_operation = 'edit'::text) OR (pending_raw IS NULL))),
    CONSTRAINT beeper_drafts_check1 CHECK (((discarded_at IS NULL) OR (pending_operation IS NULL))),
    CONSTRAINT beeper_drafts_pending_operation_check CHECK ((pending_operation = ANY (ARRAY['edit'::text, 'delete'::text]))),
    CONSTRAINT beeper_drafts_pending_original_message_id_check CHECK ((pending_original_message_id IS NULL)),
    CONSTRAINT beeper_drafts_revision_check CHECK ((revision > 0))
);


--
-- Name: beeper_media_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.beeper_media_deliveries (
    destination_key text NOT NULL,
    processing_key text NOT NULL,
    source_sha256 text NOT NULL,
    byte_length bigint NOT NULL,
    transcript_sha256 text DEFAULT ''::text NOT NULL,
    language text DEFAULT ''::text NOT NULL,
    provider text DEFAULT 'beeper'::text NOT NULL,
    profile text DEFAULT 'supplied-transcript'::text NOT NULL,
    phase text DEFAULT 'pending-artifact'::text NOT NULL,
    source_id text DEFAULT ''::text NOT NULL,
    source_version_id text DEFAULT ''::text NOT NULL,
    content_version_id text DEFAULT ''::text NOT NULL,
    donor_occurrence_id text DEFAULT ''::text NOT NULL,
    supplied_input_id text DEFAULT ''::text NOT NULL,
    pending_operation_id text,
    frozen_request_json text,
    next_action_at timestamp with time zone,
    error_code text DEFAULT ''::text NOT NULL,
    processing_operation_id text DEFAULT ''::text NOT NULL,
    job_id text DEFAULT ''::text NOT NULL,
    operation_state text DEFAULT ''::text NOT NULL,
    coverage_state text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT beeper_media_deliveries_byte_length_check CHECK ((byte_length > 0)),
    CONSTRAINT beeper_media_deliveries_phase_check CHECK ((phase = ANY (ARRAY['pending-artifact'::text, 'pending-process'::text, 'observing'::text, 'done'::text, 'blocked'::text, 'source_unavailable'::text])))
);


--
-- Name: beeper_media_occurrences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.beeper_media_occurrences (
    destination_key text NOT NULL,
    occurrence_ref text NOT NULL,
    revision text NOT NULL,
    source_type text NOT NULL,
    source_identifier text NOT NULL,
    source_conversation_id text NOT NULL,
    source_message_id text NOT NULL,
    source_attachment_id text NOT NULL,
    source_part_key text NOT NULL,
    source_row_id bigint DEFAULT 0 NOT NULL,
    message_id bigint DEFAULT 0 NOT NULL,
    attachment_id bigint DEFAULT 0 NOT NULL,
    source_sha256 text NOT NULL,
    byte_length bigint NOT NULL,
    raw_hash text DEFAULT ''::text NOT NULL,
    transcript_sha256 text DEFAULT ''::text NOT NULL,
    language text DEFAULT ''::text NOT NULL,
    occurrence_json text NOT NULL,
    request_filename text NOT NULL,
    request_mime_type text NOT NULL,
    retention_operation_id text DEFAULT ''::text NOT NULL,
    retention_state text DEFAULT 'pending'::text NOT NULL,
    next_action_at timestamp with time zone,
    error_code text DEFAULT ''::text NOT NULL,
    vault_uid text DEFAULT ''::text NOT NULL,
    source_id text DEFAULT ''::text NOT NULL,
    source_version_id text DEFAULT ''::text NOT NULL,
    content_version_id text DEFAULT ''::text NOT NULL,
    occurrence_id text DEFAULT ''::text NOT NULL,
    processing_key text DEFAULT ''::text NOT NULL,
    coverage_state text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT beeper_media_occurrences_byte_length_check CHECK ((byte_length > 0)),
    CONSTRAINT beeper_media_occurrences_retention_state_check CHECK ((retention_state = ANY (ARRAY['pending'::text, 'retained'::text, 'blocked'::text, 'source_unavailable'::text, 'revoked'::text])))
);


--
-- Name: carddav_account_home_urls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_account_home_urls (
    account_id bigint NOT NULL,
    home_url text NOT NULL,
    discovery_index integer NOT NULL,
    CONSTRAINT carddav_account_home_urls_discovery_index_check CHECK ((discovery_index >= 0))
);


--
-- Name: carddav_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_accounts (
    id bigint NOT NULL,
    connection_name text DEFAULT 'default'::text NOT NULL,
    base_url text NOT NULL,
    username text NOT NULL,
    principal_url text NOT NULL,
    home_url text NOT NULL,
    connection_generation bigint DEFAULT 1 NOT NULL,
    discovery_revision bigint DEFAULT 0 NOT NULL,
    discovered_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT carddav_accounts_connection_generation_check CHECK ((connection_generation > 0)),
    CONSTRAINT carddav_accounts_discovery_revision_check CHECK ((discovery_revision >= 0)),
    CONSTRAINT carddav_accounts_id_positive CHECK ((id > 0))
);


--
-- Name: carddav_address_book_urls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_address_book_urls (
    account_id bigint NOT NULL,
    address_book_id bigint NOT NULL,
    url_role text NOT NULL,
    normalized_url text NOT NULL,
    CONSTRAINT carddav_address_book_urls_url_role_check CHECK ((url_role = ANY (ARRAY['canonical'::text, 'alias'::text])))
);


--
-- Name: carddav_address_books; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_address_books (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    canonical_url text NOT NULL,
    discovery_alias_url text,
    display_name text NOT NULL,
    discovery_index integer NOT NULL,
    supports_sync_collection boolean DEFAULT false NOT NULL,
    supports_multiget boolean DEFAULT false NOT NULL,
    supported_vcard_versions jsonb DEFAULT '[]'::jsonb NOT NULL,
    can_create boolean,
    can_update boolean,
    can_delete boolean,
    is_write_target boolean DEFAULT false NOT NULL,
    is_subscribed boolean DEFAULT false NOT NULL,
    is_lookup_source boolean DEFAULT true NOT NULL,
    sync_token text DEFAULT ''::text NOT NULL,
    sync_revision bigint DEFAULT 1 NOT NULL,
    needs_full_reconcile boolean DEFAULT false NOT NULL,
    last_seen_revision bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT carddav_address_books_check CHECK (((NOT is_write_target) OR is_subscribed)),
    CONSTRAINT carddav_address_books_discovery_index_check CHECK ((discovery_index >= 0)),
    CONSTRAINT carddav_address_books_last_seen_revision_check CHECK ((last_seen_revision >= 0)),
    CONSTRAINT carddav_address_books_sync_revision_check CHECK ((sync_revision > 0))
);


--
-- Name: carddav_address_books_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.carddav_address_books ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.carddav_address_books_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: carddav_conflicts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_conflicts (
    id bigint NOT NULL,
    address_book_id bigint NOT NULL,
    href text NOT NULL,
    base_local_hash text NOT NULL,
    local_hash text NOT NULL,
    base_remote_hash text NOT NULL,
    base_remote_etag text NOT NULL,
    remote_etag text,
    mapping_revision bigint NOT NULL,
    review_revision bigint DEFAULT 1 NOT NULL,
    local_inference_revision bigint,
    approved_local_body_sha256 text,
    approved_local_inference_revision bigint,
    approved_conflict_revision bigint,
    local_envelope_metadata bytea,
    local_mutation_intent bytea,
    local_body bytea,
    remote_body bytea,
    local_tombstone boolean DEFAULT false NOT NULL,
    remote_tombstone boolean DEFAULT false NOT NULL,
    pending_operation text,
    connection_generation bigint,
    book_sync_revision bigint,
    previous_mapping_revision bigint,
    pending_started_at timestamp with time zone,
    status text DEFAULT 'unresolved'::text NOT NULL,
    resolution text,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT carddav_conflicts_check CHECK ((local_tombstone OR (local_body IS NOT NULL))),
    CONSTRAINT carddav_conflicts_check1 CHECK ((remote_tombstone OR (remote_body IS NOT NULL))),
    CONSTRAINT carddav_conflicts_check2 CHECK ((((status = 'unresolved'::text) AND (resolution IS NULL) AND (resolved_at IS NULL)) OR ((status = 'resolved'::text) AND (resolution IS NOT NULL) AND (resolved_at IS NOT NULL)))),
    CONSTRAINT carddav_conflicts_mapping_revision_check CHECK ((mapping_revision > 0)),
    CONSTRAINT carddav_conflicts_pending_invariant CHECK (((pending_operation IS NULL) OR ((status = 'unresolved'::text) AND local_tombstone AND (remote_etag IS NOT NULL) AND (connection_generation IS NOT NULL) AND (book_sync_revision IS NOT NULL) AND (previous_mapping_revision IS NOT NULL) AND (pending_started_at IS NOT NULL)))),
    CONSTRAINT carddav_conflicts_pending_operation_check CHECK ((pending_operation = 'delete'::text)),
    CONSTRAINT carddav_conflicts_resolution_check CHECK ((resolution = ANY (ARRAY['keep_local'::text, 'keep_remote'::text]))),
    CONSTRAINT carddav_conflicts_status_check CHECK ((status = ANY (ARRAY['unresolved'::text, 'resolved'::text])))
);


--
-- Name: carddav_conflicts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.carddav_conflicts ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.carddav_conflicts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: carddav_discovery_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_discovery_lock (
    singleton smallint NOT NULL,
    CONSTRAINT carddav_discovery_lock_singleton_check CHECK ((singleton = 1))
);


--
-- Name: carddav_publications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_publications (
    person_id bigint NOT NULL,
    desired boolean DEFAULT true NOT NULL,
    address_book_id bigint,
    href text,
    pending_operation text,
    outgoing_body bytea,
    outgoing_semantic_hash text,
    local_hash text,
    remote_etag text,
    connection_generation bigint,
    book_sync_revision bigint,
    mapping_revision bigint,
    previous_mapping_revision bigint,
    create_recovery_used boolean DEFAULT false NOT NULL,
    mutation_revision bigint DEFAULT 0 NOT NULL,
    outgoing_envelope_metadata bytea,
    approved_body_sha256 text,
    approved_inference_revision bigint,
    approved_mutation_revision bigint,
    pending_started_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT carddav_publications_check CHECK (((pending_operation IS NULL) OR ((address_book_id IS NOT NULL) AND (href IS NOT NULL) AND (local_hash IS NOT NULL) AND (connection_generation IS NOT NULL) AND (book_sync_revision IS NOT NULL) AND (mapping_revision IS NOT NULL)))),
    CONSTRAINT carddav_publications_mutation_revision_check CHECK ((mutation_revision >= 0)),
    CONSTRAINT carddav_publications_pending_operation_check CHECK ((pending_operation = ANY (ARRAY['create'::text, 'update'::text, 'delete'::text])))
);


--
-- Name: carddav_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_resources (
    id bigint NOT NULL,
    address_book_id bigint NOT NULL,
    href text NOT NULL,
    remote_uid text,
    remote_etag text NOT NULL,
    remote_body bytea NOT NULL,
    remote_semantic_hash text NOT NULL,
    local_hash text NOT NULL,
    mapping_status text NOT NULL,
    mapping_revision bigint DEFAULT 1 NOT NULL,
    governance text NOT NULL,
    person_id bigint,
    person_revision_at_bind bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT carddav_resources_governance_check CHECK ((governance = ANY (ARRAY['remote'::text, 'local'::text, 'none'::text]))),
    CONSTRAINT carddav_resources_mapping_revision_check CHECK ((mapping_revision > 0)),
    CONSTRAINT carddav_resources_mapping_status_check CHECK ((mapping_status = ANY (ARRAY['mapped'::text, 'unbound'::text, 'ambiguous'::text])))
);


--
-- Name: carddav_resources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.carddav_resources ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.carddav_resources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: carddav_retry_gate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_retry_gate (
    account_id bigint NOT NULL,
    retry_after_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: carddav_sync_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carddav_sync_runs (
    id bigint NOT NULL,
    account_id bigint DEFAULT 1 NOT NULL,
    trigger text NOT NULL,
    full_sync boolean DEFAULT false NOT NULL,
    state text NOT NULL,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    finished_at timestamp with time zone,
    books bigint DEFAULT 0 NOT NULL,
    created bigint DEFAULT 0 NOT NULL,
    updated bigint DEFAULT 0 NOT NULL,
    removed bigint DEFAULT 0 NOT NULL,
    error_code text DEFAULT ''::text NOT NULL,
    error_message text DEFAULT ''::text NOT NULL,
    CONSTRAINT carddav_sync_runs_account_id_check CHECK ((account_id > 0)),
    CONSTRAINT carddav_sync_runs_books_check CHECK ((books >= 0)),
    CONSTRAINT carddav_sync_runs_check CHECK ((((state = 'running'::text) AND (finished_at IS NULL)) OR ((state <> 'running'::text) AND (finished_at IS NOT NULL)))),
    CONSTRAINT carddav_sync_runs_check1 CHECK ((((state = ANY (ARRAY['running'::text, 'succeeded'::text])) AND (error_code = ''::text) AND (error_message = ''::text)) OR ((state = ANY (ARRAY['failed'::text, 'cancelled'::text, 'partial'::text])) AND (error_code <> ''::text)))),
    CONSTRAINT carddav_sync_runs_created_check CHECK ((created >= 0)),
    CONSTRAINT carddav_sync_runs_error_code_check CHECK (((error_code = ''::text) OR (error_code ~ '^[a-z][a-z0-9_]{0,63}$'::text))),
    CONSTRAINT carddav_sync_runs_error_message_check CHECK ((octet_length(error_message) <= 2000)),
    CONSTRAINT carddav_sync_runs_removed_check CHECK ((removed >= 0)),
    CONSTRAINT carddav_sync_runs_state_check CHECK ((state = ANY (ARRAY['running'::text, 'succeeded'::text, 'failed'::text, 'cancelled'::text, 'partial'::text]))),
    CONSTRAINT carddav_sync_runs_trigger_check CHECK ((trigger = ANY (ARRAY['manual'::text, 'scheduled'::text]))),
    CONSTRAINT carddav_sync_runs_updated_check CHECK ((updated >= 0))
);


--
-- Name: carddav_sync_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.carddav_sync_runs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.carddav_sync_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: chat_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_drafts (
    draft_id text NOT NULL,
    source_id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    source_conversation_id text NOT NULL,
    conversation_type text NOT NULL,
    reply_to_source_message_id text,
    body text NOT NULL,
    revision bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by_principal text,
    CONSTRAINT chat_drafts_revision_check CHECK ((revision > 0))
);


--
-- Name: collection_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collection_sources (
    collection_id bigint NOT NULL,
    source_id bigint NOT NULL
);


--
-- Name: collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections (
    id bigint NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: collections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.collections ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.collections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: communication_service_aliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_service_aliases (
    alias text NOT NULL,
    service_id bigint NOT NULL
);


--
-- Name: communication_service_discoveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_service_discoveries (
    service_id bigint NOT NULL,
    provider text NOT NULL,
    discovery_kind text NOT NULL
);


--
-- Name: communication_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_services (
    id bigint NOT NULL,
    slug text NOT NULL,
    display_label text NOT NULL,
    scope_policy text DEFAULT 'none'::text NOT NULL,
    default_scope_kind text,
    normalization text DEFAULT 'none'::text NOT NULL,
    normalization_version integer DEFAULT 1 NOT NULL,
    uri_scheme text,
    profile_url_template text,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: communication_services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.communication_services ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.communication_services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: conversation_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_participants (
    conversation_id bigint NOT NULL,
    participant_id bigint NOT NULL,
    role text DEFAULT 'member'::text,
    joined_at timestamp with time zone,
    left_at timestamp with time zone
);


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id bigint NOT NULL,
    source_id bigint NOT NULL,
    source_conversation_id text,
    conversation_type text DEFAULT 'email_thread'::text NOT NULL,
    title text,
    participant_count integer DEFAULT 0,
    message_count integer DEFAULT 0,
    unread_count integer DEFAULT 0,
    last_message_at timestamp with time zone,
    last_message_preview text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.conversations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: daily_note_day_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_note_day_sequences (
    local_date text NOT NULL,
    last_ordinal bigint NOT NULL,
    CONSTRAINT daily_note_day_sequences_last_ordinal_check CHECK ((last_ordinal > 0)),
    CONSTRAINT daily_note_day_sequences_local_date_check CHECK (((length(local_date) = 10) AND (substr(local_date, 1, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 2, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 3, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 4, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 5, 1) = '-'::text) AND (substr(local_date, 6, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 7, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 8, 1) = '-'::text) AND (substr(local_date, 9, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 10, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text]))))
);


--
-- Name: daily_note_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_note_entries (
    id bigint NOT NULL,
    local_date text NOT NULL,
    ordinal bigint NOT NULL,
    body text NOT NULL,
    author text DEFAULT ''::text NOT NULL,
    source text DEFAULT 'user'::text NOT NULL,
    source_ref text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT daily_note_entries_local_date_check CHECK (((length(local_date) = 10) AND (substr(local_date, 1, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 2, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 3, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 4, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 5, 1) = '-'::text) AND (substr(local_date, 6, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 7, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 8, 1) = '-'::text) AND (substr(local_date, 9, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])) AND (substr(local_date, 10, 1) = ANY (ARRAY['0'::text, '1'::text, '2'::text, '3'::text, '4'::text, '5'::text, '6'::text, '7'::text, '8'::text, '9'::text])))),
    CONSTRAINT daily_note_entries_ordinal_check CHECK ((ordinal > 0)),
    CONSTRAINT daily_note_entries_source_check CHECK ((source = 'user'::text))
);


--
-- Name: daily_note_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.daily_note_entries ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.daily_note_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: daily_note_entry_persons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_note_entry_persons (
    entry_id bigint NOT NULL,
    person_id bigint NOT NULL
);


--
-- Name: directory_people; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_people (
    person_id bigint NOT NULL,
    order_key text NOT NULL,
    contact_state text NOT NULL,
    primary_channel text NOT NULL,
    last_contact_key text DEFAULT ''::text NOT NULL
);


--
-- Name: directory_person_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_person_filters (
    person_id bigint NOT NULL,
    filter_kind text NOT NULL,
    value_key text NOT NULL
);


--
-- Name: directory_person_token_deletes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_person_token_deletes (
    person_id bigint NOT NULL,
    delete_key text NOT NULL
);


--
-- Name: directory_person_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_person_tokens (
    person_id bigint NOT NULL,
    token_key text NOT NULL
);


--
-- Name: directory_projection_dirty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.directory_projection_dirty (
    person_id bigint NOT NULL
);


--
-- Name: document_chunk_spans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_chunk_spans (
    extraction_id text NOT NULL,
    chunk_key text NOT NULL,
    span_ordinal integer NOT NULL,
    unit_index integer NOT NULL,
    start_char integer NOT NULL,
    end_char integer NOT NULL,
    synthetic boolean DEFAULT false NOT NULL,
    CONSTRAINT document_chunk_spans_check CHECK (((start_char >= 0) AND (end_char >= start_char))),
    CONSTRAINT document_chunk_spans_span_ordinal_check CHECK ((span_ordinal >= 0))
);


--
-- Name: document_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_chunks (
    id bigint NOT NULL,
    extraction_id text NOT NULL,
    chunk_key text NOT NULL,
    ordinal integer NOT NULL,
    text text NOT NULL,
    heading_path jsonb NOT NULL,
    first_unit_index integer NOT NULL,
    last_unit_index integer NOT NULL,
    synthetic_prefix_len integer DEFAULT 0 NOT NULL,
    checksum text NOT NULL,
    char_count integer NOT NULL,
    table_chunk boolean DEFAULT false NOT NULL,
    code_chunk boolean DEFAULT false NOT NULL,
    truncated boolean DEFAULT false NOT NULL,
    search_fts tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, COALESCE(text, ''::text))) STORED,
    CONSTRAINT document_chunks_check CHECK (((first_unit_index >= 0) AND (last_unit_index >= first_unit_index))),
    CONSTRAINT document_chunks_check1 CHECK (((synthetic_prefix_len >= 0) AND (char_count >= 0))),
    CONSTRAINT document_chunks_ordinal_check CHECK ((ordinal >= 0))
);


--
-- Name: document_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.document_chunks ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.document_chunks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: document_embedding_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_embedding_runs (
    id bigint NOT NULL,
    invocation_key text NOT NULL,
    trigger text NOT NULL,
    state text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    error_code text,
    attempted bigint DEFAULT 0 NOT NULL,
    succeeded bigint DEFAULT 0 NOT NULL,
    failed bigint DEFAULT 0 NOT NULL,
    CONSTRAINT document_embedding_runs_attempted_check CHECK ((attempted >= 0)),
    CONSTRAINT document_embedding_runs_check CHECK ((((state = 'running'::text) AND (finished_at IS NULL) AND (error_code IS NULL)) OR ((state <> 'running'::text) AND (finished_at IS NOT NULL)))),
    CONSTRAINT document_embedding_runs_error_code_check CHECK (((error_code IS NULL) OR (error_code = ANY (ARRAY['invocation_cancelled'::text, 'invocation_timeout'::text, 'invocation_rate_limited'::text, 'invocation_authentication_failed'::text, 'invocation_upstream_failed'::text, 'invocation_invalid_output'::text, 'invocation_safety_limit'::text, 'invocation_archive_drift'::text, 'invocation_daemon_restarted'::text, 'invocation_internal'::text, 'invocation_unsafe_error_redacted'::text])))),
    CONSTRAINT document_embedding_runs_failed_check CHECK ((failed >= 0)),
    CONSTRAINT document_embedding_runs_invocation_key_check CHECK ((((octet_length(invocation_key) >= 1) AND (octet_length(invocation_key) <= 128)) AND (btrim(invocation_key) = invocation_key))),
    CONSTRAINT document_embedding_runs_state_check CHECK ((state = ANY (ARRAY['running'::text, 'succeeded'::text, 'partial'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT document_embedding_runs_succeeded_check CHECK ((succeeded >= 0)),
    CONSTRAINT document_embedding_runs_trigger_check CHECK ((trigger = ANY (ARRAY['manual'::text, 'scheduled'::text])))
);


--
-- Name: document_embedding_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.document_embedding_runs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.document_embedding_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: document_extraction_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extraction_claims (
    profile_id text NOT NULL,
    canonical_blob_hash text NOT NULL,
    extraction_input_key text NOT NULL,
    extraction_id text NOT NULL,
    lease_owner text NOT NULL,
    lease_fence bigint NOT NULL,
    lease_until timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: document_extraction_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extraction_conversions (
    extraction_id text NOT NULL,
    provider_media_type text NOT NULL,
    pdf_sha256 text NOT NULL,
    pdf_bytes bigint NOT NULL,
    pages integer NOT NULL,
    policy_fingerprint text NOT NULL,
    converter_version text NOT NULL,
    spans jsonb NOT NULL,
    CONSTRAINT document_extraction_conversions_pages_check CHECK ((pages > 0)),
    CONSTRAINT document_extraction_conversions_pdf_bytes_check CHECK ((pdf_bytes > 0)),
    CONSTRAINT document_extraction_conversions_pdf_sha256_check CHECK ((length(pdf_sha256) = 64))
);


--
-- Name: document_extraction_heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extraction_heads (
    profile_id text NOT NULL,
    canonical_blob_hash text NOT NULL,
    extraction_input_key text NOT NULL,
    extraction_id text NOT NULL,
    source_sequence bigint DEFAULT 0 NOT NULL,
    switched_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: document_extraction_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extraction_profiles (
    id text NOT NULL,
    fingerprint text NOT NULL,
    provider text NOT NULL,
    endpoint text NOT NULL,
    region text NOT NULL,
    model text NOT NULL,
    retention_posture text NOT NULL,
    training_posture text NOT NULL,
    allowed_media_types jsonb NOT NULL,
    include_inline boolean DEFAULT false NOT NULL,
    policy_json jsonb NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    retired_at timestamp with time zone
);


--
-- Name: document_extraction_rebuild_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extraction_rebuild_targets (
    rebuild_id text NOT NULL,
    canonical_blob_hash text NOT NULL,
    CONSTRAINT document_extraction_rebuild_targets_canonical_blob_hash_check CHECK ((length(canonical_blob_hash) = 64))
);


--
-- Name: document_extraction_rebuilds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extraction_rebuilds (
    id text NOT NULL,
    profile_id text NOT NULL,
    extraction_input_key text NOT NULL,
    state text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT document_extraction_rebuilds_state_check CHECK ((state = ANY (ARRAY['building'::text, 'completed'::text])))
);


--
-- Name: document_extraction_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extraction_runs (
    id bigint NOT NULL,
    invocation_key text NOT NULL,
    trigger text NOT NULL,
    state text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    error_code text,
    attempted bigint DEFAULT 0 NOT NULL,
    succeeded bigint DEFAULT 0 NOT NULL,
    failed bigint DEFAULT 0 NOT NULL,
    CONSTRAINT document_extraction_runs_attempted_check CHECK ((attempted >= 0)),
    CONSTRAINT document_extraction_runs_check CHECK ((((state = 'running'::text) AND (finished_at IS NULL) AND (error_code IS NULL)) OR ((state <> 'running'::text) AND (finished_at IS NOT NULL)))),
    CONSTRAINT document_extraction_runs_error_code_check CHECK (((error_code IS NULL) OR (error_code = ANY (ARRAY['invocation_cancelled'::text, 'invocation_timeout'::text, 'invocation_rate_limited'::text, 'invocation_authentication_failed'::text, 'invocation_upstream_failed'::text, 'invocation_invalid_output'::text, 'invocation_safety_limit'::text, 'invocation_archive_drift'::text, 'invocation_daemon_restarted'::text, 'invocation_internal'::text, 'invocation_unsafe_error_redacted'::text])))),
    CONSTRAINT document_extraction_runs_failed_check CHECK ((failed >= 0)),
    CONSTRAINT document_extraction_runs_invocation_key_check CHECK ((((octet_length(invocation_key) >= 1) AND (octet_length(invocation_key) <= 128)) AND (btrim(invocation_key) = invocation_key))),
    CONSTRAINT document_extraction_runs_state_check CHECK ((state = ANY (ARRAY['running'::text, 'succeeded'::text, 'partial'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT document_extraction_runs_succeeded_check CHECK ((succeeded >= 0)),
    CONSTRAINT document_extraction_runs_trigger_check CHECK ((trigger = ANY (ARRAY['manual'::text, 'scheduled'::text])))
);


--
-- Name: document_extraction_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.document_extraction_runs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.document_extraction_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: document_extractions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_extractions (
    id text NOT NULL,
    profile_id text NOT NULL,
    rebuild_id text,
    canonical_blob_hash text NOT NULL,
    extraction_input_key text DEFAULT 'original'::text NOT NULL,
    source_media_type text,
    state text NOT NULL,
    lease_owner text,
    lease_fence bigint DEFAULT 0 NOT NULL,
    lease_until timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    request_count integer DEFAULT 0 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    provider_latency_ms bigint DEFAULT 0 NOT NULL,
    next_retry_at timestamp with time zone,
    local_bytes bigint NOT NULL,
    provider_bytes bigint,
    units_processed integer,
    returned_model text,
    manifest_checksum text,
    normalization_version integer,
    document_family text,
    unit_kind text,
    normalized_truncated boolean DEFAULT false NOT NULL,
    terminal_reason text,
    failure_reason text,
    failure_detail text,
    source_sequence bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    published_at timestamp with time zone,
    CONSTRAINT document_extractions_canonical_blob_hash_check CHECK ((length(canonical_blob_hash) = 64)),
    CONSTRAINT document_extractions_check CHECK (((retry_count >= 0) AND (retry_count <= request_count))),
    CONSTRAINT document_extractions_local_bytes_check CHECK ((local_bytes >= 0)),
    CONSTRAINT document_extractions_provider_bytes_check CHECK (((provider_bytes IS NULL) OR (provider_bytes >= 0))),
    CONSTRAINT document_extractions_provider_latency_ms_check CHECK ((provider_latency_ms >= 0)),
    CONSTRAINT document_extractions_request_count_check CHECK ((request_count >= 0)),
    CONSTRAINT document_extractions_state_check CHECK ((state = ANY (ARRAY['staging'::text, 'ready'::text, 'terminal'::text, 'tombstoned'::text]))),
    CONSTRAINT document_extractions_units_processed_check CHECK (((units_processed IS NULL) OR (units_processed >= 0)))
);


--
-- Name: document_index_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_index_state (
    singleton smallint NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    target_profile_id text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT document_index_state_singleton_check CHECK ((singleton = 1))
);


--
-- Name: document_occurrences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_occurrences (
    occurrence_key text NOT NULL,
    attachment_id bigint NOT NULL,
    message_id bigint NOT NULL,
    source_id bigint NOT NULL,
    source_part_key text,
    stable_source_part boolean DEFAULT false NOT NULL,
    canonical_blob_hash text NOT NULL,
    filename text,
    mime_type text,
    attachment_role text NOT NULL,
    role_source text NOT NULL,
    source_sequence bigint DEFAULT 0 NOT NULL,
    reconciled_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT document_occurrences_canonical_blob_hash_check CHECK ((length(canonical_blob_hash) = 64))
);


--
-- Name: document_provider_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_provider_consents (
    profile_id text NOT NULL,
    profile_fingerprint text NOT NULL,
    retention_posture text NOT NULL,
    training_posture text NOT NULL,
    consented_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: document_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_units (
    extraction_id text NOT NULL,
    unit_index integer NOT NULL,
    unit_kind text NOT NULL,
    text text NOT NULL,
    header_text text,
    footer_text text,
    width integer,
    height integer,
    dpi integer,
    checksum text NOT NULL,
    char_count integer NOT NULL,
    truncated boolean DEFAULT false NOT NULL,
    heading_marks jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT document_units_char_count_check CHECK ((char_count >= 0)),
    CONSTRAINT document_units_unit_index_check CHECK ((unit_index >= 0))
);


--
-- Name: document_vector_build_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_vector_build_progress (
    generation_id bigint NOT NULL,
    after_chunk_id bigint NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT document_vector_build_progress_after_chunk_id_check CHECK ((after_chunk_id > 0))
);


--
-- Name: document_vector_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_vector_consents (
    egress_fingerprint text NOT NULL,
    purpose text NOT NULL,
    generation_fingerprint text NOT NULL,
    target_extraction_profile_id text NOT NULL,
    embedding_profile text NOT NULL,
    model text NOT NULL,
    dimension integer NOT NULL,
    consented_at timestamp with time zone NOT NULL,
    CONSTRAINT document_vector_consents_dimension_check CHECK ((dimension > 0)),
    CONSTRAINT document_vector_consents_purpose_check CHECK ((purpose = ANY (ARRAY['document_embedding'::text, 'query_embedding'::text])))
);


--
-- Name: document_vector_generations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_vector_generations (
    id bigint NOT NULL,
    fingerprint text NOT NULL,
    target_extraction_profile_id text NOT NULL,
    embedding_profile text NOT NULL,
    model text NOT NULL,
    dimension integer NOT NULL,
    state text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    activated_at timestamp with time zone,
    retired_at timestamp with time zone,
    CONSTRAINT document_vector_generations_dimension_check CHECK ((dimension > 0)),
    CONSTRAINT document_vector_generations_state_check CHECK ((state = ANY (ARRAY['building'::text, 'active'::text, 'retired'::text])))
);


--
-- Name: document_vector_generations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.document_vector_generations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.document_vector_generations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: document_vector_provider_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_vector_provider_usage (
    fingerprint text NOT NULL,
    provider_calls bigint DEFAULT 0 NOT NULL,
    provider_documents bigint DEFAULT 0 NOT NULL,
    provider_chunks bigint DEFAULT 0 NOT NULL,
    provider_input_chars bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT document_vector_provider_usage_provider_calls_check CHECK ((provider_calls >= 0)),
    CONSTRAINT document_vector_provider_usage_provider_chunks_check CHECK ((provider_chunks >= 0)),
    CONSTRAINT document_vector_provider_usage_provider_documents_check CHECK ((provider_documents >= 0)),
    CONSTRAINT document_vector_provider_usage_provider_input_chars_check CHECK ((provider_input_chars >= 0))
);


--
-- Name: document_vector_publications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_vector_publications (
    generation_id bigint NOT NULL,
    extraction_id text NOT NULL,
    extraction_profile_id text NOT NULL,
    canonical_blob_hash text NOT NULL,
    extraction_input_key text NOT NULL,
    chunk_id bigint NOT NULL,
    chunk_key text NOT NULL,
    chunk_checksum text NOT NULL,
    source_sequence bigint NOT NULL,
    token text NOT NULL,
    state text NOT NULL,
    lease_owner text,
    lease_fence bigint DEFAULT 0 NOT NULL,
    lease_until timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    next_retry_at timestamp with time zone,
    error_code text,
    backend_cleaned_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT document_vector_publications_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT document_vector_publications_canonical_blob_hash_check CHECK ((length(canonical_blob_hash) = 64)),
    CONSTRAINT document_vector_publications_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'ready'::text, 'failed'::text])))
);


--
-- Name: embedding_change_clock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.embedding_change_clock (
    singleton smallint NOT NULL,
    sequence bigint NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    CONSTRAINT embedding_change_clock_singleton_check CHECK ((singleton = 1))
);


--
-- Name: embedding_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.embedding_changes (
    sequence bigint NOT NULL,
    kind text NOT NULL,
    message_id bigint,
    old_message_type text,
    new_message_type text,
    old_conversation_id bigint,
    new_conversation_id bigint,
    old_sent_at timestamp with time zone,
    new_sent_at timestamp with time zone,
    participant_id bigint
);


--
-- Name: employments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employments (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    organization_id bigint NOT NULL,
    title text,
    title_normalized text DEFAULT ''::text NOT NULL,
    role text,
    department text,
    location text,
    address_id bigint,
    description text,
    start_year integer,
    start_month integer,
    start_day integer,
    end_year integer,
    end_month integer,
    end_day integer,
    is_current boolean DEFAULT true NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    source text DEFAULT 'user'::text NOT NULL,
    source_ref text,
    confidence double precision,
    revision bigint DEFAULT 1 NOT NULL,
    created_by text DEFAULT 'user'::text NOT NULL,
    updated_by text DEFAULT 'user'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT employments_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT employments_check1 CHECK (((start_day IS NULL) OR (start_month IS NOT NULL))),
    CONSTRAINT employments_check2 CHECK (((end_day IS NULL) OR (end_month IS NOT NULL))),
    CONSTRAINT employments_check3 CHECK (((start_month IS NULL) OR (start_year IS NOT NULL))),
    CONSTRAINT employments_check4 CHECK (((end_month IS NULL) OR (end_year IS NOT NULL))),
    CONSTRAINT employments_end_day_check CHECK (((end_day >= 1) AND (end_day <= 31))),
    CONSTRAINT employments_end_month_check CHECK (((end_month >= 1) AND (end_month <= 12))),
    CONSTRAINT employments_end_year_check CHECK (((end_year >= 1) AND (end_year <= 9999))),
    CONSTRAINT employments_start_day_check CHECK (((start_day >= 1) AND (start_day <= 31))),
    CONSTRAINT employments_start_month_check CHECK (((start_month >= 1) AND (start_month <= 12))),
    CONSTRAINT employments_start_year_check CHECK (((start_year >= 1) AND (start_year <= 9999)))
);


--
-- Name: employments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.employments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: gmail_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gmail_drafts (
    draft_id text NOT NULL,
    source_id bigint NOT NULL,
    gmail_draft_id text NOT NULL,
    current_message_id bigint NOT NULL,
    current_gmail_message_id text NOT NULL,
    thread_id text NOT NULL,
    revision bigint NOT NULL,
    discarded_at timestamp with time zone,
    pending_operation text,
    pending_original_message_id bigint,
    pending_original_gmail_message_id text,
    pending_raw bytea,
    pending_replacement_gmail_message_id text,
    pending_code text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by_principal text,
    CONSTRAINT gmail_drafts_check CHECK ((((pending_operation IS NULL) AND (pending_original_message_id IS NULL) AND (pending_original_gmail_message_id IS NULL) AND (pending_raw IS NULL) AND (pending_replacement_gmail_message_id IS NULL) AND (pending_code IS NULL)) OR ((pending_operation = ANY (ARRAY['edit'::text, 'delete'::text])) AND (pending_original_message_id IS NOT NULL) AND (pending_original_gmail_message_id IS NOT NULL) AND (length(TRIM(BOTH FROM pending_original_gmail_message_id)) > 0) AND (((pending_operation = 'edit'::text) AND (pending_raw IS NOT NULL) AND (length(pending_raw) > 0)) OR ((pending_operation = 'delete'::text) AND (pending_raw IS NULL))) AND ((pending_operation = 'edit'::text) OR (pending_replacement_gmail_message_id IS NULL))))),
    CONSTRAINT gmail_drafts_check1 CHECK (((pending_operation = 'edit'::text) OR (pending_replacement_gmail_message_id IS NULL))),
    CONSTRAINT gmail_drafts_check2 CHECK (((discarded_at IS NULL) OR (pending_operation IS NULL))),
    CONSTRAINT gmail_drafts_revision_check CHECK ((revision > 0))
);


--
-- Name: identity_match_candidate_redirects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_match_candidate_redirects (
    retired_candidate_id bigint NOT NULL,
    surviving_candidate_id bigint,
    endpoints_collapsed boolean DEFAULT false NOT NULL,
    CONSTRAINT identity_match_candidate_redirects_check CHECK ((((endpoints_collapsed = true) AND (surviving_candidate_id IS NULL)) OR ((endpoints_collapsed = false) AND (surviving_candidate_id IS NOT NULL))))
);


--
-- Name: identity_match_candidate_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_match_candidate_sources (
    candidate_id bigint NOT NULL,
    source_id bigint NOT NULL,
    is_conservative boolean DEFAULT false NOT NULL
);


--
-- Name: identity_match_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_match_candidates (
    id bigint NOT NULL,
    left_kind text NOT NULL,
    left_id bigint NOT NULL,
    right_kind text NOT NULL,
    right_id bigint NOT NULL,
    basis text NOT NULL,
    service_id bigint,
    scope_kind text,
    scope_value text,
    normalized_value text,
    state text DEFAULT 'candidate'::text NOT NULL,
    source text NOT NULL,
    confidence double precision,
    source_ref text,
    observation_conflict_origin text,
    pre_conflict_state text,
    application_pending boolean DEFAULT true NOT NULL,
    decided_by text,
    decided_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT identity_match_candidates_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT identity_match_candidates_observation_conflict_origin_check CHECK ((observation_conflict_origin = ANY (ARRAY['generated'::text, 'promoted'::text]))),
    CONSTRAINT identity_match_candidates_pre_conflict_state_check CHECK ((pre_conflict_state = ANY (ARRAY['candidate'::text, 'accepted'::text, 'rejected'::text])))
);


--
-- Name: identity_match_candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.identity_match_candidates ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.identity_match_candidates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: identity_match_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_match_evidence (
    id bigint NOT NULL,
    candidate_id bigint NOT NULL,
    evidence_kind text NOT NULL,
    evidence_ref text,
    detail text,
    source text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: identity_match_evidence_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.identity_match_evidence ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.identity_match_evidence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: identity_match_evidence_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_match_evidence_sources (
    evidence_id bigint NOT NULL,
    source_id bigint NOT NULL,
    is_conservative boolean DEFAULT false NOT NULL
);


--
-- Name: identity_match_review_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_match_review_decisions (
    candidate_id bigint NOT NULL,
    evidence_fingerprint text NOT NULL
);


--
-- Name: identity_match_review_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.identity_match_review_receipts (
    candidate_id bigint NOT NULL,
    decision text NOT NULL,
    review_token text NOT NULL,
    evidence_fingerprint text NOT NULL
);


--
-- Name: imap_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imap_drafts (
    draft_id text NOT NULL,
    source_id bigint NOT NULL,
    current_message_id bigint NOT NULL,
    current_mailbox text NOT NULL,
    current_uidvalidity bigint NOT NULL,
    current_uid bigint NOT NULL,
    revision bigint NOT NULL,
    discarded_at timestamp with time zone,
    pending_operation text,
    pending_original_message_id bigint,
    pending_original_mailbox text,
    pending_original_uidvalidity bigint,
    pending_original_uid bigint,
    pending_raw bytea,
    pending_replacement_mailbox text,
    pending_replacement_uidvalidity bigint,
    pending_replacement_uid bigint,
    pending_code text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by_principal text,
    CONSTRAINT imap_drafts_check CHECK ((((pending_operation IS NULL) AND (pending_original_message_id IS NULL) AND (pending_original_mailbox IS NULL) AND (pending_original_uidvalidity IS NULL) AND (pending_original_uid IS NULL) AND (pending_raw IS NULL) AND (pending_replacement_mailbox IS NULL) AND (pending_replacement_uidvalidity IS NULL) AND (pending_replacement_uid IS NULL) AND (pending_code IS NULL)) OR ((pending_operation IS NOT NULL) AND (pending_operation = ANY (ARRAY['edit'::text, 'delete'::text])) AND (pending_original_message_id IS NOT NULL) AND (pending_original_mailbox IS NOT NULL) AND (pending_original_uidvalidity IS NOT NULL) AND (pending_original_uidvalidity > 0) AND (pending_original_uid IS NOT NULL) AND (pending_original_uid > 0) AND (((pending_operation = 'edit'::text) AND (pending_raw IS NOT NULL) AND (length(pending_raw) > 0)) OR ((pending_operation = 'delete'::text) AND (pending_raw IS NULL))) AND ((pending_operation = 'edit'::text) OR ((pending_replacement_mailbox IS NULL) AND (pending_replacement_uidvalidity IS NULL) AND (pending_replacement_uid IS NULL)))))),
    CONSTRAINT imap_drafts_check1 CHECK (((discarded_at IS NULL) OR (pending_operation IS NULL))),
    CONSTRAINT imap_drafts_check2 CHECK (((current_uidvalidity > 0) AND (current_uid > 0))),
    CONSTRAINT imap_drafts_check3 CHECK ((((pending_replacement_mailbox IS NULL) AND (pending_replacement_uidvalidity IS NULL) AND (pending_replacement_uid IS NULL)) OR ((pending_replacement_mailbox IS NOT NULL) AND (pending_replacement_uidvalidity IS NOT NULL) AND (pending_replacement_uidvalidity > 0) AND (pending_replacement_uid IS NOT NULL) AND (pending_replacement_uid > 0)))),
    CONSTRAINT imap_drafts_revision_check CHECK ((revision > 0))
);


--
-- Name: imap_folder_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imap_folder_state (
    source_id bigint NOT NULL,
    mailbox text NOT NULL,
    uidvalidity bigint NOT NULL,
    uidnext bigint NOT NULL,
    highest_modseq numeric(20,0) DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: imap_message_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imap_message_memberships (
    source_id bigint NOT NULL,
    mailbox text NOT NULL,
    uidvalidity bigint NOT NULL,
    uid bigint NOT NULL,
    message_id bigint NOT NULL,
    flags jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labels (
    id bigint NOT NULL,
    source_id bigint,
    source_label_id text,
    name text NOT NULL,
    label_type text,
    system_role text,
    color text
);


--
-- Name: labels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.labels ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.labels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mcp_event_clock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_event_clock (
    singleton smallint NOT NULL,
    head_seq bigint DEFAULT 0 NOT NULL,
    pruned_through_seq bigint DEFAULT 0 NOT NULL,
    capture_epoch bigint DEFAULT 0 NOT NULL,
    epoch_started_at text DEFAULT ''::text NOT NULL,
    coverage_fingerprint text DEFAULT ''::text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    CONSTRAINT mcp_event_clock_capture_epoch_check CHECK ((capture_epoch >= 0)),
    CONSTRAINT mcp_event_clock_head_seq_check CHECK ((head_seq >= 0)),
    CONSTRAINT mcp_event_clock_pruned_through_seq_check CHECK ((pruned_through_seq >= 0)),
    CONSTRAINT mcp_event_clock_singleton_check CHECK ((singleton = 1))
);


--
-- Name: mcp_event_dead_letters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_event_dead_letters (
    subscription_id text NOT NULL,
    seq bigint NOT NULL,
    attempts bigint NOT NULL,
    last_status_class text NOT NULL,
    failed_at text NOT NULL,
    CONSTRAINT mcp_event_dead_letters_attempts_check CHECK (((attempts >= 1) AND (attempts <= 12)))
);


--
-- Name: mcp_event_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_event_log (
    seq bigint NOT NULL,
    epoch bigint NOT NULL,
    family text NOT NULL,
    kind text NOT NULL,
    scope_kind text NOT NULL,
    scope_id bigint NOT NULL,
    item_key text NOT NULL,
    message_id bigint,
    message_reference_seq bigint,
    conversation_id bigint NOT NULL,
    source_id bigint NOT NULL,
    attachment_id bigint,
    from_me boolean NOT NULL,
    occurred_at text NOT NULL,
    recorded_at text NOT NULL,
    data text NOT NULL,
    CONSTRAINT mcp_event_log_data_check CHECK ((jsonb_typeof((data)::jsonb) = 'object'::text)),
    CONSTRAINT mcp_event_log_seq_check CHECK ((seq > 0))
);


--
-- Name: mcp_event_message_refs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_event_message_refs (
    message_id bigint NOT NULL,
    reference_seq bigint NOT NULL,
    CONSTRAINT mcp_event_message_refs_reference_seq_check CHECK ((reference_seq > 0))
);


--
-- Name: mcp_event_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_event_subscriptions (
    id text NOT NULL,
    principal_id text NOT NULL,
    name text NOT NULL,
    arguments text NOT NULL,
    scope_kind text NOT NULL,
    scope_id bigint NOT NULL,
    source_id bigint NOT NULL,
    callback_url text NOT NULL,
    secret_enc bytea NOT NULL,
    previous_secret_enc bytea,
    previous_secret_until text,
    secret_revision bigint NOT NULL,
    verified_revision bigint NOT NULL,
    verified_at text NOT NULL,
    generation bigint NOT NULL,
    state text NOT NULL,
    stop_reason text DEFAULT ''::text NOT NULL,
    expires_at text NOT NULL,
    cursor_epoch bigint NOT NULL,
    cursor_seq bigint NOT NULL,
    pending_seq bigint,
    pending_envelope bytea,
    pending_generation bigint,
    attempt_count bigint DEFAULT 0 NOT NULL,
    next_attempt_at text,
    from_me_window_start text,
    from_me_window_count bigint DEFAULT 0 NOT NULL,
    loop_guard_skips bigint DEFAULT 0 NOT NULL,
    dead_letter_count bigint DEFAULT 0 NOT NULL,
    last_outcome text DEFAULT ''::text NOT NULL,
    created_at text NOT NULL,
    updated_at text NOT NULL,
    CONSTRAINT mcp_event_subscriptions_attempt_count_check CHECK (((attempt_count >= 0) AND (attempt_count <= 12))),
    CONSTRAINT mcp_event_subscriptions_check CHECK ((((pending_seq IS NULL) AND (pending_envelope IS NULL) AND (pending_generation IS NULL)) OR ((pending_seq IS NOT NULL) AND (pending_seq > 0) AND (pending_envelope IS NOT NULL) AND (pending_generation IS NOT NULL) AND (pending_generation > 0)))),
    CONSTRAINT mcp_event_subscriptions_cursor_seq_check CHECK ((cursor_seq >= 0)),
    CONSTRAINT mcp_event_subscriptions_dead_letter_count_check CHECK ((dead_letter_count >= 0)),
    CONSTRAINT mcp_event_subscriptions_from_me_window_count_check CHECK ((from_me_window_count >= 0)),
    CONSTRAINT mcp_event_subscriptions_generation_check CHECK ((generation > 0)),
    CONSTRAINT mcp_event_subscriptions_loop_guard_skips_check CHECK ((loop_guard_skips >= 0)),
    CONSTRAINT mcp_event_subscriptions_secret_revision_check CHECK ((secret_revision > 0)),
    CONSTRAINT mcp_event_subscriptions_state_check CHECK ((state = ANY (ARRAY['active'::text, 'expired'::text, 'unsubscribed'::text, 'gone'::text, 'stopped'::text])))
);


--
-- Name: mcp_live_admissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_live_admissions (
    message_id bigint NOT NULL,
    source_id bigint NOT NULL,
    message_reference_seq bigint NOT NULL,
    epoch bigint NOT NULL,
    admitted_at text NOT NULL,
    CONSTRAINT mcp_live_admissions_message_reference_seq_check CHECK ((message_reference_seq > 0))
);


--
-- Name: meeting_action_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_action_items (
    message_id bigint NOT NULL,
    ordinal integer NOT NULL,
    source_id text DEFAULT ''::text NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    assignee_name text DEFAULT ''::text NOT NULL,
    assignee_email text DEFAULT ''::text NOT NULL,
    status text NOT NULL,
    source_status text DEFAULT ''::text NOT NULL,
    due_date text DEFAULT ''::text NOT NULL,
    origin text NOT NULL,
    locator text NOT NULL
);


--
-- Name: meeting_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_details (
    message_id bigint NOT NULL,
    projection_version integer NOT NULL,
    content_hash text NOT NULL,
    content_json text NOT NULL,
    duration_seconds double precision,
    duration_basis text DEFAULT ''::text NOT NULL,
    action_coverage text NOT NULL,
    transcript_state text NOT NULL
);


--
-- Name: message_bodies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_bodies (
    message_id bigint NOT NULL,
    body_text text,
    body_html text
);


--
-- Name: message_embedding_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_embedding_runs (
    id bigint NOT NULL,
    invocation_key text NOT NULL,
    trigger text NOT NULL,
    state text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    error_code text,
    attempted bigint DEFAULT 0 NOT NULL,
    succeeded bigint DEFAULT 0 NOT NULL,
    failed bigint DEFAULT 0 NOT NULL,
    truncated bigint DEFAULT 0 NOT NULL,
    CONSTRAINT message_embedding_runs_attempted_check CHECK ((attempted >= 0)),
    CONSTRAINT message_embedding_runs_check CHECK ((((state = 'running'::text) AND (finished_at IS NULL) AND (error_code IS NULL)) OR ((state <> 'running'::text) AND (finished_at IS NOT NULL)))),
    CONSTRAINT message_embedding_runs_error_code_check CHECK (((error_code IS NULL) OR (error_code = ANY (ARRAY['invocation_cancelled'::text, 'invocation_timeout'::text, 'invocation_rate_limited'::text, 'invocation_authentication_failed'::text, 'invocation_upstream_failed'::text, 'invocation_invalid_output'::text, 'invocation_safety_limit'::text, 'invocation_archive_drift'::text, 'invocation_daemon_restarted'::text, 'invocation_internal'::text, 'invocation_unsafe_error_redacted'::text])))),
    CONSTRAINT message_embedding_runs_failed_check CHECK ((failed >= 0)),
    CONSTRAINT message_embedding_runs_invocation_key_check CHECK ((((octet_length(invocation_key) >= 1) AND (octet_length(invocation_key) <= 128)) AND (btrim(invocation_key) = invocation_key))),
    CONSTRAINT message_embedding_runs_state_check CHECK ((state = ANY (ARRAY['running'::text, 'succeeded'::text, 'partial'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT message_embedding_runs_succeeded_check CHECK ((succeeded >= 0)),
    CONSTRAINT message_embedding_runs_trigger_check CHECK ((trigger = ANY (ARRAY['manual'::text, 'scheduled'::text]))),
    CONSTRAINT message_embedding_runs_truncated_check CHECK ((truncated >= 0))
);


--
-- Name: message_embedding_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.message_embedding_runs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.message_embedding_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: message_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_labels (
    message_id bigint NOT NULL,
    label_id bigint NOT NULL
);


--
-- Name: message_raw; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_raw (
    message_id bigint NOT NULL,
    raw_data bytea NOT NULL,
    raw_format text NOT NULL,
    compression text DEFAULT 'zlib'::text,
    encryption_version integer DEFAULT 0
);


--
-- Name: message_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_recipients (
    id bigint NOT NULL,
    message_id bigint NOT NULL,
    participant_id bigint NOT NULL,
    recipient_type text NOT NULL,
    display_name text,
    email_address text
);


--
-- Name: message_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.message_recipients ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.message_recipients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    source_id bigint NOT NULL,
    source_message_id text,
    rfc822_message_id text,
    list_id text,
    message_type text DEFAULT 'email'::text NOT NULL,
    sent_at timestamp with time zone,
    received_at timestamp with time zone,
    read_at timestamp with time zone,
    delivered_at timestamp with time zone,
    internal_date timestamp with time zone,
    sender_id bigint,
    is_from_me boolean DEFAULT false,
    source_is_from_me boolean,
    identity_is_from_me boolean DEFAULT false NOT NULL,
    subject text,
    snippet text,
    reply_to_message_id bigint,
    thread_position integer,
    is_read boolean DEFAULT true,
    is_delivered boolean,
    is_sent boolean DEFAULT true,
    is_edited boolean DEFAULT false,
    is_forwarded boolean DEFAULT false,
    size_estimate bigint,
    has_attachments boolean DEFAULT false,
    attachment_count integer DEFAULT 0,
    deleted_at timestamp with time zone,
    deleted_from_source_at timestamp with time zone,
    delete_batch_id text,
    archived_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    indexing_version integer DEFAULT 1,
    metadata jsonb,
    last_modified timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    search_fts tsvector,
    embed_gen bigint,
    content_changed_at timestamp with time zone
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.messages ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: operation_history_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operation_history_state (
    singleton integer NOT NULL,
    membership_revision bigint DEFAULT 0 NOT NULL,
    CONSTRAINT operation_history_state_membership_revision_check CHECK ((membership_revision >= 0)),
    CONSTRAINT operation_history_state_singleton_check CHECK ((singleton = 1))
);


--
-- Name: operation_token_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operation_token_keys (
    key_id text NOT NULL,
    key_bytes bytea NOT NULL,
    state text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    retired_at timestamp with time zone,
    CONSTRAINT operation_token_keys_check CHECK ((((state = 'active'::text) AND (retired_at IS NULL)) OR ((state = 'decrypt_only'::text) AND (retired_at IS NOT NULL)))),
    CONSTRAINT operation_token_keys_key_bytes_check CHECK ((octet_length(key_bytes) = 32)),
    CONSTRAINT operation_token_keys_key_id_check CHECK ((key_id ~ '^[a-f0-9]{32}$'::text)),
    CONSTRAINT operation_token_keys_state_check CHECK ((state = ANY (ARRAY['active'::text, 'decrypt_only'::text])))
);


--
-- Name: organization_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_addresses (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    address_kind text DEFAULT 'postal'::text NOT NULL,
    post_office_box text,
    extended_address text,
    street_address text,
    locality text,
    region text,
    postal_code text,
    country_name text,
    extended_components text,
    free_text text,
    label text,
    geo_uri text,
    timezone text,
    country_code text,
    place_uri text,
    original_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT organization_addresses_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT organization_addresses_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: organization_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.organization_addresses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organization_addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: organization_attribute_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_attribute_values (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    definition_id bigint NOT NULL,
    ordinal bigint DEFAULT 0 NOT NULL,
    value_text text,
    value_integer bigint,
    value_real double precision,
    value_boolean boolean,
    value_date text,
    value_timestamp timestamp with time zone,
    value_json jsonb,
    value_record_type text,
    value_record_id bigint,
    active_from timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    source text NOT NULL,
    source_ref text,
    confidence double precision,
    actor text,
    CONSTRAINT organization_attribute_values_check CHECK (((active_until IS NULL) OR (active_until >= active_from))),
    CONSTRAINT organization_attribute_values_check1 CHECK (((((((((
CASE
    WHEN (value_text IS NOT NULL) THEN 1
    ELSE 0
END +
CASE
    WHEN (value_integer IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_real IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_boolean IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_date IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_timestamp IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_json IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_record_id IS NOT NULL) THEN 1
    ELSE 0
END) = 1)),
    CONSTRAINT organization_attribute_values_check2 CHECK (((value_record_id IS NULL) = (value_record_type IS NULL))),
    CONSTRAINT organization_attribute_values_confidence_check CHECK (((confidence IS NULL) OR ((confidence >= (0.0)::double precision) AND (confidence <= (1.0)::double precision)))),
    CONSTRAINT organization_attribute_values_ordinal_check CHECK ((ordinal >= 0)),
    CONSTRAINT organization_attribute_values_value_date_check CHECK (((value_date IS NULL) OR (value_date ~~ '____-__-__'::text)))
);


--
-- Name: organization_attribute_values_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.organization_attribute_values ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organization_attribute_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: organization_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_categories (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    original_value text NOT NULL,
    normalized_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT organization_categories_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT organization_categories_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: organization_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.organization_categories ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organization_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: organization_contact_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_contact_points (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    address_kind text NOT NULL,
    service_id bigint,
    scope_kind text,
    scope_value text,
    original_value text NOT NULL,
    normalized_value text NOT NULL,
    normalization text DEFAULT 'none'::text NOT NULL,
    normalization_version integer DEFAULT 1 NOT NULL,
    uri text,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT organization_contact_points_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT organization_contact_points_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: organization_contact_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.organization_contact_points ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organization_contact_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: organization_identifiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_identifiers (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    identifier_kind text NOT NULL,
    identifier_value text NOT NULL,
    normalized_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT organization_identifiers_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT organization_identifiers_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: organization_identifiers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.organization_identifiers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organization_identifiers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: organization_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_media (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    media_kind text NOT NULL,
    media_type text,
    uri text,
    data bytea,
    byte_size bigint,
    content_hash text,
    original_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT organization_media_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT organization_media_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: organization_media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.organization_media ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organization_media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: organization_names; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization_names (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    name_kind text NOT NULL,
    formatted text,
    original_value text NOT NULL,
    name_normalized text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT organization_names_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT organization_names_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: organization_names_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.organization_names ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organization_names_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organizations (
    id bigint NOT NULL,
    name text NOT NULL,
    name_normalized text NOT NULL,
    kind text DEFAULT 'other'::text NOT NULL,
    primary_domain text,
    description text,
    revision bigint DEFAULT 1 NOT NULL,
    merged_into_id bigint,
    retired_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT organizations_check CHECK (((merged_into_id IS NULL) OR (merged_into_id <> id))),
    CONSTRAINT organizations_name_check CHECK ((length(name) > 0))
);


--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.organizations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.organizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: participant_contact_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participant_contact_observations (
    id bigint NOT NULL,
    participant_id bigint NOT NULL,
    source_id bigint,
    address_kind text NOT NULL,
    service_id bigint,
    scope_kind text,
    scope_value text,
    provider_user_id text,
    original_value text NOT NULL,
    normalized_value text NOT NULL,
    normalization text DEFAULT 'none'::text NOT NULL,
    normalization_version integer DEFAULT 1 NOT NULL,
    observed_at timestamp with time zone,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT participant_contact_observations_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT participant_contact_observations_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: participant_contact_observations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.participant_contact_observations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.participant_contact_observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: participant_identifiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participant_identifiers (
    id bigint NOT NULL,
    participant_id bigint NOT NULL,
    identifier_type text NOT NULL,
    identifier_value text NOT NULL,
    display_value text,
    is_primary boolean DEFAULT false,
    service_id bigint,
    scope_kind text,
    scope_value text
);


--
-- Name: participant_identifiers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.participant_identifiers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.participant_identifiers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: participant_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participant_links (
    participant_a bigint NOT NULL,
    participant_b bigint NOT NULL,
    identity_match_candidate_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT participant_links_check CHECK ((participant_a < participant_b))
);


--
-- Name: participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.participants (
    id bigint NOT NULL,
    email_address text,
    phone_number text,
    display_name text,
    domain text,
    canonical_id text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: participants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.participants ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_addresses (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    address_kind text DEFAULT 'postal'::text NOT NULL,
    post_office_box text,
    extended_address text,
    street_address text,
    locality text,
    region text,
    postal_code text,
    country_name text,
    extended_components text,
    free_text text,
    label text,
    geo_uri text,
    timezone text,
    country_code text,
    place_uri text,
    original_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT person_addresses_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT person_addresses_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: person_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_addresses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_attribute_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_attribute_values (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    definition_id bigint NOT NULL,
    ordinal bigint DEFAULT 0 NOT NULL,
    value_text text,
    value_integer bigint,
    value_real double precision,
    value_boolean boolean,
    value_date text,
    value_timestamp timestamp with time zone,
    value_json jsonb,
    value_record_type text,
    value_record_id bigint,
    active_from timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    source text NOT NULL,
    source_ref text,
    confidence double precision,
    actor text,
    CONSTRAINT person_attribute_values_check CHECK (((active_until IS NULL) OR (active_until >= active_from))),
    CONSTRAINT person_attribute_values_check1 CHECK (((((((((
CASE
    WHEN (value_text IS NOT NULL) THEN 1
    ELSE 0
END +
CASE
    WHEN (value_integer IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_real IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_boolean IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_date IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_timestamp IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_json IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (value_record_id IS NOT NULL) THEN 1
    ELSE 0
END) = 1)),
    CONSTRAINT person_attribute_values_check2 CHECK (((value_record_id IS NULL) = (value_record_type IS NULL))),
    CONSTRAINT person_attribute_values_confidence_check CHECK (((confidence IS NULL) OR ((confidence >= (0.0)::double precision) AND (confidence <= (1.0)::double precision)))),
    CONSTRAINT person_attribute_values_ordinal_check CHECK ((ordinal >= 0)),
    CONSTRAINT person_attribute_values_value_date_check CHECK (((value_date IS NULL) OR (value_date ~~ '____-__-__'::text)))
);


--
-- Name: person_attribute_values_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_attribute_values ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_attribute_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_brief_enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_brief_enrollments (
    person_id bigint NOT NULL,
    enabled_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    actor text NOT NULL
);


--
-- Name: person_brief_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_brief_evidence (
    brief_id bigint NOT NULL,
    evidence_id bigint NOT NULL,
    ordinal integer NOT NULL,
    CONSTRAINT person_brief_evidence_ordinal_check CHECK ((ordinal >= 0))
);


--
-- Name: person_briefs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_briefs (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    version integer NOT NULL,
    generation_id bigint NOT NULL,
    status text NOT NULL,
    program_id text NOT NULL,
    program_version text NOT NULL,
    program_fingerprint text NOT NULL,
    provider text NOT NULL,
    provider_version text NOT NULL,
    model text NOT NULL,
    model_version text NOT NULL,
    provider_policy_fingerprint text NOT NULL,
    boundary_json jsonb NOT NULL,
    structured_json jsonb NOT NULL,
    rendered_text text NOT NULL,
    renderer_policy text NOT NULL,
    dropped_item_count integer DEFAULT 0 NOT NULL,
    generated_at timestamp with time zone NOT NULL,
    superseded_at timestamp with time zone,
    rejected_at timestamp with time zone,
    rejected_reason text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_briefs_dropped_item_count_check CHECK ((dropped_item_count >= 0)),
    CONSTRAINT person_briefs_status_check CHECK ((status = ANY (ARRAY['current'::text, 'superseded'::text, 'rejected'::text]))),
    CONSTRAINT person_briefs_version_check CHECK ((version >= 1))
);


--
-- Name: person_briefs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_briefs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_briefs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_carddav_inference_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_carddav_inference_state (
    person_id bigint NOT NULL,
    inference_revision bigint DEFAULT 0 NOT NULL,
    approved_revision bigint DEFAULT 0 NOT NULL,
    approved_connection_generation bigint,
    approved_address_book_id bigint,
    CONSTRAINT person_carddav_inference_state_check CHECK (((approved_revision >= 0) AND (approved_revision <= inference_revision))),
    CONSTRAINT person_carddav_inference_state_check1 CHECK (((approved_connection_generation IS NULL) = (approved_address_book_id IS NULL))),
    CONSTRAINT person_carddav_inference_state_inference_revision_check CHECK ((inference_revision >= 0))
);


--
-- Name: person_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_categories (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    original_value text NOT NULL,
    normalized_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT person_categories_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT person_categories_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: person_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_categories ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_contact_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_contact_points (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    address_kind text NOT NULL,
    service_id bigint,
    scope_kind text,
    scope_value text,
    original_value text NOT NULL,
    normalized_value text NOT NULL,
    normalization text DEFAULT 'none'::text NOT NULL,
    normalization_version integer DEFAULT 1 NOT NULL,
    uri text,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT person_contact_points_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT person_contact_points_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: person_contact_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_contact_points ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_contact_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_contact_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_contact_state (
    person_id bigint NOT NULL,
    first_contact_at timestamp with time zone,
    first_contact_message_id bigint,
    last_contact_at timestamp with time zone,
    last_contact_message_id bigint,
    last_contact_channel text,
    last_contact_source_id bigint,
    last_contact_owner text,
    last_inbound_at timestamp with time zone,
    last_inbound_message_id bigint,
    last_outbound_at timestamp with time zone,
    last_outbound_message_id bigint,
    interaction_count bigint DEFAULT 0 NOT NULL,
    identity_revision bigint DEFAULT 0 NOT NULL,
    account_identity_revision bigint DEFAULT 0 NOT NULL,
    dirty_at timestamp with time zone,
    computed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_contact_state_account_identity_revision_check CHECK ((account_identity_revision >= 0)),
    CONSTRAINT person_contact_state_identity_revision_check CHECK ((identity_revision >= 0)),
    CONSTRAINT person_contact_state_interaction_count_check CHECK ((interaction_count >= 0)),
    CONSTRAINT person_contact_state_last_contact_channel_check CHECK (((last_contact_channel IS NULL) OR (last_contact_channel = ANY (ARRAY['email'::text, 'chat'::text, 'meeting'::text, 'other'::text]))))
);


--
-- Name: person_dates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_dates (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    date_kind text NOT NULL,
    label text,
    date_year integer,
    date_month integer,
    date_day integer,
    date_text text,
    calendar_scale text,
    original_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT person_dates_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT person_dates_check1 CHECK (((date_day IS NULL) OR (date_month IS NOT NULL) OR (date_year IS NULL))),
    CONSTRAINT person_dates_date_day_check CHECK (((date_day >= 1) AND (date_day <= 31))),
    CONSTRAINT person_dates_date_month_check CHECK (((date_month >= 1) AND (date_month <= 12))),
    CONSTRAINT person_dates_date_year_check CHECK (((date_year >= 1) AND (date_year <= 9999))),
    CONSTRAINT person_dates_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: person_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_dates ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_dates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_embedding_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_embedding_runs (
    id bigint NOT NULL,
    invocation_key text NOT NULL,
    trigger text NOT NULL,
    state text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    error_code text,
    attempted bigint DEFAULT 0 NOT NULL,
    succeeded bigint DEFAULT 0 NOT NULL,
    failed bigint DEFAULT 0 NOT NULL,
    truncated bigint DEFAULT 0 NOT NULL,
    CONSTRAINT person_embedding_runs_attempted_check CHECK ((attempted >= 0)),
    CONSTRAINT person_embedding_runs_check CHECK ((((state = 'running'::text) AND (finished_at IS NULL) AND (error_code IS NULL)) OR ((state <> 'running'::text) AND (finished_at IS NOT NULL)))),
    CONSTRAINT person_embedding_runs_error_code_check CHECK (((error_code IS NULL) OR (error_code = ANY (ARRAY['invocation_cancelled'::text, 'invocation_timeout'::text, 'invocation_rate_limited'::text, 'invocation_authentication_failed'::text, 'invocation_upstream_failed'::text, 'invocation_invalid_output'::text, 'invocation_safety_limit'::text, 'invocation_archive_drift'::text, 'invocation_daemon_restarted'::text, 'invocation_internal'::text, 'invocation_unsafe_error_redacted'::text])))),
    CONSTRAINT person_embedding_runs_failed_check CHECK ((failed >= 0)),
    CONSTRAINT person_embedding_runs_invocation_key_check CHECK ((((octet_length(invocation_key) >= 1) AND (octet_length(invocation_key) <= 128)) AND (btrim(invocation_key) = invocation_key))),
    CONSTRAINT person_embedding_runs_state_check CHECK ((state = ANY (ARRAY['running'::text, 'succeeded'::text, 'partial'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT person_embedding_runs_succeeded_check CHECK ((succeeded >= 0)),
    CONSTRAINT person_embedding_runs_trigger_check CHECK ((trigger = ANY (ARRAY['manual'::text, 'scheduled'::text]))),
    CONSTRAINT person_embedding_runs_truncated_check CHECK ((truncated >= 0))
);


--
-- Name: person_embedding_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_embedding_runs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_embedding_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_enrichment_attempt_citations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_attempt_citations (
    attempt_id bigint NOT NULL,
    citation_id bigint NOT NULL
);


--
-- Name: person_enrichment_attempt_identifiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_attempt_identifiers (
    attempt_id bigint NOT NULL,
    provider_namespace text NOT NULL,
    identifier_class text NOT NULL,
    normalization_version text NOT NULL,
    key_id text NOT NULL,
    digest bytea NOT NULL,
    CONSTRAINT person_enrichment_attempt_identifiers_identifier_class_check CHECK ((identifier_class = ANY (ARRAY['email'::text, 'phone'::text, 'public_profile_url'::text, 'provider_person_id'::text, 'name_company'::text])))
);


--
-- Name: person_enrichment_attempt_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_attempt_sources (
    attempt_id bigint NOT NULL,
    canonical_url text NOT NULL,
    outcome text NOT NULL,
    observed_at timestamp with time zone NOT NULL,
    CONSTRAINT person_enrichment_attempt_sources_outcome_check CHECK ((outcome = ANY (ARRAY['cited'::text, 'visited'::text, 'failed'::text, 'blocked'::text, 'unsupported'::text])))
);


--
-- Name: person_enrichment_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_attempts (
    id bigint NOT NULL,
    run_id bigint NOT NULL,
    person_id bigint NOT NULL,
    profile_fingerprint text NOT NULL,
    trigger_kind text NOT NULL,
    trigger_generation text NOT NULL,
    person_revision bigint NOT NULL,
    payload_hash text NOT NULL,
    request_hash text NOT NULL,
    fact_generation_key text,
    state text NOT NULL,
    provider_request_id text,
    provider_job_id text,
    adapter_version text,
    schema_version text,
    generated_schema boolean DEFAULT false NOT NULL,
    generated_schema_hash text,
    targets_json text,
    program_fingerprint text,
    provider_started_at timestamp with time zone,
    dispatch_authorized_at timestamp with time zone,
    lease_owner text,
    lease_fence bigint NOT NULL,
    lease_until timestamp with time zone,
    next_action_at timestamp with time zone,
    attempt_count bigint DEFAULT 0 NOT NULL,
    hard_cost_cap_enforced boolean NOT NULL,
    reserved_cost_usd_micros bigint NOT NULL,
    actual_cost_usd_micros bigint,
    failure_class text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT person_enrichment_attempts_actual_cost_usd_micros_check CHECK ((actual_cost_usd_micros >= 0)),
    CONSTRAINT person_enrichment_attempts_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT person_enrichment_attempts_check CHECK (((generated_schema AND (generated_schema_hash IS NOT NULL)) OR ((NOT generated_schema) AND (generated_schema_hash IS NULL)))),
    CONSTRAINT person_enrichment_attempts_lease_fence_check CHECK ((lease_fence >= 0)),
    CONSTRAINT person_enrichment_attempts_person_revision_check CHECK ((person_revision >= 0)),
    CONSTRAINT person_enrichment_attempts_reserved_cost_usd_micros_check CHECK ((reserved_cost_usd_micros >= 0)),
    CONSTRAINT person_enrichment_attempts_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'starting'::text, 'pending'::text, 'retry_wait'::text, 'succeeded'::text, 'terminal'::text, 'suppressed'::text, 'identity_rejected'::text, 'uncertain_start'::text]))),
    CONSTRAINT person_enrichment_attempts_trigger_kind_check CHECK ((trigger_kind = ANY (ARRAY['tracked'::text, 'identity'::text, 'claim_expiry'::text, 'refresh'::text, 'manual'::text])))
);


--
-- Name: person_enrichment_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_enrichment_attempts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_enrichment_attempts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_enrichment_citations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_citations (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    citation_key text NOT NULL,
    canonical_url text NOT NULL,
    title text NOT NULL,
    publisher text NOT NULL,
    excerpt text NOT NULL,
    published_at timestamp with time zone,
    retrieved_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: person_enrichment_citations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_enrichment_citations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_enrichment_citations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_enrichment_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_consents (
    id bigint NOT NULL,
    profile_fingerprint text NOT NULL,
    granted_by text NOT NULL,
    granted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_by text,
    revoked_at timestamp with time zone,
    CONSTRAINT person_enrichment_consents_check CHECK (((revoked_by IS NULL) = (revoked_at IS NULL)))
);


--
-- Name: person_enrichment_consents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_enrichment_consents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_enrichment_consents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_enrichment_day_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_day_counters (
    profile_fingerprint text NOT NULL,
    utc_day text NOT NULL,
    requests_started bigint DEFAULT 0 NOT NULL,
    cost_reserved_usd_micros bigint DEFAULT 0 NOT NULL,
    cost_charged_usd_micros bigint DEFAULT 0 NOT NULL,
    CONSTRAINT person_enrichment_day_counters_cost_charged_usd_micros_check CHECK ((cost_charged_usd_micros >= 0)),
    CONSTRAINT person_enrichment_day_counters_cost_reserved_usd_micros_check CHECK ((cost_reserved_usd_micros >= 0)),
    CONSTRAINT person_enrichment_day_counters_requests_started_check CHECK ((requests_started >= 0))
);


--
-- Name: person_enrichment_manual_run_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_manual_run_targets (
    run_id bigint NOT NULL,
    person_id bigint NOT NULL,
    profile_fingerprint text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_enrichment_manual_run_targets_person_id_check CHECK ((person_id > 0))
);


--
-- Name: person_enrichment_person_day_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_person_day_counters (
    person_id bigint NOT NULL,
    profile_fingerprint text NOT NULL,
    utc_day text NOT NULL,
    requests_started bigint DEFAULT 0 NOT NULL,
    cost_reserved_usd_micros bigint DEFAULT 0 NOT NULL,
    cost_charged_usd_micros bigint DEFAULT 0 NOT NULL,
    CONSTRAINT person_enrichment_person_day_cou_cost_reserved_usd_micros_check CHECK ((cost_reserved_usd_micros >= 0)),
    CONSTRAINT person_enrichment_person_day_coun_cost_charged_usd_micros_check CHECK ((cost_charged_usd_micros >= 0)),
    CONSTRAINT person_enrichment_person_day_counters_requests_started_check CHECK ((requests_started >= 0))
);


--
-- Name: person_enrichment_profile_accounting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_profile_accounting (
    profile_fingerprint text NOT NULL,
    starts_disabled boolean DEFAULT false NOT NULL,
    safe_error text,
    disabled_at timestamp with time zone
);


--
-- Name: person_enrichment_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_profiles (
    fingerprint text NOT NULL,
    provider_name text NOT NULL,
    provider_kind text NOT NULL,
    provider_namespace text NOT NULL,
    endpoint text NOT NULL,
    api_key_env text NOT NULL,
    policy_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_enrichment_profiles_provider_kind_check CHECK ((provider_kind = ANY (ARRAY['exa'::text, 'sixtyfour'::text])))
);


--
-- Name: person_enrichment_provider_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_provider_identities (
    person_id bigint NOT NULL,
    provider_namespace text NOT NULL,
    provider_person_id text NOT NULL,
    confidence integer NOT NULL,
    verified_at timestamp with time zone NOT NULL,
    CONSTRAINT person_enrichment_provider_identities_confidence_check CHECK (((confidence >= 0) AND (confidence <= 1000)))
);


--
-- Name: person_enrichment_run_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_run_counters (
    run_id bigint NOT NULL,
    requests_started bigint DEFAULT 0 NOT NULL,
    cost_reserved_usd_micros bigint DEFAULT 0 NOT NULL,
    cost_charged_usd_micros bigint DEFAULT 0 NOT NULL,
    CONSTRAINT person_enrichment_run_counters_cost_charged_usd_micros_check CHECK ((cost_charged_usd_micros >= 0)),
    CONSTRAINT person_enrichment_run_counters_cost_reserved_usd_micros_check CHECK ((cost_reserved_usd_micros >= 0)),
    CONSTRAINT person_enrichment_run_counters_requests_started_check CHECK ((requests_started >= 0))
);


--
-- Name: person_enrichment_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_runs (
    id bigint NOT NULL,
    kind text NOT NULL,
    requested_by text NOT NULL,
    requested_at timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    state text NOT NULL,
    requested_count bigint DEFAULT 0 NOT NULL,
    started_count bigint DEFAULT 0 NOT NULL,
    succeeded_count bigint DEFAULT 0 NOT NULL,
    failed_count bigint DEFAULT 0 NOT NULL,
    suppressed_count bigint DEFAULT 0 NOT NULL,
    identity_rejected_count bigint DEFAULT 0 NOT NULL,
    failure_class text,
    safe_error text,
    CONSTRAINT person_enrichment_runs_failed_count_check CHECK ((failed_count >= 0)),
    CONSTRAINT person_enrichment_runs_identity_rejected_count_check CHECK ((identity_rejected_count >= 0)),
    CONSTRAINT person_enrichment_runs_kind_check CHECK ((kind = ANY (ARRAY['scheduled'::text, 'manual'::text]))),
    CONSTRAINT person_enrichment_runs_requested_count_check CHECK ((requested_count >= 0)),
    CONSTRAINT person_enrichment_runs_started_count_check CHECK ((started_count >= 0)),
    CONSTRAINT person_enrichment_runs_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'running'::text, 'succeeded'::text, 'partial'::text, 'failed'::text]))),
    CONSTRAINT person_enrichment_runs_succeeded_count_check CHECK ((succeeded_count >= 0)),
    CONSTRAINT person_enrichment_runs_suppressed_count_check CHECK ((suppressed_count >= 0))
);


--
-- Name: person_enrichment_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_enrichment_runs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_enrichment_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_enrichment_suppressions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_suppressions (
    id bigint NOT NULL,
    provider_namespace text NOT NULL,
    identifier_class text NOT NULL,
    normalization_version text NOT NULL,
    key_id text NOT NULL,
    digest bytea NOT NULL,
    reason text NOT NULL,
    actor text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_enrichment_suppressions_identifier_class_check CHECK ((identifier_class = ANY (ARRAY['email'::text, 'phone'::text, 'public_profile_url'::text, 'provider_person_id'::text, 'name_company'::text]))),
    CONSTRAINT person_enrichment_suppressions_reason_check CHECK ((reason = ANY (ARRAY['deletion'::text, 'opt_out'::text, 'data_subject_request'::text])))
);


--
-- Name: person_enrichment_suppressions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_enrichment_suppressions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_enrichment_suppressions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_enrichment_work; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_enrichment_work (
    person_id bigint NOT NULL,
    profile_fingerprint text NOT NULL,
    trigger_mask bigint NOT NULL,
    trigger_generation text NOT NULL,
    due_at timestamp with time zone NOT NULL,
    lease_owner text,
    lease_fence bigint DEFAULT 0 NOT NULL,
    lease_until timestamp with time zone,
    run_id bigint,
    active_attempt_id bigint,
    has_fresh_trigger boolean DEFAULT false NOT NULL,
    CONSTRAINT person_enrichment_work_check CHECK (((lease_owner IS NULL) = (lease_until IS NULL))),
    CONSTRAINT person_enrichment_work_lease_fence_check CHECK ((lease_fence >= 0)),
    CONSTRAINT person_enrichment_work_trigger_mask_check CHECK ((trigger_mask > 0))
);


--
-- Name: person_fact_claim_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_fact_claim_evidence (
    claim_id bigint NOT NULL,
    evidence_id bigint NOT NULL
);


--
-- Name: person_fact_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_fact_claims (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    generation_id bigint NOT NULL,
    claim_key text NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    target_revision text NOT NULL,
    relation text NOT NULL,
    submitted_value_json text NOT NULL,
    normalized_value_json jsonb,
    value_fingerprint text,
    valid_from timestamp with time zone,
    valid_until timestamp with time zone,
    origin text NOT NULL,
    confidence_json jsonb NOT NULL,
    rejection_action text,
    rejection_reason text,
    rejection_detail text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_fact_claims_check CHECK ((((rejection_action IS NULL) AND (rejection_reason IS NULL) AND (rejection_detail IS NULL)) OR ((rejection_action IS NOT NULL) AND (rejection_reason IS NOT NULL) AND (rejection_detail IS NOT NULL) AND (rejection_detail <> ''::text)))),
    CONSTRAINT person_fact_claims_check1 CHECK (((normalized_value_json IS NULL) = (value_fingerprint IS NULL))),
    CONSTRAINT person_fact_claims_check2 CHECK (((valid_from IS NULL) OR (valid_until IS NULL) OR (valid_until >= valid_from))),
    CONSTRAINT person_fact_claims_origin_check CHECK ((origin = ANY (ARRAY['extraction'::text, 'enrichment'::text, 'brief'::text, 'system'::text, 'invalid'::text]))),
    CONSTRAINT person_fact_claims_rejection_action_check CHECK ((rejection_action = ANY (ARRAY['applied'::text, 'retained'::text, 'superseded'::text, 'invalid'::text, 'identity-rejected'::text, 'policy-rejected'::text, 'conflict-rejected'::text, 'ambiguous-retained'::text]))),
    CONSTRAINT person_fact_claims_rejection_reason_check CHECK ((rejection_reason = ANY (ARRAY['malformed-value'::text, 'unsupported-target'::text, 'stale-target-revision'::text, 'unaligned-evidence'::text, 'identity-mismatch'::text, 'sensitive-policy'::text, 'pin-retained'::text, 'below-threshold'::text, 'insufficient-margin'::text, 'competing-tie'::text, 'explicit-contradiction'::text, 'explicit-supersession'::text, 'organization-ambiguous'::text, 'applied-projection'::text, 'evidence-unsupported'::text, 'outside-validity'::text]))),
    CONSTRAINT person_fact_claims_relation_check CHECK ((relation = ANY (ARRAY['support'::text, 'contradict'::text, 'supersede'::text, 'invalid'::text])))
);


--
-- Name: person_fact_claims_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_fact_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_fact_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_fact_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_fact_decisions (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    resolution_id bigint NOT NULL,
    claim_id bigint,
    decision_key text NOT NULL,
    action text NOT NULL,
    reason text NOT NULL,
    score_json jsonb NOT NULL,
    competing_claim_id bigint,
    projection_kind text,
    projection_row_id bigint,
    resolved_organization_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_fact_decisions_action_check CHECK ((action = ANY (ARRAY['applied'::text, 'retained'::text, 'superseded'::text, 'invalid'::text, 'identity-rejected'::text, 'policy-rejected'::text, 'conflict-rejected'::text, 'ambiguous-retained'::text]))),
    CONSTRAINT person_fact_decisions_check CHECK (((projection_kind IS NULL) = (projection_row_id IS NULL))),
    CONSTRAINT person_fact_decisions_reason_check CHECK ((reason = ANY (ARRAY['malformed-value'::text, 'unsupported-target'::text, 'stale-target-revision'::text, 'unaligned-evidence'::text, 'identity-mismatch'::text, 'sensitive-policy'::text, 'pin-retained'::text, 'below-threshold'::text, 'insufficient-margin'::text, 'competing-tie'::text, 'explicit-contradiction'::text, 'explicit-supersession'::text, 'organization-ambiguous'::text, 'applied-projection'::text, 'evidence-unsupported'::text, 'outside-validity'::text])))
);


--
-- Name: person_fact_decisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_fact_decisions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_fact_decisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_fact_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_fact_evidence (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    evidence_key text NOT NULL,
    source_class text NOT NULL,
    directness text NOT NULL,
    authority text NOT NULL,
    source_ref text DEFAULT ''::text NOT NULL,
    source_url text DEFAULT ''::text NOT NULL,
    subject_person_id bigint,
    subject_ref text DEFAULT ''::text NOT NULL,
    span_start bigint,
    span_end bigint,
    excerpt text DEFAULT ''::text NOT NULL,
    content_sha256 text DEFAULT ''::text NOT NULL,
    source_version text DEFAULT ''::text NOT NULL,
    event_time timestamp with time zone NOT NULL,
    recorded_time timestamp with time zone NOT NULL,
    identity_score integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_fact_evidence_authority_check CHECK ((authority = ANY (ARRAY['authoritative'::text, 'ordinary'::text, 'aggregator'::text]))),
    CONSTRAINT person_fact_evidence_check CHECK (((span_start IS NULL) = (span_end IS NULL))),
    CONSTRAINT person_fact_evidence_check1 CHECK (((span_start IS NULL) OR ((span_start >= 0) AND (span_end >= span_start)))),
    CONSTRAINT person_fact_evidence_directness_check CHECK ((directness = ANY (ARRAY['direct-self'::text, 'direct-other'::text, 'indirect'::text]))),
    CONSTRAINT person_fact_evidence_identity_score_check CHECK (((identity_score >= 0) AND (identity_score <= 1000))),
    CONSTRAINT person_fact_evidence_source_class_check CHECK ((source_class = ANY (ARRAY['archive'::text, 'public'::text, 'system'::text, 'provider_assertion'::text])))
);


--
-- Name: person_fact_evidence_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_fact_evidence ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_fact_evidence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_fact_evidence_status_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_fact_evidence_status_events (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    generation_id bigint NOT NULL,
    evidence_id bigint NOT NULL,
    evidence_key text NOT NULL,
    source_version text NOT NULL,
    supported boolean NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_fact_evidence_status_events_reason_check CHECK ((reason = ANY (ARRAY['source-deleted'::text, 'source-edited'::text, 'scope-unlinked'::text, 'identity-reassigned'::text, 'source-reimported'::text, 'scope-relinked'::text])))
);


--
-- Name: person_fact_evidence_status_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_fact_evidence_status_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_fact_evidence_status_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_fact_generations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_fact_generations (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    generation_key text NOT NULL,
    source_cursors_json jsonb NOT NULL,
    program_id text NOT NULL,
    program_version text NOT NULL,
    program_fingerprint text NOT NULL,
    catalog_fingerprint text NOT NULL,
    provider text NOT NULL,
    provider_version text NOT NULL,
    model text NOT NULL,
    model_version text NOT NULL,
    provider_policy_fingerprint text NOT NULL,
    resolved_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_fact_generations_program_fingerprint_check CHECK ((program_fingerprint ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: person_fact_generations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_fact_generations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_fact_generations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_fact_pin_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_fact_pin_events (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    target_revision text NOT NULL,
    pinned boolean NOT NULL,
    actor text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_fact_pin_events_target_kind_check CHECK ((target_kind = ANY (ARRAY['attribute'::text, 'employment'::text])))
);


--
-- Name: person_fact_pin_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_fact_pin_events ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_fact_pin_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_fact_resolutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_fact_resolutions (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    generation_id bigint NOT NULL,
    target_kind text NOT NULL,
    target_key text NOT NULL,
    target_revision text NOT NULL,
    resolver_version text NOT NULL,
    input_fingerprint text NOT NULL,
    provider_policy_fingerprint text NOT NULL,
    resolved_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: person_fact_resolutions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_fact_resolutions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_fact_resolutions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_inference_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_inference_checks (
    profile_fingerprint text NOT NULL,
    checked_at timestamp with time zone NOT NULL,
    driver_version text NOT NULL,
    output_mode text NOT NULL,
    provider_request_id text DEFAULT ''::text NOT NULL,
    model_version text NOT NULL
);


--
-- Name: person_inference_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_inference_consents (
    id bigint NOT NULL,
    profile_fingerprint text NOT NULL,
    granted_by text NOT NULL,
    granted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_by text,
    revoked_at timestamp with time zone,
    CONSTRAINT person_inference_consents_check CHECK (((revoked_by IS NULL) = (revoked_at IS NULL)))
);


--
-- Name: person_inference_consents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_inference_consents ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_inference_consents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_inference_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_inference_profiles (
    fingerprint text NOT NULL,
    provider_kind text NOT NULL,
    endpoint text NOT NULL,
    model text NOT NULL,
    api_key_env text NOT NULL,
    allow_anonymous boolean DEFAULT false NOT NULL,
    auth_scheme text DEFAULT 'bearer'::text NOT NULL,
    credential_source text DEFAULT 'env'::text NOT NULL,
    credential_ref text DEFAULT ''::text NOT NULL,
    output_mode text DEFAULT 'native_json_schema'::text NOT NULL,
    token_limit_parameter text DEFAULT ''::text NOT NULL,
    reasoning_effort text DEFAULT ''::text NOT NULL,
    reasoning_mode text DEFAULT ''::text NOT NULL,
    driver_version text DEFAULT ''::text NOT NULL,
    retention_posture text NOT NULL,
    training_posture text NOT NULL,
    allowed_sources jsonb NOT NULL,
    source_since text NOT NULL,
    source_until text,
    allow_sensitive boolean DEFAULT false NOT NULL,
    execution_boundary text DEFAULT ''::text NOT NULL,
    packet_renderer_policy text DEFAULT ''::text NOT NULL,
    program_fingerprint text DEFAULT ''::text NOT NULL,
    disclosed_packet_fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    policy_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: person_match_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_match_consents (
    id bigint NOT NULL,
    disclosure_fingerprint text NOT NULL,
    endpoint text NOT NULL,
    model_id text NOT NULL,
    packet_schema text NOT NULL,
    retention_declaration text NOT NULL,
    policy_version text NOT NULL,
    question_version text NOT NULL,
    granted_by text NOT NULL,
    granted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_by text,
    revoked_at timestamp with time zone,
    CONSTRAINT person_match_consents_check CHECK (((revoked_by IS NULL) = (revoked_at IS NULL)))
);


--
-- Name: person_match_consents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_match_consents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.person_match_consents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_match_judgment_cursor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_match_judgment_cursor (
    singleton integer NOT NULL,
    candidate_id bigint DEFAULT 0 NOT NULL,
    started_at_zero boolean DEFAULT false NOT NULL,
    CONSTRAINT person_match_judgment_cursor_singleton_check CHECK ((singleton = 1))
);


--
-- Name: person_match_judgment_work; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_match_judgment_work (
    candidate_id bigint NOT NULL,
    fingerprint text NOT NULL,
    lease_owner text,
    lease_token text,
    lease_until timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    retry_after_at timestamp with time zone,
    CONSTRAINT person_match_judgment_work_attempt_count_check CHECK ((attempt_count >= 0))
);


--
-- Name: person_match_judgments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_match_judgments (
    id bigint NOT NULL,
    candidate_id bigint NOT NULL,
    fingerprint text NOT NULL,
    model_id text NOT NULL,
    question_version text NOT NULL,
    policy_version text NOT NULL,
    probability double precision,
    blockers_json text DEFAULT '[]'::text NOT NULL,
    outcome text NOT NULL,
    status text NOT NULL,
    error_class text,
    retry_after_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_match_judgments_probability_check CHECK (((probability IS NULL) OR ((probability >= (0)::double precision) AND (probability <= (1)::double precision)))),
    CONSTRAINT person_match_judgments_status_check CHECK ((status = ANY (ARRAY['scored'::text, 'retryable_error'::text, 'terminal_error'::text, 'stale'::text])))
);


--
-- Name: person_match_judgments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_match_judgments ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_match_judgments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_media (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    media_kind text NOT NULL,
    media_type text,
    uri text,
    data bytea,
    byte_size bigint,
    content_hash text,
    original_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT person_media_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT person_media_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: person_media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_media ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_merge_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_merge_participants (
    merge_id bigint NOT NULL,
    participant_id bigint NOT NULL,
    origin_side text NOT NULL,
    split_id bigint,
    CONSTRAINT person_merge_participants_origin_side_check CHECK ((origin_side = ANY (ARRAY['survivor'::text, 'absorbed'::text])))
);


--
-- Name: person_merge_review_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_merge_review_candidates (
    id bigint NOT NULL,
    merge_id bigint NOT NULL,
    survivor_person_id bigint NOT NULL,
    definition_id bigint NOT NULL,
    survivor_value_id bigint NOT NULL,
    absorbed_value_id bigint NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    resolution_value_id bigint,
    reviewed_by text,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_merge_review_candidates_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'accepted'::text, 'rejected'::text])))
);


--
-- Name: person_merge_review_candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_merge_review_candidates ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_merge_review_candidates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_merge_row_person_refs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_merge_row_person_refs (
    merge_id bigint NOT NULL,
    table_name text NOT NULL,
    original_row_key text NOT NULL,
    column_name text NOT NULL,
    person_id bigint NOT NULL
);


--
-- Name: person_merge_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_merge_rows (
    merge_id bigint NOT NULL,
    table_name text NOT NULL,
    original_row_id bigint,
    original_row_key text NOT NULL,
    current_row_id bigint,
    current_row_key text,
    origin_side text NOT NULL,
    provenance_kind text NOT NULL,
    participant_id bigint,
    action text NOT NULL,
    snapshot_path text NOT NULL,
    post_merge_row_json text,
    split_id bigint,
    CONSTRAINT person_merge_rows_action_check CHECK ((action = ANY (ARRAY['moved'::text, 'repointed'::text, 'deduplicated'::text, 'deleted_snapshot'::text, 'recomputed'::text]))),
    CONSTRAINT person_merge_rows_origin_side_check CHECK ((origin_side = ANY (ARRAY['survivor'::text, 'absorbed'::text]))),
    CONSTRAINT person_merge_rows_original_row_key_check CHECK ((original_row_key <> ''::text)),
    CONSTRAINT person_merge_rows_provenance_kind_check CHECK ((provenance_kind = ANY (ARRAY['participant_exact'::text, 'absorbed_profile'::text, 'derived'::text, 'inbound_reference'::text])))
);


--
-- Name: person_merges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_merges (
    id bigint NOT NULL,
    idempotency_key text NOT NULL,
    request_hash text NOT NULL,
    survivor_person_id_at_merge bigint NOT NULL,
    absorbed_person_id bigint NOT NULL,
    current_person_id bigint,
    survivor_uid text NOT NULL,
    absorbed_uid text NOT NULL,
    survivor_revision_before bigint NOT NULL,
    absorbed_revision_before bigint NOT NULL,
    survivor_revision_after bigint NOT NULL,
    actor text NOT NULL,
    snapshot_version integer NOT NULL,
    snapshot_blob bytea NOT NULL,
    snapshot_sha256 text NOT NULL,
    result_json text,
    identity_revision bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_merges_check CHECK ((survivor_person_id_at_merge <> absorbed_person_id)),
    CONSTRAINT person_merges_idempotency_key_check CHECK (((length(idempotency_key) >= 1) AND (length(idempotency_key) <= 128))),
    CONSTRAINT person_merges_identity_revision_check CHECK (((identity_revision IS NULL) OR (identity_revision > 0))),
    CONSTRAINT person_merges_request_hash_check CHECK ((length(request_hash) = 64)),
    CONSTRAINT person_merges_snapshot_sha256_check CHECK ((length(snapshot_sha256) = 64)),
    CONSTRAINT person_merges_snapshot_version_check CHECK ((snapshot_version > 0))
);


--
-- Name: person_merges_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_merges ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_merges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_names; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_names (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    name_kind text NOT NULL,
    formatted text,
    family_name text,
    given_name text,
    additional_names text,
    honorific_prefixes text,
    honorific_suffixes text,
    secondary_surname text,
    generation text,
    language text,
    script text,
    phonetic_system text,
    phonetic_script text,
    sort_as text,
    is_derived boolean DEFAULT false NOT NULL,
    original_value text NOT NULL,
    pref integer,
    ordinal integer DEFAULT 0 NOT NULL,
    type_label text,
    type_tokens text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    active_from timestamp with time zone,
    active_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT person_names_check CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT person_names_pref_check CHECK (((pref IS NULL) OR ((pref >= 1) AND (pref <= 100))))
);


--
-- Name: person_names_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_names ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_names_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_participants (
    person_id bigint NOT NULL,
    participant_id bigint NOT NULL
);


--
-- Name: person_relationship_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_relationship_reviews (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    raw_related_value text NOT NULL,
    raw_related_type text DEFAULT ''::text NOT NULL,
    value_kind text NOT NULL,
    matched_person_id bigint,
    accepted_relationship_id bigint,
    status text DEFAULT 'pending'::text NOT NULL,
    source text NOT NULL,
    source_ref text,
    source_resource_uid text,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    created_by text DEFAULT 'system'::text NOT NULL,
    reviewed_by text,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_relationship_reviews_check CHECK (((matched_person_id IS NULL) OR (matched_person_id <> person_id)))
);


--
-- Name: person_relationship_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_relationship_reviews ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_relationship_reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_relationships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_relationships (
    id bigint NOT NULL,
    source_person_id bigint NOT NULL,
    target_person_id bigint NOT NULL,
    relationship_type_id bigint NOT NULL,
    start_year integer,
    start_month integer,
    start_day integer,
    end_year integer,
    end_month integer,
    end_day integer,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    source text DEFAULT 'user'::text NOT NULL,
    source_ref text,
    source_resource_uid text,
    confidence double precision,
    vcard_property text,
    vcard_group text,
    vcard_prop_id text,
    vcard_pid text,
    vcard_altid text,
    created_by text DEFAULT 'user'::text NOT NULL,
    updated_by text DEFAULT 'user'::text NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_relationships_check CHECK ((source_person_id <> target_person_id)),
    CONSTRAINT person_relationships_check1 CHECK (((start_day IS NULL) OR (start_month IS NOT NULL))),
    CONSTRAINT person_relationships_check2 CHECK (((end_day IS NULL) OR (end_month IS NOT NULL))),
    CONSTRAINT person_relationships_check3 CHECK (((start_month IS NULL) OR (start_year IS NOT NULL))),
    CONSTRAINT person_relationships_check4 CHECK (((end_month IS NULL) OR (end_year IS NOT NULL))),
    CONSTRAINT person_relationships_check5 CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision) AND (source <> ALL (ARRAY['user'::text, 'carddav_import'::text, 'vcard_import'::text]))))),
    CONSTRAINT person_relationships_end_day_check CHECK (((end_day >= 1) AND (end_day <= 31))),
    CONSTRAINT person_relationships_end_month_check CHECK (((end_month >= 1) AND (end_month <= 12))),
    CONSTRAINT person_relationships_end_year_check CHECK (((end_year >= 1) AND (end_year <= 9999))),
    CONSTRAINT person_relationships_start_day_check CHECK (((start_day >= 1) AND (start_day <= 31))),
    CONSTRAINT person_relationships_start_month_check CHECK (((start_month >= 1) AND (start_month <= 12))),
    CONSTRAINT person_relationships_start_year_check CHECK (((start_year >= 1) AND (start_year <= 9999)))
);


--
-- Name: person_relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_relationships ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_relationships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_semantic_embedding_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_semantic_embedding_consents (
    id bigint NOT NULL,
    profile_fingerprint text NOT NULL,
    granted_by text NOT NULL,
    granted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_by text,
    revoked_at timestamp with time zone,
    CONSTRAINT person_semantic_embedding_consents_check CHECK (((revoked_by IS NULL) = (revoked_at IS NULL)))
);


--
-- Name: person_semantic_embedding_consents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_semantic_embedding_consents ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_semantic_embedding_consents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_semantic_embedding_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_semantic_embedding_profiles (
    fingerprint text NOT NULL,
    purpose text NOT NULL,
    destination text NOT NULL,
    api_format text NOT NULL,
    model text NOT NULL,
    api_key_env text NOT NULL,
    retention_posture text NOT NULL,
    training_posture text NOT NULL,
    renderer_policy text NOT NULL,
    disclosed_field_classes jsonb NOT NULL,
    corpus_scope text NOT NULL,
    policy_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: person_splits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_splits (
    id bigint NOT NULL,
    merge_id bigint NOT NULL,
    idempotency_key text NOT NULL,
    request_hash text NOT NULL,
    source_person_id bigint NOT NULL,
    new_person_id bigint NOT NULL,
    new_person_uid text NOT NULL,
    source_revision_before bigint NOT NULL,
    source_revision_after bigint NOT NULL,
    actor text NOT NULL,
    is_exact_reversal boolean NOT NULL,
    result_json text,
    identity_revision bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_splits_check CHECK ((source_person_id <> new_person_id)),
    CONSTRAINT person_splits_idempotency_key_check CHECK (((length(idempotency_key) >= 1) AND (length(idempotency_key) <= 128))),
    CONSTRAINT person_splits_identity_revision_check CHECK (((identity_revision IS NULL) OR (identity_revision > 0))),
    CONSTRAINT person_splits_request_hash_check CHECK ((length(request_hash) = 64))
);


--
-- Name: person_splits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.person_splits ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.person_splits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: person_sweep_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_attempts (
    id text NOT NULL,
    run_id text NOT NULL,
    person_id bigint NOT NULL,
    lease_fence bigint NOT NULL,
    mode text NOT NULL,
    status text NOT NULL,
    failure_class text DEFAULT ''::text NOT NULL,
    brief_failure_class text DEFAULT ''::text NOT NULL,
    cursor_envelope_json text NOT NULL,
    envelope_hash text NOT NULL,
    program_fingerprint text NOT NULL,
    catalog_fingerprint text NOT NULL,
    provider_fingerprint text NOT NULL,
    generation_id bigint,
    generation_key text DEFAULT ''::text NOT NULL,
    seed_count integer DEFAULT 0 NOT NULL,
    context_count integer DEFAULT 0 NOT NULL,
    claim_count integer DEFAULT 0 NOT NULL,
    decision_count integer DEFAULT 0 NOT NULL,
    projected_write_count integer DEFAULT 0 NOT NULL,
    request_count integer DEFAULT 0 NOT NULL,
    provider_request_id text DEFAULT ''::text NOT NULL,
    input_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint DEFAULT 0 NOT NULL,
    estimated_cost_micro_usd bigint DEFAULT 0 NOT NULL,
    latency_milliseconds bigint DEFAULT 0 NOT NULL,
    retry_at timestamp with time zone,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT person_sweep_attempts_brief_failure_class_check CHECK ((brief_failure_class = ANY (ARRAY[''::text, 'policy'::text, 'budget'::text, 'lease_lost'::text, 'rate_limited'::text, 'timeout'::text, 'provider_http'::text, 'invalid_output'::text, 'archive_gap'::text, 'internal'::text]))),
    CONSTRAINT person_sweep_attempts_claim_count_check CHECK ((claim_count >= 0)),
    CONSTRAINT person_sweep_attempts_context_count_check CHECK ((context_count >= 0)),
    CONSTRAINT person_sweep_attempts_decision_count_check CHECK ((decision_count >= 0)),
    CONSTRAINT person_sweep_attempts_estimated_cost_micro_usd_check CHECK ((estimated_cost_micro_usd >= 0)),
    CONSTRAINT person_sweep_attempts_failure_class_check CHECK ((failure_class = ANY (ARRAY[''::text, 'policy'::text, 'budget'::text, 'lease_lost'::text, 'rate_limited'::text, 'timeout'::text, 'provider_http'::text, 'invalid_output'::text, 'archive_gap'::text, 'internal'::text]))),
    CONSTRAINT person_sweep_attempts_input_tokens_check CHECK ((input_tokens >= 0)),
    CONSTRAINT person_sweep_attempts_latency_milliseconds_check CHECK ((latency_milliseconds >= 0)),
    CONSTRAINT person_sweep_attempts_lease_fence_check CHECK ((lease_fence >= 0)),
    CONSTRAINT person_sweep_attempts_mode_check CHECK ((mode = ANY (ARRAY['incremental'::text, 'backstop'::text]))),
    CONSTRAINT person_sweep_attempts_output_tokens_check CHECK ((output_tokens >= 0)),
    CONSTRAINT person_sweep_attempts_projected_write_count_check CHECK ((projected_write_count >= 0)),
    CONSTRAINT person_sweep_attempts_request_count_check CHECK ((request_count >= 0)),
    CONSTRAINT person_sweep_attempts_seed_count_check CHECK ((seed_count >= 0)),
    CONSTRAINT person_sweep_attempts_status_check CHECK ((status = ANY (ARRAY['running'::text, 'succeeded'::text, 'failed'::text, 'cancelled'::text])))
);


--
-- Name: person_sweep_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_batches (
    attempt_id text NOT NULL,
    batch_ordinal integer NOT NULL,
    call_ordinal integer DEFAULT 0 NOT NULL,
    purpose text DEFAULT 'primary'::text NOT NULL,
    utc_day text NOT NULL,
    reservation_id text NOT NULL,
    budget_fingerprint text NOT NULL,
    input_hash text NOT NULL,
    item_count integer NOT NULL,
    status text NOT NULL,
    provider_request_id text DEFAULT ''::text NOT NULL,
    reserved_requests integer NOT NULL,
    reserved_input_tokens bigint NOT NULL,
    reserved_output_tokens bigint NOT NULL,
    reserved_cost_micro_usd bigint NOT NULL,
    actual_requests integer DEFAULT 0 NOT NULL,
    actual_input_tokens bigint DEFAULT 0 NOT NULL,
    actual_output_tokens bigint DEFAULT 0 NOT NULL,
    actual_cost_micro_usd bigint DEFAULT 0 NOT NULL,
    latency_milliseconds bigint DEFAULT 0 NOT NULL,
    failure_class text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT person_sweep_batches_actual_cost_micro_usd_check CHECK ((actual_cost_micro_usd >= 0)),
    CONSTRAINT person_sweep_batches_actual_input_tokens_check CHECK ((actual_input_tokens >= 0)),
    CONSTRAINT person_sweep_batches_actual_output_tokens_check CHECK ((actual_output_tokens >= 0)),
    CONSTRAINT person_sweep_batches_actual_requests_check CHECK ((actual_requests >= 0)),
    CONSTRAINT person_sweep_batches_batch_ordinal_check CHECK ((batch_ordinal >= 0)),
    CONSTRAINT person_sweep_batches_call_coordinate_check CHECK ((((call_ordinal = 0) AND (purpose = ANY (ARRAY['primary'::text, 'brief'::text]))) OR ((call_ordinal = 1) AND (purpose = ANY (ARRAY['repair'::text, 'brief_repair'::text]))))),
    CONSTRAINT person_sweep_batches_call_ordinal_check CHECK ((call_ordinal = ANY (ARRAY[0, 1]))),
    CONSTRAINT person_sweep_batches_failure_class_check CHECK ((failure_class = ANY (ARRAY[''::text, 'policy'::text, 'budget'::text, 'lease_lost'::text, 'rate_limited'::text, 'timeout'::text, 'provider_http'::text, 'invalid_output'::text, 'archive_gap'::text, 'internal'::text]))),
    CONSTRAINT person_sweep_batches_item_count_check CHECK ((item_count >= 0)),
    CONSTRAINT person_sweep_batches_latency_milliseconds_check CHECK ((latency_milliseconds >= 0)),
    CONSTRAINT person_sweep_batches_reserved_cost_micro_usd_check CHECK ((reserved_cost_micro_usd >= 0)),
    CONSTRAINT person_sweep_batches_reserved_input_tokens_check CHECK ((reserved_input_tokens >= 0)),
    CONSTRAINT person_sweep_batches_reserved_output_tokens_check CHECK ((reserved_output_tokens >= 0)),
    CONSTRAINT person_sweep_batches_reserved_requests_check CHECK ((reserved_requests >= 0)),
    CONSTRAINT person_sweep_batches_status_check CHECK ((status = ANY (ARRAY['reserved'::text, 'running'::text, 'succeeded'::text, 'failed'::text, 'cancelled'::text])))
);


--
-- Name: person_sweep_change_clock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_change_clock (
    singleton boolean NOT NULL,
    sequence bigint NOT NULL,
    enabled boolean NOT NULL,
    CONSTRAINT person_sweep_change_clock_sequence_check CHECK ((sequence >= 0)),
    CONSTRAINT person_sweep_change_clock_singleton_check CHECK (singleton)
);


--
-- Name: person_sweep_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_changes (
    sequence bigint NOT NULL,
    person_id bigint NOT NULL,
    source_lane text NOT NULL,
    change_kind text NOT NULL,
    evidence_effect text DEFAULT ''::text NOT NULL,
    source_id bigint,
    message_id bigint,
    attachment_id bigint,
    occurrence_key text DEFAULT ''::text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT person_sweep_changes_change_kind_check CHECK ((change_kind = ANY (ARRAY['upsert'::text, 'delete'::text, 'scope'::text, 'tracking'::text, 'publication'::text]))),
    CONSTRAINT person_sweep_changes_evidence_effect_check CHECK ((evidence_effect = ANY (ARRAY[''::text, 'source-deleted'::text, 'source-edited'::text, 'scope-unlinked'::text, 'identity-reassigned'::text, 'source-reimported'::text, 'scope-relinked'::text]))),
    CONSTRAINT person_sweep_changes_sequence_check CHECK ((sequence > 0)),
    CONSTRAINT person_sweep_changes_source_lane_check CHECK ((source_lane = ANY (ARRAY['conversation_text'::text, 'meeting_text'::text, 'attachment_caption'::text, 'attachment_ocr'::text, 'document_text'::text])))
);


--
-- Name: person_sweep_cursors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_cursors (
    person_id bigint NOT NULL,
    source_lane text NOT NULL,
    program_fingerprint text NOT NULL,
    catalog_fingerprint text NOT NULL,
    optimistic_sequence bigint NOT NULL,
    optimistic_document_key text DEFAULT ''::text NOT NULL,
    reconcile_upper_key text NOT NULL,
    reconcile_after_key text NOT NULL,
    reconcile_document_key text DEFAULT ''::text NOT NULL,
    reconciliation_complete boolean NOT NULL,
    backstop_upper_key text DEFAULT ''::text NOT NULL,
    backstop_after_key text DEFAULT ''::text NOT NULL,
    backstop_document_key text DEFAULT ''::text NOT NULL,
    last_backstop_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_sweep_cursors_optimistic_sequence_check CHECK ((optimistic_sequence >= 0)),
    CONSTRAINT person_sweep_cursors_source_lane_check CHECK ((source_lane = ANY (ARRAY['conversation_text'::text, 'meeting_text'::text, 'attachment_caption'::text, 'attachment_ocr'::text, 'document_text'::text])))
);


--
-- Name: person_sweep_daily_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_daily_usage (
    utc_day text NOT NULL,
    reserved_requests integer DEFAULT 0 NOT NULL,
    reserved_input_tokens bigint DEFAULT 0 NOT NULL,
    reserved_output_tokens bigint DEFAULT 0 NOT NULL,
    reserved_cost_micro_usd bigint DEFAULT 0 NOT NULL,
    actual_requests integer DEFAULT 0 NOT NULL,
    actual_input_tokens bigint DEFAULT 0 NOT NULL,
    actual_output_tokens bigint DEFAULT 0 NOT NULL,
    actual_cost_micro_usd bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_sweep_daily_usage_actual_cost_micro_usd_check CHECK ((actual_cost_micro_usd >= 0)),
    CONSTRAINT person_sweep_daily_usage_actual_input_tokens_check CHECK ((actual_input_tokens >= 0)),
    CONSTRAINT person_sweep_daily_usage_actual_output_tokens_check CHECK ((actual_output_tokens >= 0)),
    CONSTRAINT person_sweep_daily_usage_actual_requests_check CHECK ((actual_requests >= 0)),
    CONSTRAINT person_sweep_daily_usage_reserved_cost_micro_usd_check CHECK ((reserved_cost_micro_usd >= 0)),
    CONSTRAINT person_sweep_daily_usage_reserved_input_tokens_check CHECK ((reserved_input_tokens >= 0)),
    CONSTRAINT person_sweep_daily_usage_reserved_output_tokens_check CHECK ((reserved_output_tokens >= 0)),
    CONSTRAINT person_sweep_daily_usage_reserved_requests_check CHECK ((reserved_requests >= 0))
);


--
-- Name: person_sweep_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_runs (
    id text NOT NULL,
    kind text NOT NULL,
    mode text NOT NULL,
    status text NOT NULL,
    program_fingerprint text NOT NULL,
    catalog_fingerprint text NOT NULL,
    provider_fingerprint text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    failure_count integer DEFAULT 0 NOT NULL,
    projected_write_count integer DEFAULT 0 NOT NULL,
    actual_requests integer DEFAULT 0 NOT NULL,
    actual_input_tokens bigint DEFAULT 0 NOT NULL,
    actual_output_tokens bigint DEFAULT 0 NOT NULL,
    actual_cost_micro_usd bigint DEFAULT 0 NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT person_sweep_runs_actual_cost_micro_usd_check CHECK ((actual_cost_micro_usd >= 0)),
    CONSTRAINT person_sweep_runs_actual_input_tokens_check CHECK ((actual_input_tokens >= 0)),
    CONSTRAINT person_sweep_runs_actual_output_tokens_check CHECK ((actual_output_tokens >= 0)),
    CONSTRAINT person_sweep_runs_actual_requests_check CHECK ((actual_requests >= 0)),
    CONSTRAINT person_sweep_runs_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT person_sweep_runs_failure_count_check CHECK ((failure_count >= 0)),
    CONSTRAINT person_sweep_runs_kind_check CHECK ((kind = ANY (ARRAY['scheduled'::text, 'manual'::text]))),
    CONSTRAINT person_sweep_runs_mode_check CHECK ((mode = ANY (ARRAY['incremental'::text, 'backstop'::text]))),
    CONSTRAINT person_sweep_runs_projected_write_count_check CHECK ((projected_write_count >= 0)),
    CONSTRAINT person_sweep_runs_status_check CHECK ((status = ANY (ARRAY['running'::text, 'succeeded'::text, 'partial'::text, 'failed'::text]))),
    CONSTRAINT person_sweep_runs_success_count_check CHECK ((success_count >= 0))
);


--
-- Name: person_sweep_sync_publications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_sync_publications (
    sync_run_id bigint NOT NULL,
    source_id bigint NOT NULL,
    lower_sequence bigint NOT NULL,
    upper_sequence bigint,
    published_at timestamp with time zone,
    CONSTRAINT person_sweep_sync_publications_check CHECK (((upper_sequence IS NULL) OR (upper_sequence >= lower_sequence))),
    CONSTRAINT person_sweep_sync_publications_lower_sequence_check CHECK ((lower_sequence >= 0))
);


--
-- Name: person_sweep_work; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_sweep_work (
    person_id bigint NOT NULL,
    dirty_through_sequence bigint NOT NULL,
    available_at timestamp with time zone NOT NULL,
    attempt_count integer NOT NULL,
    last_failure_class text DEFAULT ''::text NOT NULL,
    lease_owner text DEFAULT ''::text NOT NULL,
    lease_until timestamp with time zone,
    lease_fence bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT person_sweep_work_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT person_sweep_work_dirty_through_sequence_check CHECK ((dirty_through_sequence >= 0)),
    CONSTRAINT person_sweep_work_lease_fence_check CHECK ((lease_fence >= 0))
);


--
-- Name: person_tracking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_tracking (
    person_id bigint NOT NULL,
    tracked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: person_uid_aliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_uid_aliases (
    retired_uid text NOT NULL,
    surviving_person_id bigint,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: persons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.persons (
    id bigint NOT NULL,
    vcard_uid text NOT NULL,
    display_name text,
    revision bigint DEFAULT 1 NOT NULL,
    vcard_projection_revision bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: persons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.persons ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.persons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reaction_source_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reaction_source_events (
    source_id bigint NOT NULL,
    source_reaction_id text NOT NULL,
    reaction_id bigint NOT NULL
);


--
-- Name: reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reactions (
    id bigint NOT NULL,
    message_id bigint NOT NULL,
    participant_id bigint NOT NULL,
    reaction_type text NOT NULL,
    reaction_value text NOT NULL,
    created_at timestamp with time zone,
    removed_at timestamp with time zone
);


--
-- Name: reactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.reactions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.reactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: relationship_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relationship_types (
    id bigint NOT NULL,
    universal_id text NOT NULL,
    slug text NOT NULL,
    forward_label text NOT NULL,
    reverse_label text NOT NULL,
    is_symmetric boolean DEFAULT false NOT NULL,
    is_canonical boolean DEFAULT true NOT NULL,
    inverse_type_id bigint,
    vcard_related_type text,
    color text,
    icon text,
    description text,
    ownership text DEFAULT 'user'::text NOT NULL,
    is_deletable boolean DEFAULT true NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT relationship_types_check CHECK (((is_symmetric = false) OR (forward_label = reverse_label))),
    CONSTRAINT relationship_types_check1 CHECK (((is_canonical = true) OR (inverse_type_id IS NOT NULL)))
);


--
-- Name: relationship_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.relationship_types ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.relationship_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: saved_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_views (
    id bigint NOT NULL,
    name text NOT NULL,
    description text,
    canonical_state jsonb NOT NULL,
    schema_version integer NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: saved_views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.saved_views ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.saved_views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: source_import_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.source_import_items (
    id bigint NOT NULL,
    source_id bigint NOT NULL,
    provider text NOT NULL,
    provider_id text NOT NULL,
    name text NOT NULL,
    checksum text,
    size bigint DEFAULT 0,
    modified_at timestamp with time zone,
    imported_at timestamp with time zone,
    status text DEFAULT 'pending'::text NOT NULL,
    records_imported integer DEFAULT 0,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: source_import_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.source_import_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.source_import_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sources (
    id bigint NOT NULL,
    source_type text NOT NULL,
    identifier text NOT NULL,
    display_name text,
    google_user_id text,
    last_sync_at timestamp with time zone,
    sync_cursor text,
    sync_config jsonb,
    oauth_app text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sources ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sync_checkpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_checkpoints (
    source_id bigint NOT NULL,
    checkpoint_type text NOT NULL,
    checkpoint_value text NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: sync_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_operations (
    id text NOT NULL,
    source_id bigint NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    CONSTRAINT sync_operations_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'done'::text, 'failed'::text])))
);


--
-- Name: sync_run_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_run_items (
    id bigint NOT NULL,
    sync_run_id bigint NOT NULL,
    source_message_id text NOT NULL,
    phase text NOT NULL,
    status text NOT NULL,
    error_kind text NOT NULL,
    error_message text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: sync_run_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sync_run_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sync_run_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sync_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_runs (
    id bigint NOT NULL,
    source_id bigint NOT NULL,
    sync_type text DEFAULT ''::text NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    status text DEFAULT 'running'::text,
    messages_processed bigint DEFAULT 0,
    messages_added bigint DEFAULT 0,
    messages_updated bigint DEFAULT 0,
    errors_count bigint DEFAULT 0,
    error_message text,
    cursor_before text,
    cursor_after text,
    request_fingerprint text,
    operation_id text
);


--
-- Name: sync_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.sync_runs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sync_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: vcard_resource_envelopes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vcard_resource_envelopes (
    id bigint NOT NULL,
    person_id bigint NOT NULL,
    canonical_person_uid text NOT NULL,
    source_ref text NOT NULL,
    source_resource_uid text NOT NULL,
    href text,
    original_raw_bytes bytea NOT NULL,
    stored_body bytea NOT NULL,
    resource_metadata jsonb NOT NULL,
    projection_fingerprint text,
    content_hash text NOT NULL,
    etag text NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT vcard_resource_envelopes_source_ref_check CHECK ((length(TRIM(BOTH FROM source_ref)) > 0)),
    CONSTRAINT vcard_resource_envelopes_source_resource_uid_check CHECK ((length(TRIM(BOTH FROM source_resource_uid)) > 0))
);


--
-- Name: vcard_resource_envelopes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.vcard_resource_envelopes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.vcard_resource_envelopes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: visual_embedding_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visual_embedding_runs (
    id bigint NOT NULL,
    invocation_key text NOT NULL,
    trigger text NOT NULL,
    state text DEFAULT 'running'::text NOT NULL,
    started_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    error_code text,
    attempted bigint DEFAULT 0 NOT NULL,
    succeeded bigint DEFAULT 0 NOT NULL,
    failed bigint DEFAULT 0 NOT NULL,
    skipped bigint DEFAULT 0 NOT NULL,
    CONSTRAINT visual_embedding_runs_attempted_check CHECK ((attempted >= 0)),
    CONSTRAINT visual_embedding_runs_check CHECK ((((state = 'running'::text) AND (finished_at IS NULL) AND (error_code IS NULL)) OR ((state <> 'running'::text) AND (finished_at IS NOT NULL)))),
    CONSTRAINT visual_embedding_runs_error_code_check CHECK (((error_code IS NULL) OR (error_code = ANY (ARRAY['invocation_cancelled'::text, 'invocation_timeout'::text, 'invocation_rate_limited'::text, 'invocation_authentication_failed'::text, 'invocation_upstream_failed'::text, 'invocation_invalid_output'::text, 'invocation_safety_limit'::text, 'invocation_archive_drift'::text, 'invocation_daemon_restarted'::text, 'invocation_internal'::text, 'invocation_unsafe_error_redacted'::text])))),
    CONSTRAINT visual_embedding_runs_failed_check CHECK ((failed >= 0)),
    CONSTRAINT visual_embedding_runs_invocation_key_check CHECK ((((octet_length(invocation_key) >= 1) AND (octet_length(invocation_key) <= 128)) AND (btrim(invocation_key) = invocation_key))),
    CONSTRAINT visual_embedding_runs_skipped_check CHECK ((skipped >= 0)),
    CONSTRAINT visual_embedding_runs_state_check CHECK ((state = ANY (ARRAY['running'::text, 'succeeded'::text, 'partial'::text, 'failed'::text, 'cancelled'::text]))),
    CONSTRAINT visual_embedding_runs_succeeded_check CHECK ((succeeded >= 0)),
    CONSTRAINT visual_embedding_runs_trigger_check CHECK ((trigger = ANY (ARRAY['manual'::text, 'scheduled'::text])))
);


--
-- Name: visual_embedding_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.visual_embedding_runs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.visual_embedding_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: visual_generations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visual_generations (
    id bigint NOT NULL,
    fingerprint text NOT NULL,
    model text NOT NULL,
    dimension integer NOT NULL,
    state text DEFAULT 'building'::text NOT NULL,
    source_fence bigint DEFAULT 0 NOT NULL,
    consented_at timestamp with time zone,
    consent_policy_fingerprint text,
    capability_fingerprint text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    activated_at timestamp with time zone,
    CONSTRAINT visual_generations_dimension_check CHECK ((dimension = 1024)),
    CONSTRAINT visual_generations_state_check CHECK ((state = ANY (ARRAY['building'::text, 'active'::text, 'retired'::text])))
);


--
-- Name: visual_generations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.visual_generations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.visual_generations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: visual_obsolete_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visual_obsolete_tokens (
    generation_id bigint NOT NULL,
    vector_token text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: visual_publications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visual_publications (
    generation_id bigint NOT NULL,
    message_id bigint NOT NULL,
    blob_hash text NOT NULL,
    media_input_key text NOT NULL,
    published_revision text,
    prepared_revision text,
    source_fence bigint DEFAULT 0 NOT NULL,
    representative_attachment_id bigint,
    attachment_role text NOT NULL,
    role_source text NOT NULL,
    current_vector_token text,
    pending_vector_token text,
    state text NOT NULL,
    outcome_kind text,
    outcome_reason text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT visual_publications_state_check CHECK ((state = ANY (ARRAY['current'::text, 'stale'::text, 'tombstoned'::text])))
);


--
-- Name: visual_work_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visual_work_claims (
    generation_id bigint NOT NULL,
    message_id bigint NOT NULL,
    blob_hash text NOT NULL,
    media_input_key text NOT NULL,
    proposed_revision text NOT NULL,
    lease_owner text NOT NULL,
    lease_expires_at timestamp with time zone NOT NULL,
    fencing_token bigint NOT NULL,
    source_fence bigint NOT NULL,
    claimed_content_stamp text DEFAULT ''::text NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Data for Name: account_identities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_identities (source_id, address, address_key, source_signal, confirmed_at) FROM stdin;
\.


--
-- Data for Name: activity_event_persons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_event_persons (message_id, person_id, role, evidence, local_date) FROM stdin;
\.


--
-- Data for Name: activity_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_events (message_id, ref_kind, source_id, conversation_id, channel, occurred_at, date_origin, date_precision, timezone, utc_offset_minutes, local_date, direction, owner_source_id, owner_address, projected_last_modified, projected_identity_revision, projected_account_identity_revision, created_at) FROM stdin;
\.


--
-- Data for Name: activity_projection_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_projection_queue (message_id, revision, processed_revision, queued_at) FROM stdin;
1	1	0	2026-10-08 09:55:05.831546+00
3	1	0	2026-10-08 09:55:06.197501+00
5	1	0	2026-10-08 09:55:06.50243+00
\.


--
-- Data for Name: applied_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.applied_migrations (name, version, applied_at) FROM stdin;
person_inference_provider_v2	1	2026-10-08 09:54:57.901069+00
person_sweep_calls_v2	1	2026-10-08 09:54:57.944108+00
person_sweep_batch_purpose_v2	1	2026-10-08 09:54:58.004888+00
person_fact_claim_origin_brief_v1	1	2026-10-08 09:54:58.121564+00
person_sweep_attempt_brief_failure_v1	1	2026-10-08 09:54:58.337709+00
directory_projection_v1	1	2026-10-08 09:54:58.814565+00
attachments_content_hash_unique_index	1	2026-10-08 09:54:58.849796+00
identity_match_source_support_v1	1	2026-10-08 09:54:58.937805+00
participants_phone_unique_index	1	2026-10-08 09:54:59.068454+00
communication_services_seed_v1	1	2026-10-08 09:54:59.076549+00
carddav_multiple_accounts_v1	1	2026-10-08 09:55:00.666043+00
sync_run_resume_metadata_v1	1	2026-10-08 09:55:00.701469+00
vcard_source_resource_identity_v1	1	2026-10-08 09:55:01.16465+00
organization_domain_idna_v1	1	2026-10-08 09:55:01.194921+00
participant_identifiers_service_scope_v1	1	2026-10-08 09:55:01.283832+00
participant_identifiers_service_scope_v2	1	2026-10-08 09:55:01.291146+00
attachment_occurrence_unique_indexes_v1	1	2026-10-08 09:55:01.411963+00
message_recipients_envelope_unique_index	1	2026-10-08 09:55:01.460901+00
message_and_attachment_triggers_v10	1	2026-10-08 09:55:01.579463+00
embedding_change_journal_triggers_v7	1	2026-10-08 09:55:01.591877+00
person_sweep_change_triggers_v5	1	2026-10-08 09:55:01.5958+00
activity_projection_triggers_v4	1	2026-10-08 09:55:01.640121+00
gmail_chat_classification_v1	1	2026-10-08 09:55:01.710075+00
message_attribution_provenance_v3	1	2026-10-08 09:55:01.738658+00
account_identities_address_key_index_v1	1	2026-10-08 09:55:01.760691+00
messages_last_modified_backfill	1	2026-10-08 09:55:02.302577+00
messages_last_modified_null_repair	1	2026-10-08 09:55:02.320123+00
messages_content_changed_at_backfill	1	2026-10-08 09:55:02.362144+00
archive_identity_v1	1	2026-10-08 09:55:02.513226+00
meeting_projection_v1	1	2026-10-08 09:55:02.662211+00
carddav_inference_export_state_v1	1	2026-10-08 09:55:03.116064+00
\.


--
-- Data for Name: archive_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.archive_metadata (key, value) FROM stdin;
archive_uid	132e50caafa0b75e3f68c3a9161d82ec487395960edace9f180702e200728da7
identity_revision	0
\.


--
-- Data for Name: attachment_change_consumers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachment_change_consumers (consumer_key, baseline_sequence, last_sequence, reconciliation_complete, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attachment_change_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachment_change_log (sequence, event_kind, old_message_id, new_message_id, old_attachment_id, new_attachment_id, old_content_hash, new_content_hash, old_source_part_key, new_source_part_key, old_role, new_role, created_at) FROM stdin;
\.


--
-- Data for Name: attachment_pack_index; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachment_pack_index (blob_hash, pack_id, pack_offset, stored_len, raw_len, flags, crc32c) FROM stdin;
\.


--
-- Data for Name: attachment_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachment_packs (pack_id, entry_count, stored_bytes, created_at) FROM stdin;
\.


--
-- Data for Name: attachment_role_repair_progress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachment_role_repair_progress (singleton, last_message_id, completed, updated_at) FROM stdin;
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, message_id, filename, mime_type, size, content_hash, storage_path, media_type, width, height, duration_ms, thumbnail_hash, thumbnail_path, source_attachment_id, attachment_metadata, attachment_state, attachment_skip_reason, attachment_role, role_source, source_part_key, content_id, encryption_version, created_at) FROM stdin;
\.


--
-- Data for Name: attribute_definitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attribute_definitions (id, universal_id, object_type, slug, label, description, value_type, field_type, record_target, cardinality, display_order, is_required, ownership, ui_creatable, ui_editable, api_mutable, is_searchable, is_sensitive, is_audited, is_deletable, history_exempt, derived_source, options, vcard_property, is_active, revision, created_at, updated_at) FROM stdin;
1	59e9a7d3-4904-4d0e-97d1-d0680e1e9e55	person	primary_channel	Primary channel	Preferred way to reach this person	text	select	\N	single	10	f	system	t	t	t	f	f	t	f	f	\N	{"choices": [{"label": "Email", "value": "email"}, {"label": "Phone", "value": "phone"}, {"label": "SMS", "value": "sms"}, {"label": "Chat", "value": "chat"}, {"label": "In person", "value": "in_person"}]}	\N	t	1	2026-10-08 09:55:02.77796+00	2026-10-08 09:55:02.77796+00
2	34b52841-dcf5-40c6-a24e-628b049e85b2	person	contact_frequency	Contact frequency	Desired number of days between contacts	integer	duration	\N	single	20	f	system	t	t	t	f	f	t	f	f	\N	{"unit": "days"}	\N	t	1	2026-10-08 09:55:02.85831+00	2026-10-08 09:55:02.85831+00
3	93c658a1-2346-4a6e-98c2-abfa29209334	person	ask_me_about	Ask me about	Topics worth raising with this person	text	text	\N	multi	30	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.869395+00	2026-10-08 09:55:02.869395+00
4	6e843902-1685-4e23-a107-819220c7dd8d	person	last_contacted	Last contacted	Most recent interaction, computed from archive activity	timestamp	timestamp	\N	single	40	f	system	f	f	f	f	f	f	f	t	activity_spine	\N	\N	t	1	2026-10-08 09:55:02.879577+00	2026-10-08 09:55:02.879577+00
5	b72b3cf7-509f-4286-a0f0-bb039c85ff40	person	notes	Notes	General notes about this person	text	textarea	\N	single	45	f	system	t	t	t	f	t	t	f	f	\N	\N	NOTE	t	1	2026-10-08 09:55:02.897898+00	2026-10-08 09:55:02.897898+00
6	2068efb0-9808-498b-ac3a-8e0a87d4513a	person	location	Location	Where this person lives or is based	text	text	\N	single	50	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.905577+00	2026-10-08 09:55:02.905577+00
7	cd5aaad0-4368-4686-85e1-4dbdb86cc54b	person	birthplace	Born in	Where this person was born	text	text	\N	single	60	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.911043+00	2026-10-08 09:55:02.911043+00
8	fbf748ac-585a-4f79-aac3-f7eda023b5e4	person	membership	Membership	Groups and communities this person belongs to	text	text	\N	multi	70	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.917404+00	2026-10-08 09:55:02.917404+00
9	4425dff2-5da8-4398-8d91-9ec54defa1c0	person	religion	Religion	Religious identity or affiliation	text	text	\N	single	80	f	system	t	t	t	f	t	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.928375+00	2026-10-08 09:55:02.928375+00
10	f897f0b4-45fa-469a-97d5-c7d98517a50e	person	politics	Politics	Political views or affiliation	text	text	\N	single	90	f	system	t	t	t	f	t	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.934946+00	2026-10-08 09:55:02.934946+00
11	64142a35-ab0f-43cc-9828-87aaa362c693	person	personality	Personality	Personality traits and working style	text	text	\N	multi	100	f	system	t	t	t	f	t	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.940864+00	2026-10-08 09:55:02.940864+00
12	e0775bae-cf07-4d06-9cc2-cb09a5358d82	person	family_pets	Pets	Pets in this person's family	text	text	\N	multi	110	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.971299+00	2026-10-08 09:55:02.971299+00
13	e8c815d5-3568-429b-a93b-00220b0a1b43	person	interests_fun_now	Fun now	Activities this person enjoys now	text	text	\N	multi	120	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.977861+00	2026-10-08 09:55:02.977861+00
14	7ffd6a23-74cc-4e05-ad6b-7d765d883a94	person	interests_fun_growing_up	Fun growing up	Activities this person enjoyed growing up	text	text	\N	multi	130	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:02.989987+00	2026-10-08 09:55:02.989987+00
15	12612daa-90b0-461b-b928-79d4a2bc07ba	person	favorites_food	Favorite food	Foods this person especially likes	text	text	\N	multi	140	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:03.024178+00	2026-10-08 09:55:03.024178+00
16	be2bccc1-c395-4bb4-8f68-02e745ea7b22	person	favorites_place	Favorite place	Places this person especially likes	text	text	\N	multi	150	f	system	t	t	t	t	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:03.041421+00	2026-10-08 09:55:03.041421+00
17	ab373615-6ee4-43e7-9f60-8c1d4dbf46c6	person	how_we_met	How we met	How you and this person first met	text	text	\N	single	155	f	system	t	t	t	f	f	t	f	f	\N	{"max_length": 280}	\N	t	1	2026-10-08 09:55:03.062241+00	2026-10-08 09:55:03.062241+00
\.


--
-- Data for Name: beeper_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.beeper_drafts (draft_id, source_id, chat_id, text, revision, discarded_at, pending_operation, pending_original_message_id, pending_raw, pending_code, created_at, updated_at, created_by_principal) FROM stdin;
\.


--
-- Data for Name: beeper_media_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.beeper_media_deliveries (destination_key, processing_key, source_sha256, byte_length, transcript_sha256, language, provider, profile, phase, source_id, source_version_id, content_version_id, donor_occurrence_id, supplied_input_id, pending_operation_id, frozen_request_json, next_action_at, error_code, processing_operation_id, job_id, operation_state, coverage_state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: beeper_media_occurrences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.beeper_media_occurrences (destination_key, occurrence_ref, revision, source_type, source_identifier, source_conversation_id, source_message_id, source_attachment_id, source_part_key, source_row_id, message_id, attachment_id, source_sha256, byte_length, raw_hash, transcript_sha256, language, occurrence_json, request_filename, request_mime_type, retention_operation_id, retention_state, next_action_at, error_code, vault_uid, source_id, source_version_id, content_version_id, occurrence_id, processing_key, coverage_state, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carddav_account_home_urls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_account_home_urls (account_id, home_url, discovery_index) FROM stdin;
\.


--
-- Data for Name: carddav_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_accounts (id, connection_name, base_url, username, principal_url, home_url, connection_generation, discovery_revision, discovered_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carddav_address_book_urls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_address_book_urls (account_id, address_book_id, url_role, normalized_url) FROM stdin;
\.


--
-- Data for Name: carddav_address_books; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_address_books (id, account_id, canonical_url, discovery_alias_url, display_name, discovery_index, supports_sync_collection, supports_multiget, supported_vcard_versions, can_create, can_update, can_delete, is_write_target, is_subscribed, is_lookup_source, sync_token, sync_revision, needs_full_reconcile, last_seen_revision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carddav_conflicts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_conflicts (id, address_book_id, href, base_local_hash, local_hash, base_remote_hash, base_remote_etag, remote_etag, mapping_revision, review_revision, local_inference_revision, approved_local_body_sha256, approved_local_inference_revision, approved_conflict_revision, local_envelope_metadata, local_mutation_intent, local_body, remote_body, local_tombstone, remote_tombstone, pending_operation, connection_generation, book_sync_revision, previous_mapping_revision, pending_started_at, status, resolution, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carddav_discovery_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_discovery_lock (singleton) FROM stdin;
1
\.


--
-- Data for Name: carddav_publications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_publications (person_id, desired, address_book_id, href, pending_operation, outgoing_body, outgoing_semantic_hash, local_hash, remote_etag, connection_generation, book_sync_revision, mapping_revision, previous_mapping_revision, create_recovery_used, mutation_revision, outgoing_envelope_metadata, approved_body_sha256, approved_inference_revision, approved_mutation_revision, pending_started_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carddav_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_resources (id, address_book_id, href, remote_uid, remote_etag, remote_body, remote_semantic_hash, local_hash, mapping_status, mapping_revision, governance, person_id, person_revision_at_bind, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carddav_retry_gate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_retry_gate (account_id, retry_after_at, updated_at) FROM stdin;
\.


--
-- Data for Name: carddav_sync_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carddav_sync_runs (id, account_id, trigger, full_sync, state, started_at, finished_at, books, created, updated, removed, error_code, error_message) FROM stdin;
\.


--
-- Data for Name: chat_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_drafts (draft_id, source_id, conversation_id, source_conversation_id, conversation_type, reply_to_source_message_id, body, revision, created_at, updated_at, created_by_principal) FROM stdin;
\.


--
-- Data for Name: collection_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collection_sources (collection_id, source_id) FROM stdin;
1	1
\.


--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections (id, name, description, created_at) FROM stdin;
1	All	All accounts	2026-10-08 09:55:03.549937+00
\.


--
-- Data for Name: communication_service_aliases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_service_aliases (alias, service_id) FROM stdin;
twitter	7
gmessages	13
bsky	20
\.


--
-- Data for Name: communication_service_discoveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_service_discoveries (service_id, provider, discovery_kind) FROM stdin;
\.


--
-- Data for Name: communication_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_services (id, slug, display_label, scope_policy, default_scope_kind, normalization, normalization_version, uri_scheme, profile_url_template, is_system, is_active, created_at, updated_at) FROM stdin;
1	whatsapp	WhatsApp	none	\N	phone_e164	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
2	telegram	Telegram	none	\N	strip_at_lower	1	tg	https://t.me/{username}	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
3	facebook	Facebook	none	\N	strip_at_lower	1	\N	https://www.facebook.com/{username}	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
4	messenger	Messenger	none	\N	strip_at_lower	1	\N	https://m.me/{username}	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
5	instagram	Instagram	none	\N	strip_at_lower	1	\N	https://www.instagram.com/{username}	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
6	signal	Signal	none	\N	phone_e164	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
7	x	X	none	\N	strip_at_lower	1	\N	https://x.com/{username}	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
8	discord	Discord	none	\N	lower	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
9	slack	Slack	required	workspace	lower	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
10	linkedin	LinkedIn	none	\N	lower	1	\N	https://www.linkedin.com/in/{username}	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
11	sms	SMS	none	\N	phone_e164	1	sms	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
12	rcs	RCS	none	\N	phone_e164	1	sms	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
13	google-messages	Google Messages	none	\N	phone_e164	1	sms	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
14	google-voice	Google Voice	none	\N	phone_e164	1	tel	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
15	google-chat	Google Chat	optional	account	email	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
16	irc	IRC	required	network	lower	1	irc	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
17	groupme	GroupMe	none	\N	phone_e164	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
18	imessage	iMessage	none	\N	by_address_kind	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
19	line	LINE	none	\N	lower	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
20	bluesky	Bluesky	none	\N	strip_at_lower	1	\N	https://bsky.app/profile/{username}	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
21	matrix	Matrix	required	server	none	1	matrix	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
22	reddit	Reddit	none	\N	strip_at_lower	1	\N	https://www.reddit.com/user/{username}	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
23	kakaotalk	KakaoTalk	none	\N	lower	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
24	wechat	WeChat	none	\N	lower	1	\N	\N	t	t	2026-10-08 09:54:59.076549+00	2026-10-08 09:54:59.076549+00
\.


--
-- Data for Name: conversation_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_participants (conversation_id, participant_id, role, joined_at, left_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, source_id, source_conversation_id, conversation_type, title, participant_count, message_count, unread_count, last_message_at, last_message_preview, metadata, created_at, updated_at) FROM stdin;
1	1	default-thread	email_thread	Default Thread	0	0	0	\N	\N	\N	2026-10-08 09:55:05.405181+00	2026-10-08 09:55:05.405181+00
\.


--
-- Data for Name: daily_note_day_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_note_day_sequences (local_date, last_ordinal) FROM stdin;
\.


--
-- Data for Name: daily_note_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_note_entries (id, local_date, ordinal, body, author, source, source_ref, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: daily_note_entry_persons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_note_entry_persons (entry_id, person_id) FROM stdin;
\.


--
-- Data for Name: directory_people; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directory_people (person_id, order_key, contact_state, primary_channel, last_contact_key) FROM stdin;
\.


--
-- Data for Name: directory_person_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directory_person_filters (person_id, filter_kind, value_key) FROM stdin;
\.


--
-- Data for Name: directory_person_token_deletes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directory_person_token_deletes (person_id, delete_key) FROM stdin;
\.


--
-- Data for Name: directory_person_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directory_person_tokens (person_id, token_key) FROM stdin;
\.


--
-- Data for Name: directory_projection_dirty; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.directory_projection_dirty (person_id) FROM stdin;
\.


--
-- Data for Name: document_chunk_spans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_chunk_spans (extraction_id, chunk_key, span_ordinal, unit_index, start_char, end_char, synthetic) FROM stdin;
\.


--
-- Data for Name: document_chunks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_chunks (id, extraction_id, chunk_key, ordinal, text, heading_path, first_unit_index, last_unit_index, synthetic_prefix_len, checksum, char_count, table_chunk, code_chunk, truncated) FROM stdin;
\.


--
-- Data for Name: document_embedding_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_embedding_runs (id, invocation_key, trigger, state, started_at, finished_at, error_code, attempted, succeeded, failed) FROM stdin;
\.


--
-- Data for Name: document_extraction_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_extraction_claims (profile_id, canonical_blob_hash, extraction_input_key, extraction_id, lease_owner, lease_fence, lease_until, updated_at) FROM stdin;
\.


--
-- Data for Name: document_extraction_conversions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_extraction_conversions (extraction_id, provider_media_type, pdf_sha256, pdf_bytes, pages, policy_fingerprint, converter_version, spans) FROM stdin;
\.


--
-- Data for Name: document_extraction_heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_extraction_heads (profile_id, canonical_blob_hash, extraction_input_key, extraction_id, source_sequence, switched_at) FROM stdin;
\.


--
-- Data for Name: document_extraction_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_extraction_profiles (id, fingerprint, provider, endpoint, region, model, retention_posture, training_posture, allowed_media_types, include_inline, policy_json, enabled, created_at, retired_at) FROM stdin;
\.


--
-- Data for Name: document_extraction_rebuild_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_extraction_rebuild_targets (rebuild_id, canonical_blob_hash) FROM stdin;
\.


--
-- Data for Name: document_extraction_rebuilds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_extraction_rebuilds (id, profile_id, extraction_input_key, state, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: document_extraction_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_extraction_runs (id, invocation_key, trigger, state, started_at, finished_at, error_code, attempted, succeeded, failed) FROM stdin;
\.


--
-- Data for Name: document_extractions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_extractions (id, profile_id, rebuild_id, canonical_blob_hash, extraction_input_key, source_media_type, state, lease_owner, lease_fence, lease_until, attempt_count, request_count, retry_count, provider_latency_ms, next_retry_at, local_bytes, provider_bytes, units_processed, returned_model, manifest_checksum, normalization_version, document_family, unit_kind, normalized_truncated, terminal_reason, failure_reason, failure_detail, source_sequence, created_at, updated_at, published_at) FROM stdin;
\.


--
-- Data for Name: document_index_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_index_state (singleton, revision, target_profile_id, updated_at) FROM stdin;
1	0	\N	2026-10-08 09:54:02.669231+00
\.


--
-- Data for Name: document_occurrences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_occurrences (occurrence_key, attachment_id, message_id, source_id, source_part_key, stable_source_part, canonical_blob_hash, filename, mime_type, attachment_role, role_source, source_sequence, reconciled_at) FROM stdin;
\.


--
-- Data for Name: document_provider_consents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_provider_consents (profile_id, profile_fingerprint, retention_posture, training_posture, consented_at) FROM stdin;
\.


--
-- Data for Name: document_units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_units (extraction_id, unit_index, unit_kind, text, header_text, footer_text, width, height, dpi, checksum, char_count, truncated, heading_marks) FROM stdin;
\.


--
-- Data for Name: document_vector_build_progress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_vector_build_progress (generation_id, after_chunk_id, updated_at) FROM stdin;
\.


--
-- Data for Name: document_vector_consents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_vector_consents (egress_fingerprint, purpose, generation_fingerprint, target_extraction_profile_id, embedding_profile, model, dimension, consented_at) FROM stdin;
\.


--
-- Data for Name: document_vector_generations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_vector_generations (id, fingerprint, target_extraction_profile_id, embedding_profile, model, dimension, state, created_at, activated_at, retired_at) FROM stdin;
\.


--
-- Data for Name: document_vector_provider_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_vector_provider_usage (fingerprint, provider_calls, provider_documents, provider_chunks, provider_input_chars, updated_at) FROM stdin;
\.


--
-- Data for Name: document_vector_publications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_vector_publications (generation_id, extraction_id, extraction_profile_id, canonical_blob_hash, extraction_input_key, chunk_id, chunk_key, chunk_checksum, source_sequence, token, state, lease_owner, lease_fence, lease_until, attempt_count, next_retry_at, error_code, backend_cleaned_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: embedding_change_clock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.embedding_change_clock (singleton, sequence, enabled) FROM stdin;
1	0	f
\.


--
-- Data for Name: embedding_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.embedding_changes (sequence, kind, message_id, old_message_type, new_message_type, old_conversation_id, new_conversation_id, old_sent_at, new_sent_at, participant_id) FROM stdin;
\.


--
-- Data for Name: employments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employments (id, person_id, organization_id, title, title_normalized, role, department, location, address_id, description, start_year, start_month, start_day, end_year, end_month, end_day, is_current, is_primary, source, source_ref, confidence, revision, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gmail_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gmail_drafts (draft_id, source_id, gmail_draft_id, current_message_id, current_gmail_message_id, thread_id, revision, discarded_at, pending_operation, pending_original_message_id, pending_original_gmail_message_id, pending_raw, pending_replacement_gmail_message_id, pending_code, created_at, updated_at, created_by_principal) FROM stdin;
\.


--
-- Data for Name: identity_match_candidate_redirects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_match_candidate_redirects (retired_candidate_id, surviving_candidate_id, endpoints_collapsed) FROM stdin;
\.


--
-- Data for Name: identity_match_candidate_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_match_candidate_sources (candidate_id, source_id, is_conservative) FROM stdin;
\.


--
-- Data for Name: identity_match_candidates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_match_candidates (id, left_kind, left_id, right_kind, right_id, basis, service_id, scope_kind, scope_value, normalized_value, state, source, confidence, source_ref, observation_conflict_origin, pre_conflict_state, application_pending, decided_by, decided_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: identity_match_evidence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_match_evidence (id, candidate_id, evidence_kind, evidence_ref, detail, source, created_at) FROM stdin;
\.


--
-- Data for Name: identity_match_evidence_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_match_evidence_sources (evidence_id, source_id, is_conservative) FROM stdin;
\.


--
-- Data for Name: identity_match_review_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_match_review_decisions (candidate_id, evidence_fingerprint) FROM stdin;
\.


--
-- Data for Name: identity_match_review_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.identity_match_review_receipts (candidate_id, decision, review_token, evidence_fingerprint) FROM stdin;
\.


--
-- Data for Name: imap_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.imap_drafts (draft_id, source_id, current_message_id, current_mailbox, current_uidvalidity, current_uid, revision, discarded_at, pending_operation, pending_original_message_id, pending_original_mailbox, pending_original_uidvalidity, pending_original_uid, pending_raw, pending_replacement_mailbox, pending_replacement_uidvalidity, pending_replacement_uid, pending_code, created_at, updated_at, created_by_principal) FROM stdin;
\.


--
-- Data for Name: imap_folder_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.imap_folder_state (source_id, mailbox, uidvalidity, uidnext, highest_modseq, updated_at) FROM stdin;
\.


--
-- Data for Name: imap_message_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.imap_message_memberships (source_id, mailbox, uidvalidity, uid, message_id, flags, updated_at) FROM stdin;
\.


--
-- Data for Name: labels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labels (id, source_id, source_label_id, name, label_type, system_role, color) FROM stdin;
\.


--
-- Data for Name: mcp_event_clock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mcp_event_clock (singleton, head_seq, pruned_through_seq, capture_epoch, epoch_started_at, coverage_fingerprint, enabled) FROM stdin;
1	2	0	1	2026-10-08T09:55:05.679375918Z	a0b3b2228586c056d482d0b44e3c508e3e5437ab751e4914ad2ee8f376dd71a7	t
\.


--
-- Data for Name: mcp_event_dead_letters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mcp_event_dead_letters (subscription_id, seq, attempts, last_status_class, failed_at) FROM stdin;
\.


--
-- Data for Name: mcp_event_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mcp_event_log (seq, epoch, family, kind, scope_kind, scope_id, item_key, message_id, message_reference_seq, conversation_id, source_id, attachment_id, from_me, occurred_at, recorded_at, data) FROM stdin;
1	1	msgvault.message_archived	message	conversation	1	message:1	1	1	1	1	\N	f	2026-10-08T09:55:05.831546000Z	2026-10-08T09:55:06.004850142Z	{"kind":"message","message_id":"1","conversation_id":"1","source_id":"1","from_me":false,"sent_at":null,"archived_at":"2026-10-08T09:55:05.831546Z"}
2	1	msgvault.message_archived	message	conversation	1	message:5	5	2	1	1	\N	f	2026-10-08T09:55:06.502430000Z	2026-10-08T09:55:06.913436308Z	{"archived_at":"2026-10-08T09:55:06.50243Z","kind":"message","message_id":"5","conversation_id":"1","source_id":"1","from_me":false,"sent_at":null}
\.


--
-- Data for Name: mcp_event_message_refs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mcp_event_message_refs (message_id, reference_seq) FROM stdin;
1	1
5	2
\.


--
-- Data for Name: mcp_event_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mcp_event_subscriptions (id, principal_id, name, arguments, scope_kind, scope_id, source_id, callback_url, secret_enc, previous_secret_enc, previous_secret_until, secret_revision, verified_revision, verified_at, generation, state, stop_reason, expires_at, cursor_epoch, cursor_seq, pending_seq, pending_envelope, pending_generation, attempt_count, next_attempt_at, from_me_window_start, from_me_window_count, loop_guard_skips, dead_letter_count, last_outcome, created_at, updated_at) FROM stdin;
sub_cfd4ec5f91b01e412327617559a8ed74f1c695cc8ffc99a1caff83cf8f96975f	owner:434d16345e073024	msgvault.message_archived	{"conversation_id":"1","include_from_me":false,"include_reactions":true}	conversation	1	1	https://example.com/hook	\\x241b062935b8df4dc82cbe5f0338f7a26fe5b6f3061b0f57fa6bc1b95b2d3c5ceb53b7ee196c9efc9bf4638c5f01ffb736a4222e27380bcec9e18ae8	\N	\N	1	1	2026-10-08T09:55:05.773792820Z	1	active		2026-10-09T09:55:05.773792820Z	1	1	2	\\x7b226576656e744964223a22657674312e7375625f636664346563356639316230316534313233323736313735353961386564373466316336393563633866666339396131636166663833636638663936393735662e322e6a4d776431512d39464935586a534b4a395076355f67222c226e616d65223a226d73677661756c742e6d6573736167655f6172636869766564222c2274696d657374616d70223a22323032362d31302d30385430393a35353a30362e35303234335a222c2264617461223a7b2261726368697665645f6174223a22323032362d31302d30385430393a35353a30362e35303234335a222c226b696e64223a226d657373616765222c226d6573736167655f6964223a2235222c22636f6e766572736174696f6e5f6964223a2231222c22736f757263655f6964223a2231222c2266726f6d5f6d65223a66616c73652c2273656e745f6174223a6e756c6c7d2c22637572736f72223a2263312e312e322e4155445f4c327364776b6a5a69573170624e5f7a4a41227d	1	1	2026-10-08T09:55:06.997452764Z	\N	0	0	0	acknowledged	2026-10-08T09:55:05.773792820Z	2026-10-08T09:55:06.997452764Z
\.


--
-- Data for Name: mcp_live_admissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mcp_live_admissions (message_id, source_id, message_reference_seq, epoch, admitted_at) FROM stdin;
1	1	1	1	2026-10-08T09:55:06.004850142Z
5	1	2	1	2026-10-08T09:55:06.913436308Z
\.


--
-- Data for Name: meeting_action_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_action_items (message_id, ordinal, source_id, title, description, assignee_name, assignee_email, status, source_status, due_date, origin, locator) FROM stdin;
\.


--
-- Data for Name: meeting_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_details (message_id, projection_version, content_hash, content_json, duration_seconds, duration_basis, action_coverage, transcript_state) FROM stdin;
\.


--
-- Data for Name: message_bodies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_bodies (message_id, body_text, body_html) FROM stdin;
1	Synthetic body split across receipt-bound pages.	\N
3	Unrelated synthetic content must not be read	\N
5	Synthetic pending upgrade message	\N
\.


--
-- Data for Name: message_embedding_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_embedding_runs (id, invocation_key, trigger, state, started_at, finished_at, error_code, attempted, succeeded, failed, truncated) FROM stdin;
\.


--
-- Data for Name: message_labels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_labels (message_id, label_id) FROM stdin;
\.


--
-- Data for Name: message_raw; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_raw (message_id, raw_data, raw_format, compression, encryption_version) FROM stdin;
\.


--
-- Data for Name: message_recipients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_recipients (id, message_id, participant_id, recipient_type, display_name, email_address) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, conversation_id, source_id, source_message_id, rfc822_message_id, list_id, message_type, sent_at, received_at, read_at, delivered_at, internal_date, sender_id, is_from_me, source_is_from_me, identity_is_from_me, subject, snippet, reply_to_message_id, thread_position, is_read, is_delivered, is_sent, is_edited, is_forwarded, size_estimate, has_attachments, attachment_count, deleted_at, deleted_from_source_at, delete_batch_id, archived_at, indexing_version, metadata, last_modified, search_fts, embed_gen, content_changed_at) FROM stdin;
1	1	1	fixture-msg-1	\N	\N	email	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	t	\N	t	f	f	1000	f	0	\N	\N	\N	2026-10-08 09:55:05.831546+00	\N	\N	2026-10-08 09:55:05.831546+00	\N	\N	2026-10-08 09:55:05.944765+00
3	1	1	fixture-msg-2	\N	\N	email	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	t	\N	t	f	f	1000	f	0	\N	\N	\N	2026-10-08 09:55:06.197501+00	\N	\N	2026-10-08 09:55:06.197501+00	\N	\N	2026-10-08 09:55:06.322551+00
5	1	1	fixture-msg-3	\N	\N	email	\N	\N	\N	\N	\N	\N	f	f	f	\N	\N	\N	\N	t	\N	t	f	f	1000	f	0	\N	\N	\N	2026-10-08 09:55:06.50243+00	\N	\N	2026-10-08 09:55:06.50243+00	\N	\N	2026-10-08 09:55:06.637204+00
\.


--
-- Data for Name: operation_history_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operation_history_state (singleton, membership_revision) FROM stdin;
1	0
\.


--
-- Data for Name: operation_token_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operation_token_keys (key_id, key_bytes, state, created_at, retired_at) FROM stdin;
\.


--
-- Data for Name: organization_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_addresses (id, organization_id, address_kind, post_office_box, extended_address, street_address, locality, region, postal_code, country_name, extended_components, free_text, label, geo_uri, timezone, country_code, place_uri, original_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: organization_attribute_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_attribute_values (id, organization_id, definition_id, ordinal, value_text, value_integer, value_real, value_boolean, value_date, value_timestamp, value_json, value_record_type, value_record_id, active_from, active_until, created_at, superseded_at, source, source_ref, confidence, actor) FROM stdin;
\.


--
-- Data for Name: organization_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_categories (id, organization_id, original_value, normalized_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: organization_contact_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_contact_points (id, organization_id, address_kind, service_id, scope_kind, scope_value, original_value, normalized_value, normalization, normalization_version, uri, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: organization_identifiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_identifiers (id, organization_id, identifier_kind, identifier_value, normalized_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: organization_media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_media (id, organization_id, media_kind, media_type, uri, data, byte_size, content_hash, original_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: organization_names; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization_names (id, organization_id, name_kind, formatted, original_value, name_normalized, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organizations (id, name, name_normalized, kind, primary_domain, description, revision, merged_into_id, retired_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: participant_contact_observations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.participant_contact_observations (id, participant_id, source_id, address_kind, service_id, scope_kind, scope_value, provider_user_id, original_value, normalized_value, normalization, normalization_version, observed_at, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: participant_identifiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.participant_identifiers (id, participant_id, identifier_type, identifier_value, display_value, is_primary, service_id, scope_kind, scope_value) FROM stdin;
\.


--
-- Data for Name: participant_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.participant_links (participant_a, participant_b, identity_match_candidate_id, created_at) FROM stdin;
\.


--
-- Data for Name: participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.participants (id, email_address, phone_number, display_name, domain, canonical_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: person_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_addresses (id, person_id, address_kind, post_office_box, extended_address, street_address, locality, region, postal_code, country_name, extended_components, free_text, label, geo_uri, timezone, country_code, place_uri, original_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: person_attribute_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_attribute_values (id, person_id, definition_id, ordinal, value_text, value_integer, value_real, value_boolean, value_date, value_timestamp, value_json, value_record_type, value_record_id, active_from, active_until, created_at, superseded_at, source, source_ref, confidence, actor) FROM stdin;
\.


--
-- Data for Name: person_brief_enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_brief_enrollments (person_id, enabled_at, actor) FROM stdin;
\.


--
-- Data for Name: person_brief_evidence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_brief_evidence (brief_id, evidence_id, ordinal) FROM stdin;
\.


--
-- Data for Name: person_briefs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_briefs (id, person_id, version, generation_id, status, program_id, program_version, program_fingerprint, provider, provider_version, model, model_version, provider_policy_fingerprint, boundary_json, structured_json, rendered_text, renderer_policy, dropped_item_count, generated_at, superseded_at, rejected_at, rejected_reason, created_at) FROM stdin;
\.


--
-- Data for Name: person_carddav_inference_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_carddav_inference_state (person_id, inference_revision, approved_revision, approved_connection_generation, approved_address_book_id) FROM stdin;
\.


--
-- Data for Name: person_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_categories (id, person_id, original_value, normalized_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: person_contact_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_contact_points (id, person_id, address_kind, service_id, scope_kind, scope_value, original_value, normalized_value, normalization, normalization_version, uri, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: person_contact_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_contact_state (person_id, first_contact_at, first_contact_message_id, last_contact_at, last_contact_message_id, last_contact_channel, last_contact_source_id, last_contact_owner, last_inbound_at, last_inbound_message_id, last_outbound_at, last_outbound_message_id, interaction_count, identity_revision, account_identity_revision, dirty_at, computed_at) FROM stdin;
\.


--
-- Data for Name: person_dates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_dates (id, person_id, date_kind, label, date_year, date_month, date_day, date_text, calendar_scale, original_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: person_embedding_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_embedding_runs (id, invocation_key, trigger, state, started_at, finished_at, error_code, attempted, succeeded, failed, truncated) FROM stdin;
\.


--
-- Data for Name: person_enrichment_attempt_citations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_attempt_citations (attempt_id, citation_id) FROM stdin;
\.


--
-- Data for Name: person_enrichment_attempt_identifiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_attempt_identifiers (attempt_id, provider_namespace, identifier_class, normalization_version, key_id, digest) FROM stdin;
\.


--
-- Data for Name: person_enrichment_attempt_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_attempt_sources (attempt_id, canonical_url, outcome, observed_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_attempts (id, run_id, person_id, profile_fingerprint, trigger_kind, trigger_generation, person_revision, payload_hash, request_hash, fact_generation_key, state, provider_request_id, provider_job_id, adapter_version, schema_version, generated_schema, generated_schema_hash, targets_json, program_fingerprint, provider_started_at, dispatch_authorized_at, lease_owner, lease_fence, lease_until, next_action_at, attempt_count, hard_cost_cap_enforced, reserved_cost_usd_micros, actual_cost_usd_micros, failure_class, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_citations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_citations (id, person_id, citation_key, canonical_url, title, publisher, excerpt, published_at, retrieved_at, created_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_consents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_consents (id, profile_fingerprint, granted_by, granted_at, revoked_by, revoked_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_day_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_day_counters (profile_fingerprint, utc_day, requests_started, cost_reserved_usd_micros, cost_charged_usd_micros) FROM stdin;
\.


--
-- Data for Name: person_enrichment_manual_run_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_manual_run_targets (run_id, person_id, profile_fingerprint, created_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_person_day_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_person_day_counters (person_id, profile_fingerprint, utc_day, requests_started, cost_reserved_usd_micros, cost_charged_usd_micros) FROM stdin;
\.


--
-- Data for Name: person_enrichment_profile_accounting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_profile_accounting (profile_fingerprint, starts_disabled, safe_error, disabled_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_profiles (fingerprint, provider_name, provider_kind, provider_namespace, endpoint, api_key_env, policy_json, created_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_provider_identities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_provider_identities (person_id, provider_namespace, provider_person_id, confidence, verified_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_run_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_run_counters (run_id, requests_started, cost_reserved_usd_micros, cost_charged_usd_micros) FROM stdin;
\.


--
-- Data for Name: person_enrichment_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_runs (id, kind, requested_by, requested_at, started_at, completed_at, state, requested_count, started_count, succeeded_count, failed_count, suppressed_count, identity_rejected_count, failure_class, safe_error) FROM stdin;
\.


--
-- Data for Name: person_enrichment_suppressions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_suppressions (id, provider_namespace, identifier_class, normalization_version, key_id, digest, reason, actor, created_at) FROM stdin;
\.


--
-- Data for Name: person_enrichment_work; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_enrichment_work (person_id, profile_fingerprint, trigger_mask, trigger_generation, due_at, lease_owner, lease_fence, lease_until, run_id, active_attempt_id, has_fresh_trigger) FROM stdin;
\.


--
-- Data for Name: person_fact_claim_evidence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_fact_claim_evidence (claim_id, evidence_id) FROM stdin;
\.


--
-- Data for Name: person_fact_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_fact_claims (id, person_id, generation_id, claim_key, target_kind, target_key, target_revision, relation, submitted_value_json, normalized_value_json, value_fingerprint, valid_from, valid_until, origin, confidence_json, rejection_action, rejection_reason, rejection_detail, created_at) FROM stdin;
\.


--
-- Data for Name: person_fact_decisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_fact_decisions (id, person_id, resolution_id, claim_id, decision_key, action, reason, score_json, competing_claim_id, projection_kind, projection_row_id, resolved_organization_id, created_at) FROM stdin;
\.


--
-- Data for Name: person_fact_evidence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_fact_evidence (id, person_id, evidence_key, source_class, directness, authority, source_ref, source_url, subject_person_id, subject_ref, span_start, span_end, excerpt, content_sha256, source_version, event_time, recorded_time, identity_score, created_at) FROM stdin;
\.


--
-- Data for Name: person_fact_evidence_status_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_fact_evidence_status_events (id, person_id, generation_id, evidence_id, evidence_key, source_version, supported, reason, created_at) FROM stdin;
\.


--
-- Data for Name: person_fact_generations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_fact_generations (id, person_id, generation_key, source_cursors_json, program_id, program_version, program_fingerprint, catalog_fingerprint, provider, provider_version, model, model_version, provider_policy_fingerprint, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: person_fact_pin_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_fact_pin_events (id, person_id, target_kind, target_key, target_revision, pinned, actor, created_at) FROM stdin;
\.


--
-- Data for Name: person_fact_resolutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_fact_resolutions (id, person_id, generation_id, target_kind, target_key, target_revision, resolver_version, input_fingerprint, provider_policy_fingerprint, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: person_inference_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_inference_checks (profile_fingerprint, checked_at, driver_version, output_mode, provider_request_id, model_version) FROM stdin;
\.


--
-- Data for Name: person_inference_consents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_inference_consents (id, profile_fingerprint, granted_by, granted_at, revoked_by, revoked_at) FROM stdin;
\.


--
-- Data for Name: person_inference_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_inference_profiles (fingerprint, provider_kind, endpoint, model, api_key_env, allow_anonymous, auth_scheme, credential_source, credential_ref, output_mode, token_limit_parameter, reasoning_effort, reasoning_mode, driver_version, retention_posture, training_posture, allowed_sources, source_since, source_until, allow_sensitive, execution_boundary, packet_renderer_policy, program_fingerprint, disclosed_packet_fields, policy_json, created_at) FROM stdin;
\.


--
-- Data for Name: person_match_consents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_match_consents (id, disclosure_fingerprint, endpoint, model_id, packet_schema, retention_declaration, policy_version, question_version, granted_by, granted_at, revoked_by, revoked_at) FROM stdin;
\.


--
-- Data for Name: person_match_judgment_cursor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_match_judgment_cursor (singleton, candidate_id, started_at_zero) FROM stdin;
\.


--
-- Data for Name: person_match_judgment_work; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_match_judgment_work (candidate_id, fingerprint, lease_owner, lease_token, lease_until, attempt_count, retry_after_at) FROM stdin;
\.


--
-- Data for Name: person_match_judgments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_match_judgments (id, candidate_id, fingerprint, model_id, question_version, policy_version, probability, blockers_json, outcome, status, error_class, retry_after_at, created_at) FROM stdin;
\.


--
-- Data for Name: person_media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_media (id, person_id, media_kind, media_type, uri, data, byte_size, content_hash, original_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: person_merge_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_merge_participants (merge_id, participant_id, origin_side, split_id) FROM stdin;
\.


--
-- Data for Name: person_merge_review_candidates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_merge_review_candidates (id, merge_id, survivor_person_id, definition_id, survivor_value_id, absorbed_value_id, state, resolution_value_id, reviewed_by, reviewed_at, created_at) FROM stdin;
\.


--
-- Data for Name: person_merge_row_person_refs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_merge_row_person_refs (merge_id, table_name, original_row_key, column_name, person_id) FROM stdin;
\.


--
-- Data for Name: person_merge_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_merge_rows (merge_id, table_name, original_row_id, original_row_key, current_row_id, current_row_key, origin_side, provenance_kind, participant_id, action, snapshot_path, post_merge_row_json, split_id) FROM stdin;
\.


--
-- Data for Name: person_merges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_merges (id, idempotency_key, request_hash, survivor_person_id_at_merge, absorbed_person_id, current_person_id, survivor_uid, absorbed_uid, survivor_revision_before, absorbed_revision_before, survivor_revision_after, actor, snapshot_version, snapshot_blob, snapshot_sha256, result_json, identity_revision, created_at) FROM stdin;
\.


--
-- Data for Name: person_names; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_names (id, person_id, name_kind, formatted, family_name, given_name, additional_names, honorific_prefixes, honorific_suffixes, secondary_surname, generation, language, script, phonetic_system, phonetic_script, sort_as, is_derived, original_value, pref, ordinal, type_label, type_tokens, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, source, source_ref, source_resource_uid, confidence, active_from, active_until, created_at, updated_at, superseded_at) FROM stdin;
\.


--
-- Data for Name: person_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_participants (person_id, participant_id) FROM stdin;
\.


--
-- Data for Name: person_relationship_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_relationship_reviews (id, person_id, raw_related_value, raw_related_type, value_kind, matched_person_id, accepted_relationship_id, status, source, source_ref, source_resource_uid, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, created_by, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: person_relationships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_relationships (id, source_person_id, target_person_id, relationship_type_id, start_year, start_month, start_day, end_year, end_month, end_day, status, notes, source, source_ref, source_resource_uid, confidence, vcard_property, vcard_group, vcard_prop_id, vcard_pid, vcard_altid, created_by, updated_by, revision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: person_semantic_embedding_consents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_semantic_embedding_consents (id, profile_fingerprint, granted_by, granted_at, revoked_by, revoked_at) FROM stdin;
\.


--
-- Data for Name: person_semantic_embedding_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_semantic_embedding_profiles (fingerprint, purpose, destination, api_format, model, api_key_env, retention_posture, training_posture, renderer_policy, disclosed_field_classes, corpus_scope, policy_json, created_at) FROM stdin;
\.


--
-- Data for Name: person_splits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_splits (id, merge_id, idempotency_key, request_hash, source_person_id, new_person_id, new_person_uid, source_revision_before, source_revision_after, actor, is_exact_reversal, result_json, identity_revision, created_at) FROM stdin;
\.


--
-- Data for Name: person_sweep_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_attempts (id, run_id, person_id, lease_fence, mode, status, failure_class, brief_failure_class, cursor_envelope_json, envelope_hash, program_fingerprint, catalog_fingerprint, provider_fingerprint, generation_id, generation_key, seed_count, context_count, claim_count, decision_count, projected_write_count, request_count, provider_request_id, input_tokens, output_tokens, estimated_cost_micro_usd, latency_milliseconds, retry_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: person_sweep_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_batches (attempt_id, batch_ordinal, call_ordinal, purpose, utc_day, reservation_id, budget_fingerprint, input_hash, item_count, status, provider_request_id, reserved_requests, reserved_input_tokens, reserved_output_tokens, reserved_cost_micro_usd, actual_requests, actual_input_tokens, actual_output_tokens, actual_cost_micro_usd, latency_milliseconds, failure_class, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: person_sweep_change_clock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_change_clock (singleton, sequence, enabled) FROM stdin;
t	0	t
\.


--
-- Data for Name: person_sweep_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_changes (sequence, person_id, source_lane, change_kind, evidence_effect, source_id, message_id, attachment_id, occurrence_key, recorded_at) FROM stdin;
\.


--
-- Data for Name: person_sweep_cursors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_cursors (person_id, source_lane, program_fingerprint, catalog_fingerprint, optimistic_sequence, optimistic_document_key, reconcile_upper_key, reconcile_after_key, reconcile_document_key, reconciliation_complete, backstop_upper_key, backstop_after_key, backstop_document_key, last_backstop_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: person_sweep_daily_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_daily_usage (utc_day, reserved_requests, reserved_input_tokens, reserved_output_tokens, reserved_cost_micro_usd, actual_requests, actual_input_tokens, actual_output_tokens, actual_cost_micro_usd, updated_at) FROM stdin;
\.


--
-- Data for Name: person_sweep_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_runs (id, kind, mode, status, program_fingerprint, catalog_fingerprint, provider_fingerprint, attempt_count, success_count, failure_count, projected_write_count, actual_requests, actual_input_tokens, actual_output_tokens, actual_cost_micro_usd, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: person_sweep_sync_publications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_sync_publications (sync_run_id, source_id, lower_sequence, upper_sequence, published_at) FROM stdin;
\.


--
-- Data for Name: person_sweep_work; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_sweep_work (person_id, dirty_through_sequence, available_at, attempt_count, last_failure_class, lease_owner, lease_until, lease_fence, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: person_tracking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_tracking (person_id, tracked_at) FROM stdin;
\.


--
-- Data for Name: person_uid_aliases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_uid_aliases (retired_uid, surviving_person_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: persons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.persons (id, vcard_uid, display_name, revision, vcard_projection_revision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reaction_source_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reaction_source_events (source_id, source_reaction_id, reaction_id) FROM stdin;
\.


--
-- Data for Name: reactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reactions (id, message_id, participant_id, reaction_type, reaction_value, created_at, removed_at) FROM stdin;
\.


--
-- Data for Name: relationship_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relationship_types (id, universal_id, slug, forward_label, reverse_label, is_symmetric, is_canonical, inverse_type_id, vcard_related_type, color, icon, description, ownership, is_deletable, revision, created_at, updated_at) FROM stdin;
1	dd74c978-cc03-4fce-875f-c6d03b84feeb	contact	contact	contact	t	t	\N	contact	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
2	dcee8148-7f92-4cdf-ac12-e33fb36a5ceb	acquaintance	acquaintance	acquaintance	t	t	\N	acquaintance	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
3	a1121fb7-8c6b-40d4-9fe1-1cb62dabbd88	friend	friend	friend	t	t	\N	friend	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
4	70cda530-be30-4cd5-8ef3-3ac197277d9d	met	met	met	t	t	\N	met	\N	\N	The two people have met in person.	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
5	523f6e4a-b439-4b44-9c0a-ba5d6145c138	co-worker	co-worker	co-worker	t	t	\N	co-worker	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
6	3d2b5f28-4168-497a-a66f-9ed12fe54223	colleague	colleague	colleague	t	t	\N	colleague	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
7	e9942842-51d2-465b-9fbd-81ed348fdc2e	co-resident	co-resident	co-resident	t	t	\N	co-resident	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
8	32a4e047-848f-4302-957a-4f3736ee29e9	neighbor	neighbor	neighbor	t	t	\N	neighbor	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
9	b94d3c6c-dd83-4861-a42e-3fc1e5e684df	sibling	sibling	sibling	t	t	\N	sibling	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
10	9f055281-6064-40ea-86fc-6b1a5d620d0b	spouse	spouse	spouse	t	t	\N	spouse	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
11	8d29030b-cd28-4966-96d2-3beddbbc579a	kin	relative	relative	t	t	\N	kin	\N	\N	A family relative whose exact relation is unspecified.	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
12	1f6c13b3-496a-4817-b416-6d07b8adb764	date	date	date	t	t	\N	date	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
13	80cedce5-5e11-4dee-87ff-39846d97d674	sweetheart	sweetheart	sweetheart	t	t	\N	sweetheart	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
15	676d5466-8ecc-4cb9-a801-042e8ea87341	child	child	parent	f	f	14	child	\N	\N	The non-canonical orientation of the parent/child pair, kept so RELATED;TYPE=child maps losslessly.	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
16	7202c876-95b3-42c1-920a-54586fc445f3	muse	muse	inspired by	f	t	\N	muse	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
17	8eecd031-7f3c-4740-9290-46a8399e25d2	crush	crush	admirer	f	t	\N	crush	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
18	6f2ee644-ba8d-414b-9134-a800701c1aca	agent	agent	principal	f	t	\N	agent	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
19	3f3916a0-de39-445d-96ee-7a242a4071f2	emergency	emergency contact	emergency contact for	f	t	\N	emergency	\N	\N	\N	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
14	cb3869d4-683b-48e3-a30a-4e8f7e7dc7fb	parent	parent	child	f	t	15	parent	\N	\N	The canonical orientation of the parent/child pair; a 'child' write is stored as 'parent' with the endpoints swapped.	system	f	1	2026-10-08 09:55:03.221705+00	2026-10-08 09:55:03.221705+00
\.


--
-- Data for Name: saved_views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_views (id, name, description, canonical_state, schema_version, revision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: source_import_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.source_import_items (id, source_id, provider, provider_id, name, checksum, size, modified_at, imported_at, status, records_imported, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sources (id, source_type, identifier, display_name, google_user_id, last_sync_at, sync_cursor, sync_config, oauth_app, created_at, updated_at) FROM stdin;
1	gmail	test@example.com	\N	\N	\N	\N	\N	\N	2026-10-08 09:55:05.380136+00	2026-10-08 09:55:05.380136+00
\.


--
-- Data for Name: sync_checkpoints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sync_checkpoints (source_id, checkpoint_type, checkpoint_value, updated_at) FROM stdin;
\.


--
-- Data for Name: sync_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sync_operations (id, source_id, status, created_at, started_at, finished_at) FROM stdin;
\.


--
-- Data for Name: sync_run_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sync_run_items (id, sync_run_id, source_message_id, phase, status, error_kind, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: sync_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sync_runs (id, source_id, sync_type, started_at, completed_at, status, messages_processed, messages_added, messages_updated, errors_count, error_message, cursor_before, cursor_after, request_fingerprint, operation_id) FROM stdin;
\.


--
-- Data for Name: vcard_resource_envelopes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vcard_resource_envelopes (id, person_id, canonical_person_uid, source_ref, source_resource_uid, href, original_raw_bytes, stored_body, resource_metadata, projection_fingerprint, content_hash, etag, revision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: visual_embedding_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visual_embedding_runs (id, invocation_key, trigger, state, started_at, finished_at, error_code, attempted, succeeded, failed, skipped) FROM stdin;
\.


--
-- Data for Name: visual_generations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visual_generations (id, fingerprint, model, dimension, state, source_fence, consented_at, consent_policy_fingerprint, capability_fingerprint, created_at, activated_at) FROM stdin;
\.


--
-- Data for Name: visual_obsolete_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visual_obsolete_tokens (generation_id, vector_token, created_at) FROM stdin;
\.


--
-- Data for Name: visual_publications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visual_publications (generation_id, message_id, blob_hash, media_input_key, published_revision, prepared_revision, source_fence, representative_attachment_id, attachment_role, role_source, current_vector_token, pending_vector_token, state, outcome_kind, outcome_reason, updated_at) FROM stdin;
\.


--
-- Data for Name: visual_work_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visual_work_claims (generation_id, message_id, blob_hash, media_input_key, proposed_revision, lease_owner, lease_expires_at, fencing_token, source_fence, claimed_content_stamp, updated_at) FROM stdin;
\.


--
-- Name: attachment_change_log_sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachment_change_log_sequence_seq', 1, false);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, false);


--
-- Name: attribute_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attribute_definitions_id_seq', 17, true);


--
-- Name: carddav_address_books_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carddav_address_books_id_seq', 1, false);


--
-- Name: carddav_conflicts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carddav_conflicts_id_seq', 1, false);


--
-- Name: carddav_resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carddav_resources_id_seq', 1, false);


--
-- Name: carddav_sync_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carddav_sync_runs_id_seq', 1, false);


--
-- Name: collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.collections_id_seq', 1, true);


--
-- Name: communication_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.communication_services_id_seq', 24, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, true);


--
-- Name: daily_note_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_note_entries_id_seq', 1, false);


--
-- Name: document_chunks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_chunks_id_seq', 1, false);


--
-- Name: document_embedding_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_embedding_runs_id_seq', 1, false);


--
-- Name: document_extraction_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_extraction_runs_id_seq', 1, false);


--
-- Name: document_vector_generations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_vector_generations_id_seq', 1, false);


--
-- Name: employments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employments_id_seq', 1, false);


--
-- Name: identity_match_candidates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.identity_match_candidates_id_seq', 1, false);


--
-- Name: identity_match_evidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.identity_match_evidence_id_seq', 1, false);


--
-- Name: labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.labels_id_seq', 1, false);


--
-- Name: message_embedding_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_embedding_runs_id_seq', 1, false);


--
-- Name: message_recipients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_recipients_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 6, true);


--
-- Name: organization_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_addresses_id_seq', 1, false);


--
-- Name: organization_attribute_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_attribute_values_id_seq', 1, false);


--
-- Name: organization_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_categories_id_seq', 1, false);


--
-- Name: organization_contact_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_contact_points_id_seq', 1, false);


--
-- Name: organization_identifiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_identifiers_id_seq', 1, false);


--
-- Name: organization_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_media_id_seq', 1, false);


--
-- Name: organization_names_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organization_names_id_seq', 1, false);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organizations_id_seq', 1, false);


--
-- Name: participant_contact_observations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.participant_contact_observations_id_seq', 1, false);


--
-- Name: participant_identifiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.participant_identifiers_id_seq', 1, false);


--
-- Name: participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.participants_id_seq', 1, false);


--
-- Name: person_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_addresses_id_seq', 1, false);


--
-- Name: person_attribute_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_attribute_values_id_seq', 1, false);


--
-- Name: person_briefs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_briefs_id_seq', 1, false);


--
-- Name: person_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_categories_id_seq', 1, false);


--
-- Name: person_contact_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_contact_points_id_seq', 1, false);


--
-- Name: person_dates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_dates_id_seq', 1, false);


--
-- Name: person_embedding_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_embedding_runs_id_seq', 1, false);


--
-- Name: person_enrichment_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_enrichment_attempts_id_seq', 1, false);


--
-- Name: person_enrichment_citations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_enrichment_citations_id_seq', 1, false);


--
-- Name: person_enrichment_consents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_enrichment_consents_id_seq', 1, false);


--
-- Name: person_enrichment_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_enrichment_runs_id_seq', 1, false);


--
-- Name: person_enrichment_suppressions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_enrichment_suppressions_id_seq', 1, false);


--
-- Name: person_fact_claims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_fact_claims_id_seq', 1, false);


--
-- Name: person_fact_decisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_fact_decisions_id_seq', 1, false);


--
-- Name: person_fact_evidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_fact_evidence_id_seq', 1, false);


--
-- Name: person_fact_evidence_status_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_fact_evidence_status_events_id_seq', 1, false);


--
-- Name: person_fact_generations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_fact_generations_id_seq', 1, false);


--
-- Name: person_fact_pin_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_fact_pin_events_id_seq', 1, false);


--
-- Name: person_fact_resolutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_fact_resolutions_id_seq', 1, false);


--
-- Name: person_inference_consents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_inference_consents_id_seq', 1, false);


--
-- Name: person_match_consents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_match_consents_id_seq', 1, false);


--
-- Name: person_match_judgments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_match_judgments_id_seq', 1, false);


--
-- Name: person_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_media_id_seq', 1, false);


--
-- Name: person_merge_review_candidates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_merge_review_candidates_id_seq', 1, false);


--
-- Name: person_merges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_merges_id_seq', 1, false);


--
-- Name: person_names_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_names_id_seq', 1, false);


--
-- Name: person_relationship_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_relationship_reviews_id_seq', 1, false);


--
-- Name: person_relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_relationships_id_seq', 1, false);


--
-- Name: person_semantic_embedding_consents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_semantic_embedding_consents_id_seq', 1, false);


--
-- Name: person_splits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.person_splits_id_seq', 1, false);


--
-- Name: persons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.persons_id_seq', 1, false);


--
-- Name: reactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reactions_id_seq', 1, false);


--
-- Name: relationship_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.relationship_types_id_seq', 19, true);


--
-- Name: saved_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.saved_views_id_seq', 1, false);


--
-- Name: source_import_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.source_import_items_id_seq', 1, false);


--
-- Name: sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sources_id_seq', 1, true);


--
-- Name: sync_run_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sync_run_items_id_seq', 1, false);


--
-- Name: sync_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sync_runs_id_seq', 1, false);


--
-- Name: vcard_resource_envelopes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vcard_resource_envelopes_id_seq', 1, false);


--
-- Name: visual_embedding_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.visual_embedding_runs_id_seq', 1, false);


--
-- Name: visual_generations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.visual_generations_id_seq', 1, false);


--
-- Name: account_identities account_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_identities
    ADD CONSTRAINT account_identities_pkey PRIMARY KEY (source_id, address);


--
-- Name: activity_event_persons activity_event_persons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_event_persons
    ADD CONSTRAINT activity_event_persons_pkey PRIMARY KEY (message_id, person_id);


--
-- Name: activity_events activity_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_events
    ADD CONSTRAINT activity_events_pkey PRIMARY KEY (message_id);


--
-- Name: activity_projection_queue activity_projection_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_projection_queue
    ADD CONSTRAINT activity_projection_queue_pkey PRIMARY KEY (message_id);


--
-- Name: applied_migrations applied_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applied_migrations
    ADD CONSTRAINT applied_migrations_pkey PRIMARY KEY (name);


--
-- Name: archive_metadata archive_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archive_metadata
    ADD CONSTRAINT archive_metadata_pkey PRIMARY KEY (key);


--
-- Name: attachment_change_consumers attachment_change_consumers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_change_consumers
    ADD CONSTRAINT attachment_change_consumers_pkey PRIMARY KEY (consumer_key);


--
-- Name: attachment_change_log attachment_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_change_log
    ADD CONSTRAINT attachment_change_log_pkey PRIMARY KEY (sequence);


--
-- Name: attachment_pack_index attachment_pack_index_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_pack_index
    ADD CONSTRAINT attachment_pack_index_pkey PRIMARY KEY (blob_hash);


--
-- Name: attachment_packs attachment_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_packs
    ADD CONSTRAINT attachment_packs_pkey PRIMARY KEY (pack_id);


--
-- Name: attachment_role_repair_progress attachment_role_repair_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_role_repair_progress
    ADD CONSTRAINT attachment_role_repair_progress_pkey PRIMARY KEY (singleton);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: attribute_definitions attribute_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute_definitions
    ADD CONSTRAINT attribute_definitions_pkey PRIMARY KEY (id);


--
-- Name: attribute_definitions attribute_definitions_universal_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute_definitions
    ADD CONSTRAINT attribute_definitions_universal_id_key UNIQUE (universal_id);


--
-- Name: beeper_drafts beeper_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beeper_drafts
    ADD CONSTRAINT beeper_drafts_pkey PRIMARY KEY (draft_id);


--
-- Name: beeper_media_deliveries beeper_media_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beeper_media_deliveries
    ADD CONSTRAINT beeper_media_deliveries_pkey PRIMARY KEY (destination_key, processing_key);


--
-- Name: beeper_media_occurrences beeper_media_occurrences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beeper_media_occurrences
    ADD CONSTRAINT beeper_media_occurrences_pkey PRIMARY KEY (destination_key, occurrence_ref, revision);


--
-- Name: carddav_account_home_urls carddav_account_home_urls_account_id_discovery_index_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_account_home_urls
    ADD CONSTRAINT carddav_account_home_urls_account_id_discovery_index_key UNIQUE (account_id, discovery_index);


--
-- Name: carddav_account_home_urls carddav_account_home_urls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_account_home_urls
    ADD CONSTRAINT carddav_account_home_urls_pkey PRIMARY KEY (account_id, home_url);


--
-- Name: carddav_accounts carddav_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_accounts
    ADD CONSTRAINT carddav_accounts_pkey PRIMARY KEY (id);


--
-- Name: carddav_address_book_urls carddav_address_book_urls_account_id_normalized_url_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_address_book_urls
    ADD CONSTRAINT carddav_address_book_urls_account_id_normalized_url_key UNIQUE (account_id, normalized_url);


--
-- Name: carddav_address_book_urls carddav_address_book_urls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_address_book_urls
    ADD CONSTRAINT carddav_address_book_urls_pkey PRIMARY KEY (address_book_id, url_role);


--
-- Name: carddav_address_books carddav_address_books_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_address_books
    ADD CONSTRAINT carddav_address_books_pkey PRIMARY KEY (id);


--
-- Name: carddav_conflicts carddav_conflicts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_conflicts
    ADD CONSTRAINT carddav_conflicts_pkey PRIMARY KEY (id);


--
-- Name: carddav_discovery_lock carddav_discovery_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_discovery_lock
    ADD CONSTRAINT carddav_discovery_lock_pkey PRIMARY KEY (singleton);


--
-- Name: carddav_publications carddav_publications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_publications
    ADD CONSTRAINT carddav_publications_pkey PRIMARY KEY (person_id);


--
-- Name: carddav_resources carddav_resources_address_book_id_href_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_resources
    ADD CONSTRAINT carddav_resources_address_book_id_href_key UNIQUE (address_book_id, href);


--
-- Name: carddav_resources carddav_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_resources
    ADD CONSTRAINT carddav_resources_pkey PRIMARY KEY (id);


--
-- Name: carddav_retry_gate carddav_retry_gate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_retry_gate
    ADD CONSTRAINT carddav_retry_gate_pkey PRIMARY KEY (account_id);


--
-- Name: carddav_sync_runs carddav_sync_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_sync_runs
    ADD CONSTRAINT carddav_sync_runs_pkey PRIMARY KEY (id);


--
-- Name: chat_drafts chat_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_drafts
    ADD CONSTRAINT chat_drafts_pkey PRIMARY KEY (draft_id);


--
-- Name: collection_sources collection_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_sources
    ADD CONSTRAINT collection_sources_pkey PRIMARY KEY (collection_id, source_id);


--
-- Name: collections collections_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_name_key UNIQUE (name);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- Name: communication_service_aliases communication_service_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_service_aliases
    ADD CONSTRAINT communication_service_aliases_pkey PRIMARY KEY (alias);


--
-- Name: communication_service_discoveries communication_service_discoveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_service_discoveries
    ADD CONSTRAINT communication_service_discoveries_pkey PRIMARY KEY (service_id, provider, discovery_kind);


--
-- Name: communication_services communication_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_services
    ADD CONSTRAINT communication_services_pkey PRIMARY KEY (id);


--
-- Name: communication_services communication_services_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_services
    ADD CONSTRAINT communication_services_slug_key UNIQUE (slug);


--
-- Name: conversation_participants conversation_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_pkey PRIMARY KEY (conversation_id, participant_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_source_id_source_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_source_id_source_conversation_id_key UNIQUE (source_id, source_conversation_id);


--
-- Name: daily_note_day_sequences daily_note_day_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_note_day_sequences
    ADD CONSTRAINT daily_note_day_sequences_pkey PRIMARY KEY (local_date);


--
-- Name: daily_note_entries daily_note_entries_local_date_ordinal_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_note_entries
    ADD CONSTRAINT daily_note_entries_local_date_ordinal_key UNIQUE (local_date, ordinal);


--
-- Name: daily_note_entries daily_note_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_note_entries
    ADD CONSTRAINT daily_note_entries_pkey PRIMARY KEY (id);


--
-- Name: daily_note_entry_persons daily_note_entry_persons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_note_entry_persons
    ADD CONSTRAINT daily_note_entry_persons_pkey PRIMARY KEY (entry_id, person_id);


--
-- Name: directory_people directory_people_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_people
    ADD CONSTRAINT directory_people_pkey PRIMARY KEY (person_id);


--
-- Name: directory_person_filters directory_person_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_person_filters
    ADD CONSTRAINT directory_person_filters_pkey PRIMARY KEY (person_id, filter_kind, value_key);


--
-- Name: directory_person_token_deletes directory_person_token_deletes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_person_token_deletes
    ADD CONSTRAINT directory_person_token_deletes_pkey PRIMARY KEY (person_id, delete_key);


--
-- Name: directory_person_tokens directory_person_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_person_tokens
    ADD CONSTRAINT directory_person_tokens_pkey PRIMARY KEY (person_id, token_key);


--
-- Name: directory_projection_dirty directory_projection_dirty_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.directory_projection_dirty
    ADD CONSTRAINT directory_projection_dirty_pkey PRIMARY KEY (person_id);


--
-- Name: document_chunk_spans document_chunk_spans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunk_spans
    ADD CONSTRAINT document_chunk_spans_pkey PRIMARY KEY (extraction_id, chunk_key, span_ordinal);


--
-- Name: document_chunks document_chunks_extraction_id_chunk_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_extraction_id_chunk_key_key UNIQUE (extraction_id, chunk_key);


--
-- Name: document_chunks document_chunks_extraction_id_ordinal_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_extraction_id_ordinal_key UNIQUE (extraction_id, ordinal);


--
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (id);


--
-- Name: document_embedding_runs document_embedding_runs_invocation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_embedding_runs
    ADD CONSTRAINT document_embedding_runs_invocation_key_key UNIQUE (invocation_key);


--
-- Name: document_embedding_runs document_embedding_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_embedding_runs
    ADD CONSTRAINT document_embedding_runs_pkey PRIMARY KEY (id);


--
-- Name: document_extraction_claims document_extraction_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_claims
    ADD CONSTRAINT document_extraction_claims_pkey PRIMARY KEY (profile_id, canonical_blob_hash, extraction_input_key);


--
-- Name: document_extraction_conversions document_extraction_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_conversions
    ADD CONSTRAINT document_extraction_conversions_pkey PRIMARY KEY (extraction_id);


--
-- Name: document_extraction_heads document_extraction_heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_heads
    ADD CONSTRAINT document_extraction_heads_pkey PRIMARY KEY (profile_id, canonical_blob_hash, extraction_input_key);


--
-- Name: document_extraction_profiles document_extraction_profiles_fingerprint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_profiles
    ADD CONSTRAINT document_extraction_profiles_fingerprint_key UNIQUE (fingerprint);


--
-- Name: document_extraction_profiles document_extraction_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_profiles
    ADD CONSTRAINT document_extraction_profiles_pkey PRIMARY KEY (id);


--
-- Name: document_extraction_rebuild_targets document_extraction_rebuild_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_rebuild_targets
    ADD CONSTRAINT document_extraction_rebuild_targets_pkey PRIMARY KEY (rebuild_id, canonical_blob_hash);


--
-- Name: document_extraction_rebuilds document_extraction_rebuilds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_rebuilds
    ADD CONSTRAINT document_extraction_rebuilds_pkey PRIMARY KEY (id);


--
-- Name: document_extraction_runs document_extraction_runs_invocation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_runs
    ADD CONSTRAINT document_extraction_runs_invocation_key_key UNIQUE (invocation_key);


--
-- Name: document_extraction_runs document_extraction_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_runs
    ADD CONSTRAINT document_extraction_runs_pkey PRIMARY KEY (id);


--
-- Name: document_extractions document_extractions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extractions
    ADD CONSTRAINT document_extractions_pkey PRIMARY KEY (id);


--
-- Name: document_index_state document_index_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_index_state
    ADD CONSTRAINT document_index_state_pkey PRIMARY KEY (singleton);


--
-- Name: document_occurrences document_occurrences_attachment_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_occurrences
    ADD CONSTRAINT document_occurrences_attachment_id_key UNIQUE (attachment_id);


--
-- Name: document_occurrences document_occurrences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_occurrences
    ADD CONSTRAINT document_occurrences_pkey PRIMARY KEY (occurrence_key);


--
-- Name: document_provider_consents document_provider_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_provider_consents
    ADD CONSTRAINT document_provider_consents_pkey PRIMARY KEY (profile_id);


--
-- Name: document_units document_units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_units
    ADD CONSTRAINT document_units_pkey PRIMARY KEY (extraction_id, unit_index);


--
-- Name: document_vector_build_progress document_vector_build_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_build_progress
    ADD CONSTRAINT document_vector_build_progress_pkey PRIMARY KEY (generation_id);


--
-- Name: document_vector_consents document_vector_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_consents
    ADD CONSTRAINT document_vector_consents_pkey PRIMARY KEY (egress_fingerprint);


--
-- Name: document_vector_generations document_vector_generations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_generations
    ADD CONSTRAINT document_vector_generations_pkey PRIMARY KEY (id);


--
-- Name: document_vector_provider_usage document_vector_provider_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_provider_usage
    ADD CONSTRAINT document_vector_provider_usage_pkey PRIMARY KEY (fingerprint);


--
-- Name: document_vector_publications document_vector_publications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_publications
    ADD CONSTRAINT document_vector_publications_pkey PRIMARY KEY (generation_id, extraction_id, chunk_id);


--
-- Name: document_vector_publications document_vector_publications_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_publications
    ADD CONSTRAINT document_vector_publications_token_key UNIQUE (token);


--
-- Name: embedding_change_clock embedding_change_clock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.embedding_change_clock
    ADD CONSTRAINT embedding_change_clock_pkey PRIMARY KEY (singleton);


--
-- Name: embedding_changes embedding_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.embedding_changes
    ADD CONSTRAINT embedding_changes_pkey PRIMARY KEY (sequence);


--
-- Name: employments employments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employments
    ADD CONSTRAINT employments_pkey PRIMARY KEY (id);


--
-- Name: gmail_drafts gmail_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gmail_drafts
    ADD CONSTRAINT gmail_drafts_pkey PRIMARY KEY (draft_id);


--
-- Name: gmail_drafts gmail_drafts_source_id_gmail_draft_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gmail_drafts
    ADD CONSTRAINT gmail_drafts_source_id_gmail_draft_id_key UNIQUE (source_id, gmail_draft_id);


--
-- Name: identity_match_candidate_redirects identity_match_candidate_redirects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_candidate_redirects
    ADD CONSTRAINT identity_match_candidate_redirects_pkey PRIMARY KEY (retired_candidate_id);


--
-- Name: identity_match_candidate_sources identity_match_candidate_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_candidate_sources
    ADD CONSTRAINT identity_match_candidate_sources_pkey PRIMARY KEY (candidate_id, source_id);


--
-- Name: identity_match_candidates identity_match_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_candidates
    ADD CONSTRAINT identity_match_candidates_pkey PRIMARY KEY (id);


--
-- Name: identity_match_evidence identity_match_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_evidence
    ADD CONSTRAINT identity_match_evidence_pkey PRIMARY KEY (id);


--
-- Name: identity_match_evidence_sources identity_match_evidence_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_evidence_sources
    ADD CONSTRAINT identity_match_evidence_sources_pkey PRIMARY KEY (evidence_id, source_id);


--
-- Name: identity_match_review_decisions identity_match_review_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_review_decisions
    ADD CONSTRAINT identity_match_review_decisions_pkey PRIMARY KEY (candidate_id);


--
-- Name: identity_match_review_receipts identity_match_review_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_review_receipts
    ADD CONSTRAINT identity_match_review_receipts_pkey PRIMARY KEY (candidate_id);


--
-- Name: carddav_accounts idx_carddav_account_connection_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_accounts
    ADD CONSTRAINT idx_carddav_account_connection_name UNIQUE (connection_name);


--
-- Name: imap_drafts imap_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_drafts
    ADD CONSTRAINT imap_drafts_pkey PRIMARY KEY (draft_id);


--
-- Name: imap_folder_state imap_folder_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_folder_state
    ADD CONSTRAINT imap_folder_state_pkey PRIMARY KEY (source_id, mailbox);


--
-- Name: imap_message_memberships imap_message_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_message_memberships
    ADD CONSTRAINT imap_message_memberships_pkey PRIMARY KEY (source_id, mailbox, uidvalidity, uid);


--
-- Name: labels labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_pkey PRIMARY KEY (id);


--
-- Name: labels labels_source_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_source_id_name_key UNIQUE (source_id, name);


--
-- Name: mcp_event_clock mcp_event_clock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_event_clock
    ADD CONSTRAINT mcp_event_clock_pkey PRIMARY KEY (singleton);


--
-- Name: mcp_event_dead_letters mcp_event_dead_letters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_event_dead_letters
    ADD CONSTRAINT mcp_event_dead_letters_pkey PRIMARY KEY (subscription_id, seq);


--
-- Name: mcp_event_log mcp_event_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_event_log
    ADD CONSTRAINT mcp_event_log_pkey PRIMARY KEY (seq);


--
-- Name: mcp_event_message_refs mcp_event_message_refs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_event_message_refs
    ADD CONSTRAINT mcp_event_message_refs_pkey PRIMARY KEY (message_id);


--
-- Name: mcp_event_message_refs mcp_event_message_refs_reference_seq_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_event_message_refs
    ADD CONSTRAINT mcp_event_message_refs_reference_seq_key UNIQUE (reference_seq);


--
-- Name: mcp_event_subscriptions mcp_event_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_event_subscriptions
    ADD CONSTRAINT mcp_event_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: mcp_live_admissions mcp_live_admissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_live_admissions
    ADD CONSTRAINT mcp_live_admissions_pkey PRIMARY KEY (message_id);


--
-- Name: meeting_action_items meeting_action_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_action_items
    ADD CONSTRAINT meeting_action_items_pkey PRIMARY KEY (message_id, ordinal);


--
-- Name: meeting_details meeting_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_details
    ADD CONSTRAINT meeting_details_pkey PRIMARY KEY (message_id);


--
-- Name: message_bodies message_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_bodies
    ADD CONSTRAINT message_bodies_pkey PRIMARY KEY (message_id);


--
-- Name: message_embedding_runs message_embedding_runs_invocation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_embedding_runs
    ADD CONSTRAINT message_embedding_runs_invocation_key_key UNIQUE (invocation_key);


--
-- Name: message_embedding_runs message_embedding_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_embedding_runs
    ADD CONSTRAINT message_embedding_runs_pkey PRIMARY KEY (id);


--
-- Name: message_labels message_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_labels
    ADD CONSTRAINT message_labels_pkey PRIMARY KEY (message_id, label_id);


--
-- Name: message_raw message_raw_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_raw
    ADD CONSTRAINT message_raw_pkey PRIMARY KEY (message_id);


--
-- Name: message_recipients message_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_recipients
    ADD CONSTRAINT message_recipients_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: messages messages_source_id_source_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_source_id_source_message_id_key UNIQUE (source_id, source_message_id);


--
-- Name: operation_history_state operation_history_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operation_history_state
    ADD CONSTRAINT operation_history_state_pkey PRIMARY KEY (singleton);


--
-- Name: operation_token_keys operation_token_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operation_token_keys
    ADD CONSTRAINT operation_token_keys_pkey PRIMARY KEY (key_id);


--
-- Name: organization_addresses organization_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_addresses
    ADD CONSTRAINT organization_addresses_pkey PRIMARY KEY (id);


--
-- Name: organization_attribute_values organization_attribute_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_attribute_values
    ADD CONSTRAINT organization_attribute_values_pkey PRIMARY KEY (id);


--
-- Name: organization_categories organization_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_categories
    ADD CONSTRAINT organization_categories_pkey PRIMARY KEY (id);


--
-- Name: organization_contact_points organization_contact_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_contact_points
    ADD CONSTRAINT organization_contact_points_pkey PRIMARY KEY (id);


--
-- Name: organization_identifiers organization_identifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_identifiers
    ADD CONSTRAINT organization_identifiers_pkey PRIMARY KEY (id);


--
-- Name: organization_media organization_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_media
    ADD CONSTRAINT organization_media_pkey PRIMARY KEY (id);


--
-- Name: organization_names organization_names_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_names
    ADD CONSTRAINT organization_names_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: participant_contact_observations participant_contact_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_contact_observations
    ADD CONSTRAINT participant_contact_observations_pkey PRIMARY KEY (id);


--
-- Name: participant_identifiers participant_identifiers_identifier_type_identifier_value_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_identifiers
    ADD CONSTRAINT participant_identifiers_identifier_type_identifier_value_key UNIQUE (identifier_type, identifier_value);


--
-- Name: participant_identifiers participant_identifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_identifiers
    ADD CONSTRAINT participant_identifiers_pkey PRIMARY KEY (id);


--
-- Name: participant_links participant_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_links
    ADD CONSTRAINT participant_links_pkey PRIMARY KEY (participant_a, participant_b);


--
-- Name: participants participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participants
    ADD CONSTRAINT participants_pkey PRIMARY KEY (id);


--
-- Name: person_addresses person_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_addresses
    ADD CONSTRAINT person_addresses_pkey PRIMARY KEY (id);


--
-- Name: person_attribute_values person_attribute_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_attribute_values
    ADD CONSTRAINT person_attribute_values_pkey PRIMARY KEY (id);


--
-- Name: person_brief_enrollments person_brief_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_brief_enrollments
    ADD CONSTRAINT person_brief_enrollments_pkey PRIMARY KEY (person_id);


--
-- Name: person_brief_evidence person_brief_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_brief_evidence
    ADD CONSTRAINT person_brief_evidence_pkey PRIMARY KEY (brief_id, ordinal);


--
-- Name: person_briefs person_briefs_person_id_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_briefs
    ADD CONSTRAINT person_briefs_person_id_version_key UNIQUE (person_id, version);


--
-- Name: person_briefs person_briefs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_briefs
    ADD CONSTRAINT person_briefs_pkey PRIMARY KEY (id);


--
-- Name: person_carddav_inference_state person_carddav_inference_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_carddav_inference_state
    ADD CONSTRAINT person_carddav_inference_state_pkey PRIMARY KEY (person_id);


--
-- Name: person_categories person_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_categories
    ADD CONSTRAINT person_categories_pkey PRIMARY KEY (id);


--
-- Name: person_contact_points person_contact_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_contact_points
    ADD CONSTRAINT person_contact_points_pkey PRIMARY KEY (id);


--
-- Name: person_contact_state person_contact_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_contact_state
    ADD CONSTRAINT person_contact_state_pkey PRIMARY KEY (person_id);


--
-- Name: person_dates person_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_dates
    ADD CONSTRAINT person_dates_pkey PRIMARY KEY (id);


--
-- Name: person_embedding_runs person_embedding_runs_invocation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_embedding_runs
    ADD CONSTRAINT person_embedding_runs_invocation_key_key UNIQUE (invocation_key);


--
-- Name: person_embedding_runs person_embedding_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_embedding_runs
    ADD CONSTRAINT person_embedding_runs_pkey PRIMARY KEY (id);


--
-- Name: person_enrichment_attempt_citations person_enrichment_attempt_citations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempt_citations
    ADD CONSTRAINT person_enrichment_attempt_citations_pkey PRIMARY KEY (attempt_id, citation_id);


--
-- Name: person_enrichment_attempt_identifiers person_enrichment_attempt_identifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempt_identifiers
    ADD CONSTRAINT person_enrichment_attempt_identifiers_pkey PRIMARY KEY (attempt_id, provider_namespace, identifier_class, normalization_version, key_id, digest);


--
-- Name: person_enrichment_attempt_sources person_enrichment_attempt_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempt_sources
    ADD CONSTRAINT person_enrichment_attempt_sources_pkey PRIMARY KEY (attempt_id, canonical_url, outcome);


--
-- Name: person_enrichment_attempts person_enrichment_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempts
    ADD CONSTRAINT person_enrichment_attempts_pkey PRIMARY KEY (id);


--
-- Name: person_enrichment_attempts person_enrichment_attempts_request_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempts
    ADD CONSTRAINT person_enrichment_attempts_request_hash_key UNIQUE (request_hash);


--
-- Name: person_enrichment_citations person_enrichment_citations_person_id_citation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_citations
    ADD CONSTRAINT person_enrichment_citations_person_id_citation_key_key UNIQUE (person_id, citation_key);


--
-- Name: person_enrichment_citations person_enrichment_citations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_citations
    ADD CONSTRAINT person_enrichment_citations_pkey PRIMARY KEY (id);


--
-- Name: person_enrichment_consents person_enrichment_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_consents
    ADD CONSTRAINT person_enrichment_consents_pkey PRIMARY KEY (id);


--
-- Name: person_enrichment_day_counters person_enrichment_day_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_day_counters
    ADD CONSTRAINT person_enrichment_day_counters_pkey PRIMARY KEY (profile_fingerprint, utc_day);


--
-- Name: person_enrichment_manual_run_targets person_enrichment_manual_run_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_manual_run_targets
    ADD CONSTRAINT person_enrichment_manual_run_targets_pkey PRIMARY KEY (run_id);


--
-- Name: person_enrichment_person_day_counters person_enrichment_person_day_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_person_day_counters
    ADD CONSTRAINT person_enrichment_person_day_counters_pkey PRIMARY KEY (person_id, profile_fingerprint, utc_day);


--
-- Name: person_enrichment_profile_accounting person_enrichment_profile_accounting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_profile_accounting
    ADD CONSTRAINT person_enrichment_profile_accounting_pkey PRIMARY KEY (profile_fingerprint);


--
-- Name: person_enrichment_profiles person_enrichment_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_profiles
    ADD CONSTRAINT person_enrichment_profiles_pkey PRIMARY KEY (fingerprint);


--
-- Name: person_enrichment_provider_identities person_enrichment_provider_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_provider_identities
    ADD CONSTRAINT person_enrichment_provider_identities_pkey PRIMARY KEY (person_id, provider_namespace, provider_person_id);


--
-- Name: person_enrichment_run_counters person_enrichment_run_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_run_counters
    ADD CONSTRAINT person_enrichment_run_counters_pkey PRIMARY KEY (run_id);


--
-- Name: person_enrichment_runs person_enrichment_runs_kind_requested_by_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_runs
    ADD CONSTRAINT person_enrichment_runs_kind_requested_by_key UNIQUE (kind, requested_by);


--
-- Name: person_enrichment_runs person_enrichment_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_runs
    ADD CONSTRAINT person_enrichment_runs_pkey PRIMARY KEY (id);


--
-- Name: person_enrichment_suppressions person_enrichment_suppression_provider_namespace_identifier_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_suppressions
    ADD CONSTRAINT person_enrichment_suppression_provider_namespace_identifier_key UNIQUE (provider_namespace, identifier_class, normalization_version, key_id, digest);


--
-- Name: person_enrichment_suppressions person_enrichment_suppressions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_suppressions
    ADD CONSTRAINT person_enrichment_suppressions_pkey PRIMARY KEY (id);


--
-- Name: person_enrichment_work person_enrichment_work_active_attempt_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_work
    ADD CONSTRAINT person_enrichment_work_active_attempt_id_key UNIQUE (active_attempt_id);


--
-- Name: person_enrichment_work person_enrichment_work_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_work
    ADD CONSTRAINT person_enrichment_work_pkey PRIMARY KEY (person_id, profile_fingerprint);


--
-- Name: person_fact_claim_evidence person_fact_claim_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_claim_evidence
    ADD CONSTRAINT person_fact_claim_evidence_pkey PRIMARY KEY (claim_id, evidence_id);


--
-- Name: person_fact_claims person_fact_claims_person_id_claim_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_claims
    ADD CONSTRAINT person_fact_claims_person_id_claim_key_key UNIQUE (person_id, claim_key);


--
-- Name: person_fact_claims person_fact_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_claims
    ADD CONSTRAINT person_fact_claims_pkey PRIMARY KEY (id);


--
-- Name: person_fact_decisions person_fact_decisions_person_id_decision_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_decisions
    ADD CONSTRAINT person_fact_decisions_person_id_decision_key_key UNIQUE (person_id, decision_key);


--
-- Name: person_fact_decisions person_fact_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_decisions
    ADD CONSTRAINT person_fact_decisions_pkey PRIMARY KEY (id);


--
-- Name: person_fact_evidence person_fact_evidence_person_id_evidence_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_evidence
    ADD CONSTRAINT person_fact_evidence_person_id_evidence_key_key UNIQUE (person_id, evidence_key);


--
-- Name: person_fact_evidence person_fact_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_evidence
    ADD CONSTRAINT person_fact_evidence_pkey PRIMARY KEY (id);


--
-- Name: person_fact_evidence_status_events person_fact_evidence_status_e_person_id_generation_id_evide_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_evidence_status_events
    ADD CONSTRAINT person_fact_evidence_status_e_person_id_generation_id_evide_key UNIQUE (person_id, generation_id, evidence_key, source_version);


--
-- Name: person_fact_evidence_status_events person_fact_evidence_status_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_evidence_status_events
    ADD CONSTRAINT person_fact_evidence_status_events_pkey PRIMARY KEY (id);


--
-- Name: person_fact_generations person_fact_generations_person_id_generation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_generations
    ADD CONSTRAINT person_fact_generations_person_id_generation_key_key UNIQUE (person_id, generation_key);


--
-- Name: person_fact_generations person_fact_generations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_generations
    ADD CONSTRAINT person_fact_generations_pkey PRIMARY KEY (id);


--
-- Name: person_fact_pin_events person_fact_pin_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_pin_events
    ADD CONSTRAINT person_fact_pin_events_pkey PRIMARY KEY (id);


--
-- Name: person_fact_resolutions person_fact_resolutions_generation_id_target_kind_target_ke_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_resolutions
    ADD CONSTRAINT person_fact_resolutions_generation_id_target_kind_target_ke_key UNIQUE (generation_id, target_kind, target_key, resolver_version, input_fingerprint);


--
-- Name: person_fact_resolutions person_fact_resolutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_resolutions
    ADD CONSTRAINT person_fact_resolutions_pkey PRIMARY KEY (id);


--
-- Name: person_inference_checks person_inference_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_inference_checks
    ADD CONSTRAINT person_inference_checks_pkey PRIMARY KEY (profile_fingerprint);


--
-- Name: person_inference_consents person_inference_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_inference_consents
    ADD CONSTRAINT person_inference_consents_pkey PRIMARY KEY (id);


--
-- Name: person_inference_profiles person_inference_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_inference_profiles
    ADD CONSTRAINT person_inference_profiles_pkey PRIMARY KEY (fingerprint);


--
-- Name: person_match_consents person_match_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_match_consents
    ADD CONSTRAINT person_match_consents_pkey PRIMARY KEY (id);


--
-- Name: person_match_judgment_cursor person_match_judgment_cursor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_match_judgment_cursor
    ADD CONSTRAINT person_match_judgment_cursor_pkey PRIMARY KEY (singleton);


--
-- Name: person_match_judgment_work person_match_judgment_work_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_match_judgment_work
    ADD CONSTRAINT person_match_judgment_work_pkey PRIMARY KEY (candidate_id);


--
-- Name: person_match_judgments person_match_judgments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_match_judgments
    ADD CONSTRAINT person_match_judgments_pkey PRIMARY KEY (id);


--
-- Name: person_media person_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_media
    ADD CONSTRAINT person_media_pkey PRIMARY KEY (id);


--
-- Name: person_merge_participants person_merge_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_participants
    ADD CONSTRAINT person_merge_participants_pkey PRIMARY KEY (merge_id, participant_id);


--
-- Name: person_merge_review_candidates person_merge_review_candidates_merge_id_definition_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_review_candidates
    ADD CONSTRAINT person_merge_review_candidates_merge_id_definition_id_key UNIQUE (merge_id, definition_id);


--
-- Name: person_merge_review_candidates person_merge_review_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_review_candidates
    ADD CONSTRAINT person_merge_review_candidates_pkey PRIMARY KEY (id);


--
-- Name: person_merge_row_person_refs person_merge_row_person_refs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_row_person_refs
    ADD CONSTRAINT person_merge_row_person_refs_pkey PRIMARY KEY (merge_id, table_name, original_row_key, column_name);


--
-- Name: person_merge_rows person_merge_rows_merge_id_table_name_original_row_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_rows
    ADD CONSTRAINT person_merge_rows_merge_id_table_name_original_row_key_key UNIQUE (merge_id, table_name, original_row_key);


--
-- Name: person_merges person_merges_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merges
    ADD CONSTRAINT person_merges_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: person_merges person_merges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merges
    ADD CONSTRAINT person_merges_pkey PRIMARY KEY (id);


--
-- Name: person_names person_names_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_names
    ADD CONSTRAINT person_names_pkey PRIMARY KEY (id);


--
-- Name: person_participants person_participants_participant_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_participants
    ADD CONSTRAINT person_participants_participant_id_key UNIQUE (participant_id);


--
-- Name: person_participants person_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_participants
    ADD CONSTRAINT person_participants_pkey PRIMARY KEY (person_id, participant_id);


--
-- Name: person_relationship_reviews person_relationship_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_relationship_reviews
    ADD CONSTRAINT person_relationship_reviews_pkey PRIMARY KEY (id);


--
-- Name: person_relationships person_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_relationships
    ADD CONSTRAINT person_relationships_pkey PRIMARY KEY (id);


--
-- Name: person_semantic_embedding_consents person_semantic_embedding_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_semantic_embedding_consents
    ADD CONSTRAINT person_semantic_embedding_consents_pkey PRIMARY KEY (id);


--
-- Name: person_semantic_embedding_profiles person_semantic_embedding_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_semantic_embedding_profiles
    ADD CONSTRAINT person_semantic_embedding_profiles_pkey PRIMARY KEY (fingerprint);


--
-- Name: person_splits person_splits_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_splits
    ADD CONSTRAINT person_splits_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: person_splits person_splits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_splits
    ADD CONSTRAINT person_splits_pkey PRIMARY KEY (id);


--
-- Name: person_sweep_attempts person_sweep_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_attempts
    ADD CONSTRAINT person_sweep_attempts_pkey PRIMARY KEY (id);


--
-- Name: person_sweep_batches person_sweep_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_batches
    ADD CONSTRAINT person_sweep_batches_pkey PRIMARY KEY (attempt_id, batch_ordinal, call_ordinal);


--
-- Name: person_sweep_change_clock person_sweep_change_clock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_change_clock
    ADD CONSTRAINT person_sweep_change_clock_pkey PRIMARY KEY (singleton);


--
-- Name: person_sweep_changes person_sweep_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_changes
    ADD CONSTRAINT person_sweep_changes_pkey PRIMARY KEY (sequence);


--
-- Name: person_sweep_cursors person_sweep_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_cursors
    ADD CONSTRAINT person_sweep_cursors_pkey PRIMARY KEY (person_id, source_lane, program_fingerprint, catalog_fingerprint);


--
-- Name: person_sweep_daily_usage person_sweep_daily_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_daily_usage
    ADD CONSTRAINT person_sweep_daily_usage_pkey PRIMARY KEY (utc_day);


--
-- Name: person_sweep_runs person_sweep_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_runs
    ADD CONSTRAINT person_sweep_runs_pkey PRIMARY KEY (id);


--
-- Name: person_sweep_sync_publications person_sweep_sync_publications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_sync_publications
    ADD CONSTRAINT person_sweep_sync_publications_pkey PRIMARY KEY (sync_run_id);


--
-- Name: person_sweep_work person_sweep_work_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_work
    ADD CONSTRAINT person_sweep_work_pkey PRIMARY KEY (person_id);


--
-- Name: person_tracking person_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_tracking
    ADD CONSTRAINT person_tracking_pkey PRIMARY KEY (person_id);


--
-- Name: person_uid_aliases person_uid_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_uid_aliases
    ADD CONSTRAINT person_uid_aliases_pkey PRIMARY KEY (retired_uid);


--
-- Name: persons persons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persons
    ADD CONSTRAINT persons_pkey PRIMARY KEY (id);


--
-- Name: persons persons_vcard_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persons
    ADD CONSTRAINT persons_vcard_uid_key UNIQUE (vcard_uid);


--
-- Name: reaction_source_events reaction_source_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reaction_source_events
    ADD CONSTRAINT reaction_source_events_pkey PRIMARY KEY (source_id, source_reaction_id);


--
-- Name: reactions reactions_message_id_participant_id_reaction_type_reaction__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_message_id_participant_id_reaction_type_reaction__key UNIQUE (message_id, participant_id, reaction_type, reaction_value);


--
-- Name: reactions reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_pkey PRIMARY KEY (id);


--
-- Name: relationship_types relationship_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_pkey PRIMARY KEY (id);


--
-- Name: relationship_types relationship_types_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_slug_key UNIQUE (slug);


--
-- Name: relationship_types relationship_types_universal_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_universal_id_key UNIQUE (universal_id);


--
-- Name: relationship_types relationship_types_vcard_related_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_vcard_related_type_key UNIQUE (vcard_related_type);


--
-- Name: saved_views saved_views_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_views
    ADD CONSTRAINT saved_views_name_key UNIQUE (name);


--
-- Name: saved_views saved_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_views
    ADD CONSTRAINT saved_views_pkey PRIMARY KEY (id);


--
-- Name: source_import_items source_import_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_import_items
    ADD CONSTRAINT source_import_items_pkey PRIMARY KEY (id);


--
-- Name: source_import_items source_import_items_source_id_provider_provider_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_import_items
    ADD CONSTRAINT source_import_items_source_id_provider_provider_id_key UNIQUE (source_id, provider, provider_id);


--
-- Name: sources sources_google_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_google_user_id_key UNIQUE (google_user_id);


--
-- Name: sources sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_pkey PRIMARY KEY (id);


--
-- Name: sources sources_source_type_identifier_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sources
    ADD CONSTRAINT sources_source_type_identifier_key UNIQUE (source_type, identifier);


--
-- Name: sync_checkpoints sync_checkpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_checkpoints
    ADD CONSTRAINT sync_checkpoints_pkey PRIMARY KEY (source_id, checkpoint_type);


--
-- Name: sync_operations sync_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_operations
    ADD CONSTRAINT sync_operations_pkey PRIMARY KEY (id);


--
-- Name: sync_run_items sync_run_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_run_items
    ADD CONSTRAINT sync_run_items_pkey PRIMARY KEY (id);


--
-- Name: sync_runs sync_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_runs
    ADD CONSTRAINT sync_runs_pkey PRIMARY KEY (id);


--
-- Name: vcard_resource_envelopes vcard_resource_envelopes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vcard_resource_envelopes
    ADD CONSTRAINT vcard_resource_envelopes_pkey PRIMARY KEY (id);


--
-- Name: vcard_resource_envelopes vcard_resource_envelopes_source_ref_source_resource_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vcard_resource_envelopes
    ADD CONSTRAINT vcard_resource_envelopes_source_ref_source_resource_uid_key UNIQUE (source_ref, source_resource_uid);


--
-- Name: visual_embedding_runs visual_embedding_runs_invocation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_embedding_runs
    ADD CONSTRAINT visual_embedding_runs_invocation_key_key UNIQUE (invocation_key);


--
-- Name: visual_embedding_runs visual_embedding_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_embedding_runs
    ADD CONSTRAINT visual_embedding_runs_pkey PRIMARY KEY (id);


--
-- Name: visual_generations visual_generations_fingerprint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_generations
    ADD CONSTRAINT visual_generations_fingerprint_key UNIQUE (fingerprint);


--
-- Name: visual_generations visual_generations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_generations
    ADD CONSTRAINT visual_generations_pkey PRIMARY KEY (id);


--
-- Name: visual_obsolete_tokens visual_obsolete_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_obsolete_tokens
    ADD CONSTRAINT visual_obsolete_tokens_pkey PRIMARY KEY (generation_id, vector_token);


--
-- Name: visual_publications visual_publications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_publications
    ADD CONSTRAINT visual_publications_pkey PRIMARY KEY (generation_id, message_id, blob_hash, media_input_key);


--
-- Name: visual_work_claims visual_work_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_work_claims
    ADD CONSTRAINT visual_work_claims_pkey PRIMARY KEY (generation_id, message_id, blob_hash, media_input_key, proposed_revision);


--
-- Name: idx_account_identities_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_identities_address ON public.account_identities USING btree (address);


--
-- Name: idx_account_identities_address_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_account_identities_address_key ON public.account_identities USING btree (source_id, address_key) WHERE (address_key <> ''::text);


--
-- Name: idx_activity_event_persons_date_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_event_persons_date_person ON public.activity_event_persons USING btree (local_date, person_id, message_id);


--
-- Name: idx_activity_event_persons_person_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_event_persons_person_date ON public.activity_event_persons USING btree (person_id, local_date, message_id);


--
-- Name: idx_activity_events_local_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_events_local_date ON public.activity_events USING btree (local_date, occurred_at DESC);


--
-- Name: idx_activity_events_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_events_source ON public.activity_events USING btree (source_id, occurred_at DESC);


--
-- Name: idx_activity_projection_queue_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_projection_queue_pending ON public.activity_projection_queue USING btree (message_id) WHERE (revision > processed_revision);


--
-- Name: idx_attachment_pack_index_pack; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachment_pack_index_pack ON public.attachment_pack_index USING btree (pack_id);


--
-- Name: idx_attachments_content_hash_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_content_hash_lower ON public.attachments USING btree (lower(content_hash));


--
-- Name: idx_attachments_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_hash ON public.attachments USING btree (content_hash);


--
-- Name: idx_attachments_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_message ON public.attachments USING btree (message_id);


--
-- Name: idx_attachments_msg_content_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_attachments_msg_content_hash ON public.attachments USING btree (message_id, content_hash) WHERE ((source_part_key IS NULL) AND (content_hash IS NOT NULL) AND (content_hash <> ''::text));


--
-- Name: idx_attachments_msg_source_part; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_attachments_msg_source_part ON public.attachments USING btree (message_id, source_part_key) WHERE (source_part_key IS NOT NULL);


--
-- Name: idx_attachments_storage_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_storage_path ON public.attachments USING btree (storage_path);


--
-- Name: idx_attachments_thumbnail_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_thumbnail_hash ON public.attachments USING btree (thumbnail_hash);


--
-- Name: idx_attachments_thumbnail_hash_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_thumbnail_hash_lower ON public.attachments USING btree (lower(thumbnail_hash));


--
-- Name: idx_attachments_thumbnail_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_thumbnail_path ON public.attachments USING btree (thumbnail_path);


--
-- Name: idx_attribute_definitions_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attribute_definitions_active ON public.attribute_definitions USING btree (object_type, display_order, id) WHERE (is_active = true);


--
-- Name: idx_attribute_definitions_object_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_attribute_definitions_object_slug ON public.attribute_definitions USING btree (object_type, slug);


--
-- Name: idx_beeper_drafts_live_chat; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_beeper_drafts_live_chat ON public.beeper_drafts USING btree (source_id, chat_id) WHERE (discarded_at IS NULL);


--
-- Name: idx_beeper_media_deliveries_ready; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_beeper_media_deliveries_ready ON public.beeper_media_deliveries USING btree (destination_key, phase, next_action_at, processing_key);


--
-- Name: idx_beeper_media_occurrences_processing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_beeper_media_occurrences_processing ON public.beeper_media_occurrences USING btree (destination_key, processing_key, retention_state);


--
-- Name: idx_beeper_media_occurrences_ready; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_beeper_media_occurrences_ready ON public.beeper_media_occurrences USING btree (destination_key, retention_state, next_action_at, occurrence_ref);


--
-- Name: idx_carddav_conflicts_resolved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_carddav_conflicts_resolved_at ON public.carddav_conflicts USING btree (status, resolved_at);


--
-- Name: idx_carddav_one_unresolved_conflict; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_carddav_one_unresolved_conflict ON public.carddav_conflicts USING btree (address_book_id, href) WHERE (status = 'unresolved'::text);


--
-- Name: idx_carddav_one_write_target; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_carddav_one_write_target ON public.carddav_address_books USING btree ((1)) WHERE (is_write_target = true);


--
-- Name: idx_carddav_publications_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_carddav_publications_pending ON public.carddav_publications USING btree (pending_operation, person_id);


--
-- Name: idx_carddav_resources_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_carddav_resources_person ON public.carddav_resources USING btree (person_id) WHERE (person_id IS NOT NULL);


--
-- Name: idx_carddav_sync_runs_one_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_carddav_sync_runs_one_active ON public.carddav_sync_runs USING btree (account_id) WHERE (state = 'running'::text);


--
-- Name: idx_carddav_sync_runs_operations_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_carddav_sync_runs_operations_order ON public.carddav_sync_runs USING btree (started_at DESC, id DESC);


--
-- Name: idx_carddav_sync_runs_state_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_carddav_sync_runs_state_id ON public.carddav_sync_runs USING btree (state, id DESC);


--
-- Name: idx_chat_drafts_conversation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_drafts_conversation ON public.chat_drafts USING btree (conversation_id);


--
-- Name: idx_chat_drafts_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_drafts_source ON public.chat_drafts USING btree (source_id);


--
-- Name: idx_collection_sources_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_collection_sources_source_id ON public.collection_sources USING btree (source_id);


--
-- Name: idx_communication_service_aliases_service; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_communication_service_aliases_service ON public.communication_service_aliases USING btree (service_id);


--
-- Name: idx_conversation_participants_participant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversation_participants_participant ON public.conversation_participants USING btree (participant_id, conversation_id);


--
-- Name: idx_conversations_last_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_last_message ON public.conversations USING btree (last_message_at DESC);


--
-- Name: idx_conversations_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_source ON public.conversations USING btree (source_id);


--
-- Name: idx_conversations_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_type ON public.conversations USING btree (conversation_type);


--
-- Name: idx_daily_note_entries_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_daily_note_entries_date ON public.daily_note_entries USING btree (local_date, ordinal, id);


--
-- Name: idx_daily_note_entry_persons_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_daily_note_entry_persons_person ON public.daily_note_entry_persons USING btree (person_id, entry_id);


--
-- Name: idx_directory_people_contact; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_directory_people_contact ON public.directory_people USING btree (contact_state, primary_channel, order_key, person_id);


--
-- Name: idx_directory_people_last_contact; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_directory_people_last_contact ON public.directory_people USING btree (last_contact_key, order_key, person_id);


--
-- Name: idx_directory_people_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_directory_people_order ON public.directory_people USING btree (order_key, person_id);


--
-- Name: idx_directory_person_filters_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_directory_person_filters_lookup ON public.directory_person_filters USING btree (filter_kind, value_key, person_id);


--
-- Name: idx_directory_person_token_deletes_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_directory_person_token_deletes_lookup ON public.directory_person_token_deletes USING btree (delete_key, person_id);


--
-- Name: idx_directory_person_tokens_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_directory_person_tokens_lookup ON public.directory_person_tokens USING btree (token_key, person_id);


--
-- Name: idx_document_chunks_search_fts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_chunks_search_fts ON public.document_chunks USING gin (search_fts);


--
-- Name: idx_document_chunks_vector_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_document_chunks_vector_identity ON public.document_chunks USING btree (id, extraction_id, chunk_key, checksum);


--
-- Name: idx_document_embedding_runs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_embedding_runs_active ON public.document_embedding_runs USING btree (state, id) WHERE (state = 'running'::text);


--
-- Name: idx_document_embedding_runs_operations_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_embedding_runs_operations_order ON public.document_embedding_runs USING btree (started_at DESC, id DESC);


--
-- Name: idx_document_extraction_rebuilds_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_document_extraction_rebuilds_active ON public.document_extraction_rebuilds USING btree (profile_id, extraction_input_key) WHERE (state = 'building'::text);


--
-- Name: idx_document_extraction_runs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_extraction_runs_active ON public.document_extraction_runs USING btree (state, id) WHERE (state = 'running'::text);


--
-- Name: idx_document_extraction_runs_operations_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_extraction_runs_operations_order ON public.document_extraction_runs USING btree (started_at DESC, id DESC);


--
-- Name: idx_document_extractions_lease; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_extractions_lease ON public.document_extractions USING btree (state, lease_until);


--
-- Name: idx_document_extractions_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_extractions_owner ON public.document_extractions USING btree (profile_id, canonical_blob_hash, extraction_input_key, state);


--
-- Name: idx_document_extractions_vector_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_document_extractions_vector_identity ON public.document_extractions USING btree (id, profile_id, canonical_blob_hash, extraction_input_key, source_sequence);


--
-- Name: idx_document_occurrences_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_occurrences_hash ON public.document_occurrences USING btree (canonical_blob_hash, message_id, occurrence_key);


--
-- Name: idx_document_occurrences_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_occurrences_source ON public.document_occurrences USING btree (source_id, message_id);


--
-- Name: idx_document_vector_generations_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_document_vector_generations_active ON public.document_vector_generations USING btree (state) WHERE (state = 'active'::text);


--
-- Name: idx_document_vector_generations_building; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_document_vector_generations_building ON public.document_vector_generations USING btree (state) WHERE (state = 'building'::text);


--
-- Name: idx_document_vector_generations_live_fingerprint; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_vector_generations_live_fingerprint ON public.document_vector_generations USING btree (fingerprint) WHERE (state <> 'retired'::text);


--
-- Name: idx_document_vector_publications_cleanup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_vector_publications_cleanup ON public.document_vector_publications USING btree (generation_id, backend_cleaned_at, token);


--
-- Name: idx_embedding_changes_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_embedding_changes_message_id ON public.embedding_changes USING btree (message_id);


--
-- Name: idx_employments_active_person_org_title; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_employments_active_person_org_title ON public.employments USING btree (person_id, organization_id, title_normalized) WHERE is_current;


--
-- Name: idx_employments_address; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employments_address ON public.employments USING btree (address_id) WHERE (address_id IS NOT NULL);


--
-- Name: idx_employments_one_primary_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_employments_one_primary_current ON public.employments USING btree (person_id) WHERE (is_primary AND is_current);


--
-- Name: idx_employments_organization; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employments_organization ON public.employments USING btree (organization_id);


--
-- Name: idx_employments_organization_current_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employments_organization_current_edge ON public.employments USING btree (organization_id, id) WHERE is_current;


--
-- Name: idx_employments_organization_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employments_organization_edge ON public.employments USING btree (organization_id, id);


--
-- Name: idx_employments_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employments_person ON public.employments USING btree (person_id);


--
-- Name: idx_employments_person_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employments_person_current ON public.employments USING btree (person_id) WHERE is_current;


--
-- Name: idx_employments_person_current_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employments_person_current_edge ON public.employments USING btree (person_id, id) WHERE is_current;


--
-- Name: idx_employments_person_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employments_person_edge ON public.employments USING btree (person_id, id);


--
-- Name: idx_gmail_drafts_current_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gmail_drafts_current_message ON public.gmail_drafts USING btree (current_message_id);


--
-- Name: idx_gmail_drafts_pending_original_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gmail_drafts_pending_original_message ON public.gmail_drafts USING btree (pending_original_message_id);


--
-- Name: idx_identity_match_candidate_redirects_survivor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_identity_match_candidate_redirects_survivor ON public.identity_match_candidate_redirects USING btree (surviving_candidate_id) WHERE (surviving_candidate_id IS NOT NULL);


--
-- Name: idx_identity_match_candidate_sources_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_identity_match_candidate_sources_source ON public.identity_match_candidate_sources USING btree (source_id, candidate_id);


--
-- Name: idx_identity_match_candidates_application_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_identity_match_candidates_application_pending ON public.identity_match_candidates USING btree (application_pending, id) WHERE (state = 'accepted'::text);


--
-- Name: idx_identity_match_candidates_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_identity_match_candidates_edge ON public.identity_match_candidates USING btree (left_kind, left_id, right_kind, right_id, basis, service_id, scope_kind, scope_value, normalized_value);


--
-- Name: idx_identity_match_candidates_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_identity_match_candidates_state ON public.identity_match_candidates USING btree (state, id);


--
-- Name: idx_identity_match_candidates_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_identity_match_candidates_value ON public.identity_match_candidates USING btree (basis, normalized_value) WHERE (normalized_value IS NOT NULL);


--
-- Name: idx_identity_match_evidence_candidate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_identity_match_evidence_candidate ON public.identity_match_evidence USING btree (candidate_id, id);


--
-- Name: idx_identity_match_evidence_sources_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_identity_match_evidence_sources_source ON public.identity_match_evidence_sources USING btree (source_id, evidence_id);


--
-- Name: idx_imap_drafts_current_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_imap_drafts_current_message ON public.imap_drafts USING btree (current_message_id);


--
-- Name: idx_imap_drafts_pending_original_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_imap_drafts_pending_original_message ON public.imap_drafts USING btree (pending_original_message_id);


--
-- Name: idx_imap_message_memberships_source_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_imap_message_memberships_source_message ON public.imap_message_memberships USING btree (source_id, message_id);


--
-- Name: idx_labels_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_labels_source ON public.labels USING btree (source_id);


--
-- Name: idx_mcp_event_dead_letters_cleanup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_event_dead_letters_cleanup ON public.mcp_event_dead_letters USING btree (failed_at);


--
-- Name: idx_mcp_event_log_occurrence; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_mcp_event_log_occurrence ON public.mcp_event_log USING btree (family, scope_kind, scope_id, item_key) WHERE ((kind = 'reaction'::text) OR (family = ANY (ARRAY['msgvault.draft_changed'::text, 'msgvault.kata_issue_filed'::text, 'msgvault.attachment_processed'::text])));


--
-- Name: idx_mcp_event_log_retention; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_event_log_retention ON public.mcp_event_log USING btree (recorded_at);


--
-- Name: idx_mcp_event_log_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_event_log_scope ON public.mcp_event_log USING btree (epoch, family, scope_kind, scope_id, seq);


--
-- Name: idx_mcp_event_log_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_event_log_source ON public.mcp_event_log USING btree (source_id);


--
-- Name: idx_mcp_event_subscriptions_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_event_subscriptions_due ON public.mcp_event_subscriptions USING btree (state, next_attempt_at);


--
-- Name: idx_mcp_event_subscriptions_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_event_subscriptions_principal ON public.mcp_event_subscriptions USING btree (principal_id, state);


--
-- Name: idx_mcp_event_subscriptions_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_event_subscriptions_scope ON public.mcp_event_subscriptions USING btree (scope_kind, scope_id) WHERE (state = 'active'::text);


--
-- Name: idx_mcp_live_admissions_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_live_admissions_source ON public.mcp_live_admissions USING btree (source_id);


--
-- Name: idx_meeting_actions_assignee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_meeting_actions_assignee ON public.meeting_action_items USING btree (assignee_email, message_id, ordinal);


--
-- Name: idx_meeting_actions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_meeting_actions_status ON public.meeting_action_items USING btree (status, message_id, ordinal);


--
-- Name: idx_message_embedding_runs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_embedding_runs_active ON public.message_embedding_runs USING btree (state, id) WHERE (state = 'running'::text);


--
-- Name: idx_message_embedding_runs_operations_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_embedding_runs_operations_order ON public.message_embedding_runs USING btree (started_at DESC, id DESC);


--
-- Name: idx_message_labels_label; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_labels_label ON public.message_labels USING btree (label_id);


--
-- Name: idx_message_recipients_envelope; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_message_recipients_envelope ON public.message_recipients USING btree (message_id, participant_id, recipient_type, lower(COALESCE(email_address, ''::text)));


--
-- Name: idx_message_recipients_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_recipients_message ON public.message_recipients USING btree (message_id);


--
-- Name: idx_message_recipients_participant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_recipients_participant ON public.message_recipients USING btree (participant_id, recipient_type);


--
-- Name: idx_messages_content_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_content_changed_at ON public.messages USING btree (content_changed_at, id);


--
-- Name: idx_messages_conversation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_conversation ON public.messages USING btree (conversation_id, sent_at DESC);


--
-- Name: idx_messages_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_deleted ON public.messages USING btree (source_id, deleted_from_source_at);


--
-- Name: idx_messages_reply_to_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_reply_to_message_id ON public.messages USING btree (reply_to_message_id) WHERE (reply_to_message_id IS NOT NULL);


--
-- Name: idx_messages_rfc822_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_rfc822_message_id ON public.messages USING btree (rfc822_message_id);


--
-- Name: idx_messages_rfc822_message_id_canonical; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_rfc822_message_id_canonical ON public.messages USING btree ((
CASE
    WHEN ((length(rfc822_message_id) > 2) AND (substr(rfc822_message_id, 1, 1) = '<'::text) AND (substr(rfc822_message_id, length(rfc822_message_id), 1) = '>'::text) AND (substr(rfc822_message_id, 2, 1) <> ALL (ARRAY['<'::text, '>'::text, ' '::text])) AND (substr(rfc822_message_id, (length(rfc822_message_id) - 1), 1) <> ALL (ARRAY['<'::text, '>'::text, ' '::text]))) THEN substr(rfc822_message_id, 2, (length(rfc822_message_id) - 2))
    ELSE rfc822_message_id
END), source_id);


--
-- Name: idx_messages_search_fts_stale_v2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_search_fts_stale_v2 ON public.messages USING btree (id) WHERE ((search_fts IS NULL) OR (indexing_version IS DISTINCT FROM 2));


--
-- Name: idx_messages_sender; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_sender ON public.messages USING btree (sender_id);


--
-- Name: idx_messages_sent_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_sent_at ON public.messages USING btree (sent_at DESC);


--
-- Name: idx_messages_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_source ON public.messages USING btree (source_id);


--
-- Name: idx_messages_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_source_id ON public.messages USING btree (source_id, id);


--
-- Name: idx_messages_source_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_source_message_id ON public.messages USING btree (source_message_id);


--
-- Name: idx_messages_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_type ON public.messages USING btree (message_type);


--
-- Name: idx_operation_token_keys_one_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_operation_token_keys_one_active ON public.operation_token_keys USING btree (state) WHERE (state = 'active'::text);


--
-- Name: idx_organization_addresses_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organization_addresses_current ON public.organization_addresses USING btree (organization_id, address_kind, pref, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_addresses_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_addresses_property_identity ON public.organization_addresses USING btree (organization_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_attribute_values_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_attribute_values_current ON public.organization_attribute_values USING btree (organization_id, definition_id, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_attribute_values_current_text; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organization_attribute_values_current_text ON public.organization_attribute_values USING btree (definition_id, value_text) WHERE ((value_text IS NOT NULL) AND (active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_attribute_values_definition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organization_attribute_values_definition ON public.organization_attribute_values USING btree (definition_id, active_until);


--
-- Name: idx_organization_attribute_values_history; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organization_attribute_values_history ON public.organization_attribute_values USING btree (organization_id, definition_id, active_from DESC, id DESC);


--
-- Name: idx_organization_categories_current_value; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_categories_current_value ON public.organization_categories USING btree (organization_id, normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_contact_points_current_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organization_contact_points_current_lookup ON public.organization_contact_points USING btree (address_kind, service_id, scope_kind, scope_value, normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_contact_points_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_contact_points_property_identity ON public.organization_contact_points USING btree (organization_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_identifiers_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_identifiers_active ON public.organization_identifiers USING btree (organization_id, identifier_kind, normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_identifiers_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organization_identifiers_lookup ON public.organization_identifiers USING btree (identifier_kind, normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_identifiers_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_identifiers_property_identity ON public.organization_identifiers USING btree (organization_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_media_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organization_media_current ON public.organization_media USING btree (organization_id, media_kind, pref, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_media_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_media_property_identity ON public.organization_media USING btree (organization_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_names_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_names_active ON public.organization_names USING btree (organization_id, name_kind, name_normalized) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_names_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organization_names_lookup ON public.organization_names USING btree (name_normalized) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organization_names_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_organization_names_property_identity ON public.organization_names USING btree (organization_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_organizations_merged_into; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organizations_merged_into ON public.organizations USING btree (merged_into_id) WHERE (merged_into_id IS NOT NULL);


--
-- Name: idx_organizations_name_normalized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organizations_name_normalized ON public.organizations USING btree (name_normalized);


--
-- Name: idx_organizations_primary_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_organizations_primary_domain ON public.organizations USING btree (primary_domain) WHERE (primary_domain IS NOT NULL);


--
-- Name: idx_participant_identifiers_participant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_identifiers_participant ON public.participant_identifiers USING btree (participant_id);


--
-- Name: idx_participant_identifiers_service_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_identifiers_service_scope ON public.participant_identifiers USING btree (service_id, scope_kind, scope_value, identifier_value) WHERE (service_id IS NOT NULL);


--
-- Name: idx_participant_identifiers_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_identifiers_value ON public.participant_identifiers USING btree (identifier_value);


--
-- Name: idx_participant_identifiers_value_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_identifiers_value_lower ON public.participant_identifiers USING btree (lower(identifier_value));


--
-- Name: idx_participant_links_b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_links_b ON public.participant_links USING btree (participant_b);


--
-- Name: idx_participant_observations_current_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_observations_current_lookup ON public.participant_contact_observations USING btree (address_kind, service_id, scope_kind, scope_value, normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_participant_observations_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_participant_observations_identity ON public.participant_contact_observations USING btree (participant_id, source_id, address_kind, service_id, scope_kind, scope_value, normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_participant_observations_participant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_observations_participant ON public.participant_contact_observations USING btree (participant_id);


--
-- Name: idx_participant_observations_provider_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_observations_provider_user ON public.participant_contact_observations USING btree (provider_user_id) WHERE (provider_user_id IS NOT NULL);


--
-- Name: idx_participant_observations_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participant_observations_source ON public.participant_contact_observations USING btree (source_id) WHERE (source_id IS NOT NULL);


--
-- Name: idx_participants_canonical; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participants_canonical ON public.participants USING btree (canonical_id) WHERE (canonical_id IS NOT NULL);


--
-- Name: idx_participants_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_participants_email ON public.participants USING btree (email_address) WHERE (email_address IS NOT NULL);


--
-- Name: idx_participants_email_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_participants_email_lower ON public.participants USING btree (lower(email_address));


--
-- Name: idx_participants_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_participants_phone ON public.participants USING btree (phone_number) WHERE (phone_number IS NOT NULL);


--
-- Name: idx_person_addresses_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_addresses_current ON public.person_addresses USING btree (person_id, address_kind, pref, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_addresses_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_addresses_person ON public.person_addresses USING btree (person_id);


--
-- Name: idx_person_addresses_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_addresses_property_identity ON public.person_addresses USING btree (person_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_attribute_values_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_attribute_values_current ON public.person_attribute_values USING btree (person_id, definition_id, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_attribute_values_current_text; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_attribute_values_current_text ON public.person_attribute_values USING btree (definition_id, value_text) WHERE ((value_text IS NOT NULL) AND (active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_attribute_values_definition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_attribute_values_definition ON public.person_attribute_values USING btree (definition_id, active_until);


--
-- Name: idx_person_attribute_values_history; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_attribute_values_history ON public.person_attribute_values USING btree (person_id, definition_id, active_from DESC, id DESC);


--
-- Name: idx_person_attribute_values_record_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_attribute_values_record_ref ON public.person_attribute_values USING btree (value_record_type, value_record_id) WHERE (value_record_id IS NOT NULL);


--
-- Name: idx_person_brief_evidence_evidence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_brief_evidence_evidence ON public.person_brief_evidence USING btree (evidence_id, brief_id);


--
-- Name: idx_person_briefs_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_briefs_current ON public.person_briefs USING btree (person_id) WHERE (status = 'current'::text);


--
-- Name: idx_person_briefs_person_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_briefs_person_version ON public.person_briefs USING btree (person_id, version DESC);


--
-- Name: idx_person_categories_current_value; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_categories_current_value ON public.person_categories USING btree (person_id, normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_categories_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_categories_value ON public.person_categories USING btree (normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_contact_points_current_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_contact_points_current_lookup ON public.person_contact_points USING btree (address_kind, service_id, scope_kind, scope_value, normalized_value) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_contact_points_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_contact_points_person ON public.person_contact_points USING btree (person_id);


--
-- Name: idx_person_contact_points_person_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_contact_points_person_current ON public.person_contact_points USING btree (person_id, address_kind, pref, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_contact_points_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_contact_points_property_identity ON public.person_contact_points USING btree (person_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_contact_points_service; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_contact_points_service ON public.person_contact_points USING btree (service_id) WHERE (service_id IS NOT NULL);


--
-- Name: idx_person_contact_state_dirty; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_contact_state_dirty ON public.person_contact_state USING btree (person_id) WHERE (dirty_at IS NOT NULL);


--
-- Name: idx_person_contact_state_last_contact; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_contact_state_last_contact ON public.person_contact_state USING btree (last_contact_at DESC);


--
-- Name: idx_person_dates_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_dates_current ON public.person_dates USING btree (person_id, date_kind, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_dates_month_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_dates_month_day ON public.person_dates USING btree (date_month, date_day) WHERE ((active_until IS NULL) AND (superseded_at IS NULL) AND (date_month IS NOT NULL));


--
-- Name: idx_person_dates_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_dates_person ON public.person_dates USING btree (person_id);


--
-- Name: idx_person_dates_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_dates_property_identity ON public.person_dates USING btree (person_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_embedding_runs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_embedding_runs_active ON public.person_embedding_runs USING btree (state, id) WHERE (state = 'running'::text);


--
-- Name: idx_person_embedding_runs_operations_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_embedding_runs_operations_order ON public.person_embedding_runs USING btree (started_at DESC, id DESC);


--
-- Name: idx_person_fact_claim_evidence_evidence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_claim_evidence_evidence ON public.person_fact_claim_evidence USING btree (evidence_id, claim_id);


--
-- Name: idx_person_fact_claims_person_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_claims_person_target ON public.person_fact_claims USING btree (person_id, target_kind, target_key, id DESC);


--
-- Name: idx_person_fact_decisions_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_decisions_person ON public.person_fact_decisions USING btree (person_id, id DESC);


--
-- Name: idx_person_fact_decisions_projection; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_decisions_projection ON public.person_fact_decisions USING btree (person_id, projection_kind, projection_row_id);


--
-- Name: idx_person_fact_evidence_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_evidence_person ON public.person_fact_evidence USING btree (person_id, id DESC);


--
-- Name: idx_person_fact_evidence_status_latest; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_evidence_status_latest ON public.person_fact_evidence_status_events USING btree (person_id, evidence_key, source_version, id DESC);


--
-- Name: idx_person_fact_generations_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_generations_person ON public.person_fact_generations USING btree (person_id, id DESC);


--
-- Name: idx_person_fact_pin_events_latest; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_pin_events_latest ON public.person_fact_pin_events USING btree (person_id, target_kind, target_key, id DESC);


--
-- Name: idx_person_fact_resolutions_person_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_fact_resolutions_person_target ON public.person_fact_resolutions USING btree (person_id, target_kind, target_key, id DESC);


--
-- Name: idx_person_inference_consents_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_inference_consents_active ON public.person_inference_consents USING btree (profile_fingerprint) WHERE (revoked_at IS NULL);


--
-- Name: idx_person_match_judgments_candidate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_match_judgments_candidate ON public.person_match_judgments USING btree (candidate_id, id);


--
-- Name: idx_person_match_judgments_final; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_match_judgments_final ON public.person_match_judgments USING btree (candidate_id, fingerprint) WHERE (status = ANY (ARRAY['scored'::text, 'terminal_error'::text]));


--
-- Name: idx_person_match_scoring_contact_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_match_scoring_contact_lookup ON public.participant_contact_observations USING btree (address_kind, normalized_value, participant_id) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_media_content_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_media_content_hash ON public.person_media USING btree (content_hash) WHERE (content_hash IS NOT NULL);


--
-- Name: idx_person_media_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_media_current ON public.person_media USING btree (person_id, media_kind, pref, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_media_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_media_person ON public.person_media USING btree (person_id);


--
-- Name: idx_person_media_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_media_property_identity ON public.person_media USING btree (person_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_merge_participants_split; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_merge_participants_split ON public.person_merge_participants USING btree (split_id) WHERE (split_id IS NOT NULL);


--
-- Name: idx_person_merge_review_candidates_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_merge_review_candidates_person ON public.person_merge_review_candidates USING btree (survivor_person_id, state, id);


--
-- Name: idx_person_merge_row_person_refs_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_merge_row_person_refs_person ON public.person_merge_row_person_refs USING btree (person_id, merge_id);


--
-- Name: idx_person_merge_rows_current_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_merge_rows_current_id ON public.person_merge_rows USING btree (table_name, current_row_id) WHERE ((current_row_id IS NOT NULL) AND (split_id IS NULL));


--
-- Name: idx_person_merge_rows_current_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_merge_rows_current_key ON public.person_merge_rows USING btree (table_name, current_row_key) WHERE ((current_row_key IS NOT NULL) AND (split_id IS NULL));


--
-- Name: idx_person_merge_rows_participant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_merge_rows_participant ON public.person_merge_rows USING btree (participant_id, merge_id) WHERE (participant_id IS NOT NULL);


--
-- Name: idx_person_merge_rows_split; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_merge_rows_split ON public.person_merge_rows USING btree (split_id) WHERE (split_id IS NOT NULL);


--
-- Name: idx_person_merges_current_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_merges_current_person ON public.person_merges USING btree (current_person_id, id DESC);


--
-- Name: idx_person_names_current; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_names_current ON public.person_names USING btree (person_id, name_kind, ordinal) WHERE ((active_until IS NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_names_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_names_person ON public.person_names USING btree (person_id);


--
-- Name: idx_person_names_property_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_names_property_identity ON public.person_names USING btree (person_id, source, source_ref, COALESCE(source_resource_uid, ''::text), vcard_property, vcard_prop_id) WHERE ((source_ref IS NOT NULL) AND (vcard_prop_id IS NOT NULL) AND (superseded_at IS NULL));


--
-- Name: idx_person_relationship_reviews_occurrence_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_relationship_reviews_occurrence_unique ON public.person_relationship_reviews USING btree (person_id, raw_related_type, raw_related_value, source, COALESCE(source_ref, ''::text), COALESCE(source_resource_uid, ''::text), COALESCE(vcard_property, ''::text), COALESCE(vcard_group, ''::text), COALESCE(vcard_prop_id, ''::text), COALESCE(vcard_pid, ''::text), COALESCE(vcard_altid, ''::text));


--
-- Name: idx_person_relationship_reviews_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationship_reviews_status ON public.person_relationship_reviews USING btree (status, person_id, id);


--
-- Name: idx_person_relationships_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_relationships_active_unique ON public.person_relationships USING btree (source_person_id, target_person_id, relationship_type_id) WHERE (end_year IS NULL);


--
-- Name: idx_person_relationships_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationships_source ON public.person_relationships USING btree (source_person_id);


--
-- Name: idx_person_relationships_source_current_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationships_source_current_edge ON public.person_relationships USING btree (source_person_id, id) WHERE (end_year IS NULL);


--
-- Name: idx_person_relationships_source_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationships_source_edge ON public.person_relationships USING btree (source_person_id, id);


--
-- Name: idx_person_relationships_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationships_target ON public.person_relationships USING btree (target_person_id);


--
-- Name: idx_person_relationships_target_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationships_target_active ON public.person_relationships USING btree (target_person_id, relationship_type_id) WHERE (end_year IS NULL);


--
-- Name: idx_person_relationships_target_current_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationships_target_current_edge ON public.person_relationships USING btree (target_person_id, id) WHERE (end_year IS NULL);


--
-- Name: idx_person_relationships_target_edge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationships_target_edge ON public.person_relationships USING btree (target_person_id, id);


--
-- Name: idx_person_relationships_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_relationships_type ON public.person_relationships USING btree (relationship_type_id);


--
-- Name: idx_person_semantic_embedding_consents_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_person_semantic_embedding_consents_active ON public.person_semantic_embedding_consents USING btree (profile_fingerprint) WHERE (revoked_at IS NULL);


--
-- Name: idx_person_splits_merge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_splits_merge ON public.person_splits USING btree (merge_id, id);


--
-- Name: idx_person_sweep_attempts_generation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_attempts_generation ON public.person_sweep_attempts USING btree (generation_id);


--
-- Name: idx_person_sweep_attempts_operations_failure; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_attempts_operations_failure ON public.person_sweep_attempts USING btree (run_id, COALESCE(completed_at, started_at) DESC, id COLLATE "C" DESC) WHERE (failure_class <> ''::text);


--
-- Name: idx_person_sweep_attempts_person_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_attempts_person_started ON public.person_sweep_attempts USING btree (person_id, started_at DESC);


--
-- Name: idx_person_sweep_attempts_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_attempts_run ON public.person_sweep_attempts USING btree (run_id, id);


--
-- Name: idx_person_sweep_changes_person_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_changes_person_message ON public.person_sweep_changes USING btree (person_id, message_id, sequence);


--
-- Name: idx_person_sweep_changes_person_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_changes_person_sequence ON public.person_sweep_changes USING btree (person_id, sequence);


--
-- Name: idx_person_sweep_changes_source_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_changes_source_sequence ON public.person_sweep_changes USING btree (source_id, sequence);


--
-- Name: idx_person_sweep_cursors_incomplete; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_cursors_incomplete ON public.person_sweep_cursors USING btree (person_id) WHERE (reconciliation_complete = false);


--
-- Name: idx_person_sweep_runs_operations_bytewise_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_runs_operations_bytewise_order ON public.person_sweep_runs USING btree (started_at DESC, id COLLATE "C" DESC);


--
-- Name: idx_person_sweep_runs_operations_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_runs_operations_order ON public.person_sweep_runs USING btree (started_at DESC, id DESC);


--
-- Name: idx_person_sweep_runs_operations_running; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_runs_operations_running ON public.person_sweep_runs USING btree (started_at DESC, id COLLATE "C" DESC) WHERE (status = 'running'::text);


--
-- Name: idx_person_sweep_runs_operations_succeeded; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_runs_operations_succeeded ON public.person_sweep_runs USING btree (started_at DESC, id COLLATE "C" DESC) WHERE (status = 'succeeded'::text);


--
-- Name: idx_person_sweep_sync_publications_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_sync_publications_source ON public.person_sweep_sync_publications USING btree (source_id, sync_run_id);


--
-- Name: idx_person_sweep_work_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_work_available ON public.person_sweep_work USING btree (available_at, person_id);


--
-- Name: idx_person_sweep_work_lease; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_sweep_work_lease ON public.person_sweep_work USING btree (lease_until, person_id);


--
-- Name: idx_person_uid_aliases_survivor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_person_uid_aliases_survivor ON public.person_uid_aliases USING btree (surviving_person_id) WHERE (surviving_person_id IS NOT NULL);


--
-- Name: idx_reaction_source_events_reaction; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reaction_source_events_reaction ON public.reaction_source_events USING btree (reaction_id);


--
-- Name: idx_reactions_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reactions_message ON public.reactions USING btree (message_id);


--
-- Name: idx_source_import_items_source_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_source_import_items_source_provider ON public.source_import_items USING btree (source_id, provider, status);


--
-- Name: idx_sources_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sources_type ON public.sources USING btree (source_type);


--
-- Name: idx_sync_run_items_run_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sync_run_items_run_status ON public.sync_run_items USING btree (sync_run_id, status, created_at DESC);


--
-- Name: idx_sync_runs_operation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sync_runs_operation ON public.sync_runs USING btree (operation_id, id) WHERE (operation_id IS NOT NULL);


--
-- Name: idx_sync_runs_operations_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sync_runs_operations_order ON public.sync_runs USING btree (started_at DESC, id DESC);


--
-- Name: idx_sync_runs_operations_running; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sync_runs_operations_running ON public.sync_runs USING btree (started_at DESC, id DESC) WHERE (status = 'running'::text);


--
-- Name: idx_sync_runs_operations_succeeded; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sync_runs_operations_succeeded ON public.sync_runs USING btree (started_at DESC, id DESC) WHERE ((status = 'completed'::text) AND (errors_count = 0));


--
-- Name: idx_sync_runs_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sync_runs_source ON public.sync_runs USING btree (source_id, started_at DESC);


--
-- Name: idx_vcard_resource_envelopes_canonical_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vcard_resource_envelopes_canonical_uid ON public.vcard_resource_envelopes USING btree (canonical_person_uid);


--
-- Name: idx_vcard_resource_envelopes_href; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vcard_resource_envelopes_href ON public.vcard_resource_envelopes USING btree (source_ref, href) WHERE (href IS NOT NULL);


--
-- Name: idx_vcard_resource_envelopes_person; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vcard_resource_envelopes_person ON public.vcard_resource_envelopes USING btree (person_id);


--
-- Name: idx_visual_embedding_runs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visual_embedding_runs_active ON public.visual_embedding_runs USING btree (state, id) WHERE (state = 'running'::text);


--
-- Name: idx_visual_embedding_runs_operations_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visual_embedding_runs_operations_order ON public.visual_embedding_runs USING btree (started_at DESC, id DESC);


--
-- Name: idx_visual_generations_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_visual_generations_active ON public.visual_generations USING btree (state) WHERE (state = 'active'::text);


--
-- Name: idx_visual_generations_building; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_visual_generations_building ON public.visual_generations USING btree (state) WHERE (state = 'building'::text);


--
-- Name: messages_search_fts_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_search_fts_idx ON public.messages USING gin (search_fts);


--
-- Name: person_enrichment_attempts_next_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX person_enrichment_attempts_next_action ON public.person_enrichment_attempts USING btree (state, next_action_at);


--
-- Name: person_enrichment_attempts_person_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX person_enrichment_attempts_person_created ON public.person_enrichment_attempts USING btree (person_id, created_at);


--
-- Name: person_enrichment_attempts_provider_job; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX person_enrichment_attempts_provider_job ON public.person_enrichment_attempts USING btree (profile_fingerprint, provider_job_id) WHERE (provider_job_id IS NOT NULL);


--
-- Name: person_enrichment_attempts_run_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX person_enrichment_attempts_run_state ON public.person_enrichment_attempts USING btree (run_id, state);


--
-- Name: person_enrichment_consents_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX person_enrichment_consents_active ON public.person_enrichment_consents USING btree (profile_fingerprint) WHERE (revoked_at IS NULL);


--
-- Name: person_enrichment_provider_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX person_enrichment_provider_identity_unique ON public.person_enrichment_provider_identities USING btree (provider_namespace, provider_person_id);


--
-- Name: person_enrichment_work_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX person_enrichment_work_due ON public.person_enrichment_work USING btree (profile_fingerprint, due_at);


--
-- Name: person_enrichment_work_lease; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX person_enrichment_work_lease ON public.person_enrichment_work USING btree (run_id, lease_until);


--
-- Name: person_match_consents_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX person_match_consents_active ON public.person_match_consents USING btree (disclosure_fingerprint) WHERE (revoked_at IS NULL);


--
-- Name: employments directory_dirty_employments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER directory_dirty_employments AFTER INSERT OR DELETE OR UPDATE ON public.employments FOR EACH ROW EXECUTE FUNCTION public.directory_projection_mark_dirty('person_id');


--
-- Name: organizations directory_dirty_organizations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER directory_dirty_organizations AFTER INSERT OR DELETE OR UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.directory_projection_mark_organization_dirty();


--
-- Name: person_categories directory_dirty_person_categories; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER directory_dirty_person_categories AFTER INSERT OR DELETE OR UPDATE ON public.person_categories FOR EACH ROW EXECUTE FUNCTION public.directory_projection_mark_dirty('person_id');


--
-- Name: person_contact_points directory_dirty_person_contact_points; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER directory_dirty_person_contact_points AFTER INSERT OR DELETE OR UPDATE ON public.person_contact_points FOR EACH ROW EXECUTE FUNCTION public.directory_projection_mark_dirty('person_id');


--
-- Name: person_contact_state directory_dirty_person_contact_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER directory_dirty_person_contact_state AFTER INSERT OR DELETE OR UPDATE ON public.person_contact_state FOR EACH ROW EXECUTE FUNCTION public.directory_projection_mark_dirty('person_id');


--
-- Name: person_names directory_dirty_person_names; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER directory_dirty_person_names AFTER INSERT OR DELETE OR UPDATE ON public.person_names FOR EACH ROW EXECUTE FUNCTION public.directory_projection_mark_dirty('person_id');


--
-- Name: persons directory_dirty_persons; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER directory_dirty_persons AFTER INSERT OR DELETE OR UPDATE ON public.persons FOR EACH ROW EXECUTE FUNCTION public.directory_projection_mark_dirty('id');


--
-- Name: activity_event_persons trg_activity_direct_link_delete_dirty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_direct_link_delete_dirty AFTER DELETE ON public.activity_event_persons FOR EACH ROW EXECUTE FUNCTION public.dirty_activity_direct_link_delete();


--
-- Name: conversation_participants trg_activity_queue_conversation_people_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_queue_conversation_people_delete AFTER DELETE ON public.conversation_participants FOR EACH ROW EXECUTE FUNCTION public.queue_activity_conversation_people_delete();


--
-- Name: conversation_participants trg_activity_queue_conversation_people_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_queue_conversation_people_insert AFTER INSERT ON public.conversation_participants FOR EACH ROW EXECUTE FUNCTION public.queue_activity_conversation_people_insert();


--
-- Name: conversation_participants trg_activity_queue_conversation_people_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_queue_conversation_people_update AFTER UPDATE ON public.conversation_participants FOR EACH ROW EXECUTE FUNCTION public.queue_activity_conversation_people_update();


--
-- Name: conversations trg_activity_queue_conversation_type_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_queue_conversation_type_update AFTER UPDATE OF conversation_type ON public.conversations FOR EACH ROW EXECUTE FUNCTION public.queue_activity_conversation_type_update();


--
-- Name: messages trg_activity_queue_messages_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_queue_messages_update AFTER UPDATE OF source_id, conversation_id, sender_id, message_type, sent_at, received_at, internal_date, deleted_at, deleted_from_source_at, metadata, source_is_from_me ON public.messages FOR EACH ROW EXECUTE FUNCTION public.queue_activity_messages();


--
-- Name: message_recipients trg_activity_queue_recipients_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_queue_recipients_delete AFTER DELETE ON public.message_recipients FOR EACH ROW EXECUTE FUNCTION public.queue_activity_recipient_delete();


--
-- Name: message_recipients trg_activity_queue_recipients_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_queue_recipients_insert AFTER INSERT ON public.message_recipients FOR EACH ROW EXECUTE FUNCTION public.queue_activity_recipient_insert();


--
-- Name: message_recipients trg_activity_queue_recipients_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_activity_queue_recipients_update AFTER UPDATE ON public.message_recipients FOR EACH ROW EXECUTE FUNCTION public.queue_activity_recipient_update();


--
-- Name: attachments trg_attachment_change_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_attachment_change_delete AFTER DELETE ON public.attachments FOR EACH ROW EXECUTE FUNCTION public.capture_attachment_change();


--
-- Name: attachments trg_attachment_change_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_attachment_change_insert AFTER INSERT ON public.attachments FOR EACH ROW EXECUTE FUNCTION public.capture_attachment_change();


--
-- Name: attachments trg_attachment_change_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_attachment_change_update AFTER UPDATE OF message_id, filename, mime_type, size, content_hash, storage_path, media_type, width, height, duration_ms, source_attachment_id, attachment_metadata, attachment_role, role_source, source_part_key, content_id, encryption_version ON public.attachments FOR EACH ROW WHEN (((old.message_id IS DISTINCT FROM new.message_id) OR (old.filename IS DISTINCT FROM new.filename) OR (old.mime_type IS DISTINCT FROM new.mime_type) OR (old.size IS DISTINCT FROM new.size) OR (old.content_hash IS DISTINCT FROM new.content_hash) OR (old.storage_path IS DISTINCT FROM new.storage_path) OR (old.media_type IS DISTINCT FROM new.media_type) OR (old.width IS DISTINCT FROM new.width) OR (old.height IS DISTINCT FROM new.height) OR (old.duration_ms IS DISTINCT FROM new.duration_ms) OR (old.source_attachment_id IS DISTINCT FROM new.source_attachment_id) OR (old.attachment_metadata IS DISTINCT FROM new.attachment_metadata) OR (old.attachment_role IS DISTINCT FROM new.attachment_role) OR (old.role_source IS DISTINCT FROM new.role_source) OR (old.source_part_key IS DISTINCT FROM new.source_part_key) OR (old.content_id IS DISTINCT FROM new.content_id) OR (old.encryption_version IS DISTINCT FROM new.encryption_version))) EXECUTE FUNCTION public.capture_attachment_change();


--
-- Name: messages trg_attachment_message_live_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_attachment_message_live_change AFTER UPDATE OF deleted_at, deleted_from_source_at ON public.messages FOR EACH ROW WHEN ((((old.deleted_at IS NULL) AND (old.deleted_from_source_at IS NULL)) IS DISTINCT FROM ((new.deleted_at IS NULL) AND (new.deleted_from_source_at IS NULL)))) EXECUTE FUNCTION public.capture_attachment_message_live_change();


--
-- Name: document_embedding_runs trg_document_embedding_runs_terminal_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_document_embedding_runs_terminal_immutable BEFORE UPDATE ON public.document_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.reject_terminal_operation_invocation_update();


--
-- Name: document_extraction_runs trg_document_extraction_runs_terminal_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_document_extraction_runs_terminal_immutable BEFORE UPDATE ON public.document_extraction_runs FOR EACH ROW EXECUTE FUNCTION public.reject_terminal_operation_invocation_update();


--
-- Name: messages trg_document_message_type_revision; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_document_message_type_revision AFTER UPDATE OF message_type ON public.messages FOR EACH ROW EXECUTE FUNCTION public.bump_document_index_revision_after_message_type_update();


--
-- Name: document_occurrences trg_document_occurrence_delete_revision; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_document_occurrence_delete_revision AFTER DELETE ON public.document_occurrences FOR EACH ROW EXECUTE FUNCTION public.bump_document_index_revision_after_occurrence_delete();


--
-- Name: message_bodies trg_embedding_changes_bodies; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_changes_bodies AFTER INSERT OR DELETE OR UPDATE ON public.message_bodies FOR EACH ROW EXECUTE FUNCTION public.journal_contextual_body_change();


--
-- Name: conversations trg_embedding_changes_conversation_title; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_changes_conversation_title AFTER UPDATE OF title ON public.conversations FOR EACH ROW EXECUTE FUNCTION public.journal_beeper_conversation_title();


--
-- Name: conversation_participants trg_embedding_changes_membership; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_changes_membership AFTER INSERT OR DELETE OR UPDATE ON public.conversation_participants FOR EACH ROW EXECUTE FUNCTION public.journal_beeper_membership_change();


--
-- Name: messages trg_embedding_changes_message_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_changes_message_delete BEFORE DELETE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.journal_contextual_message_change();


--
-- Name: messages trg_embedding_changes_messages; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_changes_messages AFTER UPDATE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.journal_contextual_message_change();


--
-- Name: participants trg_embedding_changes_participant_display_name; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_changes_participant_display_name AFTER UPDATE OF display_name, email_address, phone_number ON public.participants FOR EACH ROW EXECUTE FUNCTION public.journal_beeper_participant_display_name();


--
-- Name: message_bodies trg_embedding_clock_bodies; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_clock_bodies BEFORE INSERT OR DELETE OR UPDATE ON public.message_bodies FOR EACH STATEMENT EXECUTE FUNCTION public.lock_embedding_change_clock();


--
-- Name: conversations trg_embedding_clock_conversations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_clock_conversations BEFORE UPDATE OF title ON public.conversations FOR EACH STATEMENT EXECUTE FUNCTION public.lock_embedding_change_clock();


--
-- Name: conversation_participants trg_embedding_clock_membership; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_clock_membership BEFORE INSERT OR DELETE OR UPDATE ON public.conversation_participants FOR EACH STATEMENT EXECUTE FUNCTION public.lock_embedding_change_clock();


--
-- Name: messages trg_embedding_clock_messages; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_clock_messages BEFORE INSERT OR DELETE OR UPDATE ON public.messages FOR EACH STATEMENT EXECUTE FUNCTION public.lock_embedding_change_clock();


--
-- Name: participants trg_embedding_clock_participants; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_embedding_clock_participants BEFORE UPDATE OF display_name, email_address, phone_number ON public.participants FOR EACH STATEMENT EXECUTE FUNCTION public.lock_embedding_change_clock();


--
-- Name: message_bodies trg_message_bodies_content_changed_del; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_message_bodies_content_changed_del AFTER DELETE ON public.message_bodies FOR EACH ROW EXECUTE FUNCTION public.bump_message_content_changed_at_del();


--
-- Name: message_bodies trg_message_bodies_content_changed_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_message_bodies_content_changed_ins AFTER INSERT ON public.message_bodies FOR EACH ROW EXECUTE FUNCTION public.bump_message_content_changed_at();


--
-- Name: message_bodies trg_message_bodies_content_changed_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_message_bodies_content_changed_upd AFTER UPDATE ON public.message_bodies FOR EACH ROW WHEN (((old.body_text IS DISTINCT FROM new.body_text) OR (old.body_html IS DISTINCT FROM new.body_html))) EXECUTE FUNCTION public.bump_message_content_changed_at();


--
-- Name: message_bodies trg_message_bodies_last_modified; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_message_bodies_last_modified AFTER INSERT OR UPDATE ON public.message_bodies FOR EACH ROW EXECUTE FUNCTION public.bump_message_last_modified();


--
-- Name: message_embedding_runs trg_message_embedding_runs_terminal_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_message_embedding_runs_terminal_immutable BEFORE UPDATE ON public.message_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.reject_terminal_operation_invocation_update();


--
-- Name: messages trg_messages_content_changed_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_messages_content_changed_at BEFORE UPDATE OF source_message_id, list_id, conversation_id, sender_id, message_type, sent_at, received_at, internal_date, subject, snippet, metadata, size_estimate, has_attachments, attachment_count, deleted_at, deleted_from_source_at ON public.messages FOR EACH ROW WHEN (((NOT (old.content_changed_at IS DISTINCT FROM new.content_changed_at)) AND ((old.source_message_id IS DISTINCT FROM new.source_message_id) OR (old.list_id IS DISTINCT FROM new.list_id) OR (old.conversation_id IS DISTINCT FROM new.conversation_id) OR (old.sender_id IS DISTINCT FROM new.sender_id) OR (old.message_type IS DISTINCT FROM new.message_type) OR (old.sent_at IS DISTINCT FROM new.sent_at) OR (old.received_at IS DISTINCT FROM new.received_at) OR (old.internal_date IS DISTINCT FROM new.internal_date) OR (old.subject IS DISTINCT FROM new.subject) OR (old.snippet IS DISTINCT FROM new.snippet) OR (old.metadata IS DISTINCT FROM new.metadata) OR (old.size_estimate IS DISTINCT FROM new.size_estimate) OR (old.has_attachments IS DISTINCT FROM new.has_attachments) OR (old.attachment_count IS DISTINCT FROM new.attachment_count) OR (old.deleted_at IS DISTINCT FROM new.deleted_at) OR (old.deleted_from_source_at IS DISTINCT FROM new.deleted_from_source_at)))) EXECUTE FUNCTION public.set_messages_content_changed_at();


--
-- Name: messages trg_messages_content_changed_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_messages_content_changed_ins BEFORE INSERT ON public.messages FOR EACH ROW WHEN ((new.content_changed_at IS NULL)) EXECUTE FUNCTION public.set_messages_content_changed_at();


--
-- Name: messages trg_messages_last_modified; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_messages_last_modified BEFORE UPDATE ON public.messages FOR EACH ROW WHEN ((NOT (old.last_modified IS DISTINCT FROM new.last_modified))) EXECUTE FUNCTION public.set_messages_last_modified();


--
-- Name: carddav_sync_runs trg_operation_history_carddav_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_carddav_delete AFTER DELETE ON public.carddav_sync_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: carddav_sync_runs trg_operation_history_carddav_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_carddav_insert AFTER INSERT ON public.carddav_sync_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: carddav_sync_runs trg_operation_history_carddav_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_carddav_update AFTER UPDATE ON public.carddav_sync_runs FOR EACH ROW WHEN (((old.started_at IS DISTINCT FROM new.started_at) OR (old.state IS DISTINCT FROM new.state))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: document_embedding_runs trg_operation_history_document_embedding_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_document_embedding_delete AFTER DELETE ON public.document_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: document_embedding_runs trg_operation_history_document_embedding_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_document_embedding_insert AFTER INSERT ON public.document_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: document_embedding_runs trg_operation_history_document_embedding_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_document_embedding_update AFTER UPDATE ON public.document_embedding_runs FOR EACH ROW WHEN (((old.started_at IS DISTINCT FROM new.started_at) OR (old.state IS DISTINCT FROM new.state))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: document_extraction_runs trg_operation_history_document_extraction_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_document_extraction_delete AFTER DELETE ON public.document_extraction_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: document_extraction_runs trg_operation_history_document_extraction_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_document_extraction_insert AFTER INSERT ON public.document_extraction_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: document_extraction_runs trg_operation_history_document_extraction_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_document_extraction_update AFTER UPDATE ON public.document_extraction_runs FOR EACH ROW WHEN (((old.started_at IS DISTINCT FROM new.started_at) OR (old.state IS DISTINCT FROM new.state))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: message_embedding_runs trg_operation_history_message_embedding_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_message_embedding_delete AFTER DELETE ON public.message_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: message_embedding_runs trg_operation_history_message_embedding_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_message_embedding_insert AFTER INSERT ON public.message_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: message_embedding_runs trg_operation_history_message_embedding_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_message_embedding_update AFTER UPDATE ON public.message_embedding_runs FOR EACH ROW WHEN (((old.started_at IS DISTINCT FROM new.started_at) OR (old.state IS DISTINCT FROM new.state))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_embedding_runs trg_operation_history_person_embedding_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_embedding_delete AFTER DELETE ON public.person_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_embedding_runs trg_operation_history_person_embedding_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_embedding_insert AFTER INSERT ON public.person_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_embedding_runs trg_operation_history_person_embedding_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_embedding_update AFTER UPDATE ON public.person_embedding_runs FOR EACH ROW WHEN (((old.started_at IS DISTINCT FROM new.started_at) OR (old.state IS DISTINCT FROM new.state))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_enrichment_runs trg_operation_history_person_enrichment_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_enrichment_delete AFTER DELETE ON public.person_enrichment_runs FOR EACH ROW WHEN ((old.started_at IS NOT NULL)) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_enrichment_runs trg_operation_history_person_enrichment_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_enrichment_insert AFTER INSERT ON public.person_enrichment_runs FOR EACH ROW WHEN ((new.started_at IS NOT NULL)) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_enrichment_runs trg_operation_history_person_enrichment_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_enrichment_update AFTER UPDATE ON public.person_enrichment_runs FOR EACH ROW WHEN ((((old.started_at IS NULL) IS DISTINCT FROM (new.started_at IS NULL)) OR ((new.started_at IS NOT NULL) AND ((old.started_at IS DISTINCT FROM new.started_at) OR (old.state IS DISTINCT FROM new.state))))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_sweep_runs trg_operation_history_person_sweep_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_sweep_delete AFTER DELETE ON public.person_sweep_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_sweep_runs trg_operation_history_person_sweep_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_sweep_insert AFTER INSERT ON public.person_sweep_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_sweep_runs trg_operation_history_person_sweep_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_person_sweep_update AFTER UPDATE ON public.person_sweep_runs FOR EACH ROW WHEN (((old.started_at IS DISTINCT FROM new.started_at) OR (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: sync_runs trg_operation_history_source_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_source_delete AFTER DELETE ON public.sync_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: sync_runs trg_operation_history_source_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_source_insert AFTER INSERT ON public.sync_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: sync_runs trg_operation_history_source_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_source_update AFTER UPDATE ON public.sync_runs FOR EACH ROW WHEN (((old.started_at IS DISTINCT FROM new.started_at) OR (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: visual_embedding_runs trg_operation_history_visual_embedding_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_visual_embedding_delete AFTER DELETE ON public.visual_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: visual_embedding_runs trg_operation_history_visual_embedding_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_visual_embedding_insert AFTER INSERT ON public.visual_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: visual_embedding_runs trg_operation_history_visual_embedding_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_operation_history_visual_embedding_update AFTER UPDATE ON public.visual_embedding_runs FOR EACH ROW WHEN (((old.started_at IS DISTINCT FROM new.started_at) OR (old.state IS DISTINCT FROM new.state))) EXECUTE FUNCTION public.advance_operation_history_membership_revision();


--
-- Name: person_embedding_runs trg_person_embedding_runs_terminal_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_embedding_runs_terminal_immutable BEFORE UPDATE ON public.person_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.reject_terminal_operation_invocation_update();


--
-- Name: person_participants trg_person_sweep_changes_bindings; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_bindings AFTER INSERT OR UPDATE ON public.person_participants FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_bindings();


--
-- Name: person_participants trg_person_sweep_changes_bindings_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_bindings_delete BEFORE DELETE ON public.person_participants FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_bindings();


--
-- Name: message_bodies trg_person_sweep_changes_bodies; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_bodies AFTER INSERT OR UPDATE ON public.message_bodies FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_bodies();


--
-- Name: message_bodies trg_person_sweep_changes_bodies_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_bodies_delete BEFORE DELETE ON public.message_bodies FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_bodies();


--
-- Name: messages trg_person_sweep_changes_message_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_message_delete BEFORE DELETE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_messages();


--
-- Name: messages trg_person_sweep_changes_message_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_message_insert AFTER INSERT ON public.messages FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_messages();


--
-- Name: messages trg_person_sweep_changes_message_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_message_update AFTER UPDATE OF source_message_id, list_id, conversation_id, sender_id, message_type, sent_at, received_at, internal_date, subject, snippet, metadata, size_estimate, has_attachments, attachment_count, deleted_at, deleted_from_source_at ON public.messages FOR EACH ROW WHEN (((old.source_message_id IS DISTINCT FROM new.source_message_id) OR (old.list_id IS DISTINCT FROM new.list_id) OR (old.conversation_id IS DISTINCT FROM new.conversation_id) OR (old.sender_id IS DISTINCT FROM new.sender_id) OR (old.message_type IS DISTINCT FROM new.message_type) OR (old.sent_at IS DISTINCT FROM new.sent_at) OR (old.received_at IS DISTINCT FROM new.received_at) OR (old.internal_date IS DISTINCT FROM new.internal_date) OR (old.subject IS DISTINCT FROM new.subject) OR (old.snippet IS DISTINCT FROM new.snippet) OR (old.metadata IS DISTINCT FROM new.metadata) OR (old.size_estimate IS DISTINCT FROM new.size_estimate) OR (old.has_attachments IS DISTINCT FROM new.has_attachments) OR (old.attachment_count IS DISTINCT FROM new.attachment_count) OR (old.deleted_at IS DISTINCT FROM new.deleted_at) OR (old.deleted_from_source_at IS DISTINCT FROM new.deleted_from_source_at))) EXECUTE FUNCTION public.msgvault_person_sweep_changes_messages();


--
-- Name: message_recipients trg_person_sweep_changes_recipients; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_recipients AFTER INSERT OR UPDATE ON public.message_recipients FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_recipients();


--
-- Name: message_recipients trg_person_sweep_changes_recipients_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_recipients_delete BEFORE DELETE ON public.message_recipients FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_recipients();


--
-- Name: conversation_participants trg_person_sweep_changes_roster; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_roster AFTER INSERT OR UPDATE ON public.conversation_participants FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_roster();


--
-- Name: conversation_participants trg_person_sweep_changes_roster_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_person_sweep_changes_roster_delete BEFORE DELETE ON public.conversation_participants FOR EACH ROW EXECUTE FUNCTION public.msgvault_person_sweep_changes_roster();


--
-- Name: visual_embedding_runs trg_visual_embedding_runs_terminal_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_embedding_runs_terminal_immutable BEFORE UPDATE ON public.visual_embedding_runs FOR EACH ROW EXECUTE FUNCTION public.reject_terminal_operation_invocation_update();


--
-- Name: attachments trg_visual_publication_attachment_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_attachment_delete AFTER DELETE ON public.attachments FOR EACH ROW EXECUTE FUNCTION public.invalidate_visual_publication_attachment();


--
-- Name: attachments trg_visual_publication_attachment_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_attachment_insert AFTER INSERT ON public.attachments FOR EACH ROW EXECUTE FUNCTION public.invalidate_visual_publication_attachment();


--
-- Name: attachments trg_visual_publication_attachment_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_attachment_update AFTER UPDATE OF message_id, filename, mime_type, size, content_hash, storage_path, media_type, width, height, duration_ms, source_attachment_id, attachment_metadata, attachment_role, role_source, source_part_key, content_id, encryption_version ON public.attachments FOR EACH ROW WHEN (((old.message_id IS DISTINCT FROM new.message_id) OR (old.filename IS DISTINCT FROM new.filename) OR (old.mime_type IS DISTINCT FROM new.mime_type) OR (old.size IS DISTINCT FROM new.size) OR (old.content_hash IS DISTINCT FROM new.content_hash) OR (old.storage_path IS DISTINCT FROM new.storage_path) OR (old.media_type IS DISTINCT FROM new.media_type) OR (old.width IS DISTINCT FROM new.width) OR (old.height IS DISTINCT FROM new.height) OR (old.duration_ms IS DISTINCT FROM new.duration_ms) OR (old.source_attachment_id IS DISTINCT FROM new.source_attachment_id) OR (old.attachment_metadata IS DISTINCT FROM new.attachment_metadata) OR (old.attachment_role IS DISTINCT FROM new.attachment_role) OR (old.role_source IS DISTINCT FROM new.role_source) OR (old.source_part_key IS DISTINCT FROM new.source_part_key) OR (old.content_id IS DISTINCT FROM new.content_id) OR (old.encryption_version IS DISTINCT FROM new.encryption_version))) EXECUTE FUNCTION public.invalidate_visual_publication_attachment();


--
-- Name: visual_publications trg_visual_publication_delete_ledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_delete_ledger BEFORE DELETE ON public.visual_publications FOR EACH ROW EXECUTE FUNCTION public.ledger_visual_publication_tokens();


--
-- Name: message_bodies trg_visual_publication_message_body_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_message_body_delete AFTER DELETE ON public.message_bodies FOR EACH ROW EXECUTE FUNCTION public.invalidate_visual_publication_message_body();


--
-- Name: message_bodies trg_visual_publication_message_body_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_message_body_insert AFTER INSERT ON public.message_bodies FOR EACH ROW EXECUTE FUNCTION public.invalidate_visual_publication_message_body();


--
-- Name: message_bodies trg_visual_publication_message_body_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_message_body_update AFTER UPDATE OF body_text, body_html ON public.message_bodies FOR EACH ROW WHEN (((old.body_text IS DISTINCT FROM new.body_text) OR (old.body_html IS DISTINCT FROM new.body_html))) EXECUTE FUNCTION public.invalidate_visual_publication_message_body();


--
-- Name: messages trg_visual_publication_message_content_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_message_content_change AFTER UPDATE OF subject, message_type ON public.messages FOR EACH ROW WHEN (((old.subject IS DISTINCT FROM new.subject) OR (old.message_type IS DISTINCT FROM new.message_type))) EXECUTE FUNCTION public.invalidate_visual_publication_message_content();


--
-- Name: messages trg_visual_publication_message_live_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_message_live_change AFTER UPDATE OF deleted_at, deleted_from_source_at ON public.messages FOR EACH ROW WHEN ((((old.deleted_at IS NULL) AND (old.deleted_from_source_at IS NULL)) IS DISTINCT FROM ((new.deleted_at IS NULL) AND (new.deleted_from_source_at IS NULL)))) EXECUTE FUNCTION public.invalidate_visual_publication_message_live();


--
-- Name: messages trg_visual_publication_message_type_scope; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_visual_publication_message_type_scope AFTER UPDATE OF message_type ON public.messages FOR EACH ROW WHEN ((old.message_type IS DISTINCT FROM new.message_type)) EXECUTE FUNCTION public.seed_visual_publication_scope_entry();


--
-- Name: account_identities account_identities_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_identities
    ADD CONSTRAINT account_identities_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: activity_event_persons activity_event_persons_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_event_persons
    ADD CONSTRAINT activity_event_persons_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.activity_events(message_id) ON DELETE CASCADE;


--
-- Name: activity_event_persons activity_event_persons_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_event_persons
    ADD CONSTRAINT activity_event_persons_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: activity_events activity_events_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_events
    ADD CONSTRAINT activity_events_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: activity_events activity_events_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_events
    ADD CONSTRAINT activity_events_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: activity_events activity_events_owner_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_events
    ADD CONSTRAINT activity_events_owner_source_id_fkey FOREIGN KEY (owner_source_id) REFERENCES public.sources(id) ON DELETE SET NULL;


--
-- Name: activity_events activity_events_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_events
    ADD CONSTRAINT activity_events_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: activity_projection_queue activity_projection_queue_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_projection_queue
    ADD CONSTRAINT activity_projection_queue_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attachments attachments_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: beeper_drafts beeper_drafts_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.beeper_drafts
    ADD CONSTRAINT beeper_drafts_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: carddav_account_home_urls carddav_account_home_urls_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_account_home_urls
    ADD CONSTRAINT carddav_account_home_urls_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.carddav_accounts(id) ON DELETE CASCADE;


--
-- Name: carddav_address_book_urls carddav_address_book_urls_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_address_book_urls
    ADD CONSTRAINT carddav_address_book_urls_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.carddav_accounts(id) ON DELETE CASCADE;


--
-- Name: carddav_address_book_urls carddav_address_book_urls_address_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_address_book_urls
    ADD CONSTRAINT carddav_address_book_urls_address_book_id_fkey FOREIGN KEY (address_book_id) REFERENCES public.carddav_address_books(id) ON DELETE CASCADE;


--
-- Name: carddav_address_books carddav_address_books_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_address_books
    ADD CONSTRAINT carddav_address_books_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.carddav_accounts(id) ON DELETE CASCADE;


--
-- Name: carddav_conflicts carddav_conflicts_address_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_conflicts
    ADD CONSTRAINT carddav_conflicts_address_book_id_fkey FOREIGN KEY (address_book_id) REFERENCES public.carddav_address_books(id) ON DELETE CASCADE;


--
-- Name: carddav_publications carddav_publications_address_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_publications
    ADD CONSTRAINT carddav_publications_address_book_id_fkey FOREIGN KEY (address_book_id) REFERENCES public.carddav_address_books(id) ON DELETE CASCADE;


--
-- Name: carddav_publications carddav_publications_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_publications
    ADD CONSTRAINT carddav_publications_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE RESTRICT;


--
-- Name: carddav_resources carddav_resources_address_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_resources
    ADD CONSTRAINT carddav_resources_address_book_id_fkey FOREIGN KEY (address_book_id) REFERENCES public.carddav_address_books(id) ON DELETE CASCADE;


--
-- Name: carddav_resources carddav_resources_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_resources
    ADD CONSTRAINT carddav_resources_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE SET NULL;


--
-- Name: carddav_retry_gate carddav_retry_gate_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carddav_retry_gate
    ADD CONSTRAINT carddav_retry_gate_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.carddav_accounts(id) ON DELETE CASCADE;


--
-- Name: chat_drafts chat_drafts_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_drafts
    ADD CONSTRAINT chat_drafts_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: chat_drafts chat_drafts_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_drafts
    ADD CONSTRAINT chat_drafts_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: collection_sources collection_sources_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_sources
    ADD CONSTRAINT collection_sources_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES public.collections(id) ON DELETE CASCADE;


--
-- Name: collection_sources collection_sources_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_sources
    ADD CONSTRAINT collection_sources_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: communication_service_aliases communication_service_aliases_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_service_aliases
    ADD CONSTRAINT communication_service_aliases_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.communication_services(id) ON DELETE CASCADE;


--
-- Name: communication_service_discoveries communication_service_discoveries_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_service_discoveries
    ADD CONSTRAINT communication_service_discoveries_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.communication_services(id) ON DELETE CASCADE;


--
-- Name: conversation_participants conversation_participants_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: conversation_participants conversation_participants_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: daily_note_entry_persons daily_note_entry_persons_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_note_entry_persons
    ADD CONSTRAINT daily_note_entry_persons_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.daily_note_entries(id) ON DELETE CASCADE;


--
-- Name: daily_note_entry_persons daily_note_entry_persons_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_note_entry_persons
    ADD CONSTRAINT daily_note_entry_persons_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: document_chunk_spans document_chunk_spans_extraction_id_chunk_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunk_spans
    ADD CONSTRAINT document_chunk_spans_extraction_id_chunk_key_fkey FOREIGN KEY (extraction_id, chunk_key) REFERENCES public.document_chunks(extraction_id, chunk_key) ON DELETE CASCADE;


--
-- Name: document_chunk_spans document_chunk_spans_extraction_id_unit_index_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunk_spans
    ADD CONSTRAINT document_chunk_spans_extraction_id_unit_index_fkey FOREIGN KEY (extraction_id, unit_index) REFERENCES public.document_units(extraction_id, unit_index) ON DELETE CASCADE;


--
-- Name: document_chunks document_chunks_extraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_extraction_id_fkey FOREIGN KEY (extraction_id) REFERENCES public.document_extractions(id) ON DELETE CASCADE;


--
-- Name: document_extraction_claims document_extraction_claims_extraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_claims
    ADD CONSTRAINT document_extraction_claims_extraction_id_fkey FOREIGN KEY (extraction_id) REFERENCES public.document_extractions(id) ON DELETE CASCADE;


--
-- Name: document_extraction_claims document_extraction_claims_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_claims
    ADD CONSTRAINT document_extraction_claims_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.document_extraction_profiles(id) ON DELETE CASCADE;


--
-- Name: document_extraction_conversions document_extraction_conversions_extraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_conversions
    ADD CONSTRAINT document_extraction_conversions_extraction_id_fkey FOREIGN KEY (extraction_id) REFERENCES public.document_extractions(id) ON DELETE CASCADE;


--
-- Name: document_extraction_heads document_extraction_heads_extraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_heads
    ADD CONSTRAINT document_extraction_heads_extraction_id_fkey FOREIGN KEY (extraction_id) REFERENCES public.document_extractions(id) ON DELETE CASCADE;


--
-- Name: document_extraction_heads document_extraction_heads_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_heads
    ADD CONSTRAINT document_extraction_heads_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.document_extraction_profiles(id) ON DELETE CASCADE;


--
-- Name: document_extraction_rebuild_targets document_extraction_rebuild_targets_rebuild_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_rebuild_targets
    ADD CONSTRAINT document_extraction_rebuild_targets_rebuild_id_fkey FOREIGN KEY (rebuild_id) REFERENCES public.document_extraction_rebuilds(id) ON DELETE CASCADE;


--
-- Name: document_extraction_rebuilds document_extraction_rebuilds_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extraction_rebuilds
    ADD CONSTRAINT document_extraction_rebuilds_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.document_extraction_profiles(id) ON DELETE CASCADE;


--
-- Name: document_extractions document_extractions_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extractions
    ADD CONSTRAINT document_extractions_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.document_extraction_profiles(id) ON DELETE CASCADE;


--
-- Name: document_extractions document_extractions_rebuild_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_extractions
    ADD CONSTRAINT document_extractions_rebuild_id_fkey FOREIGN KEY (rebuild_id) REFERENCES public.document_extraction_rebuilds(id) ON DELETE SET NULL;


--
-- Name: document_occurrences document_occurrences_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_occurrences
    ADD CONSTRAINT document_occurrences_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES public.attachments(id) ON DELETE CASCADE;


--
-- Name: document_occurrences document_occurrences_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_occurrences
    ADD CONSTRAINT document_occurrences_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: document_occurrences document_occurrences_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_occurrences
    ADD CONSTRAINT document_occurrences_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: document_provider_consents document_provider_consents_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_provider_consents
    ADD CONSTRAINT document_provider_consents_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.document_extraction_profiles(id) ON DELETE CASCADE;


--
-- Name: document_units document_units_extraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_units
    ADD CONSTRAINT document_units_extraction_id_fkey FOREIGN KEY (extraction_id) REFERENCES public.document_extractions(id) ON DELETE CASCADE;


--
-- Name: document_vector_build_progress document_vector_build_progress_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_build_progress
    ADD CONSTRAINT document_vector_build_progress_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.document_vector_generations(id) ON DELETE CASCADE;


--
-- Name: document_vector_consents document_vector_consents_target_extraction_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_consents
    ADD CONSTRAINT document_vector_consents_target_extraction_profile_id_fkey FOREIGN KEY (target_extraction_profile_id) REFERENCES public.document_extraction_profiles(id) ON DELETE RESTRICT;


--
-- Name: document_vector_generations document_vector_generations_target_extraction_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_generations
    ADD CONSTRAINT document_vector_generations_target_extraction_profile_id_fkey FOREIGN KEY (target_extraction_profile_id) REFERENCES public.document_extraction_profiles(id) ON DELETE RESTRICT;


--
-- Name: document_vector_publications document_vector_publications_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_vector_publications
    ADD CONSTRAINT document_vector_publications_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.document_vector_generations(id) ON DELETE RESTRICT;


--
-- Name: employments employments_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employments
    ADD CONSTRAINT employments_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.organization_addresses(id) ON DELETE SET NULL;


--
-- Name: employments employments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employments
    ADD CONSTRAINT employments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE RESTRICT;


--
-- Name: employments employments_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employments
    ADD CONSTRAINT employments_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: gmail_drafts gmail_drafts_current_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gmail_drafts
    ADD CONSTRAINT gmail_drafts_current_message_id_fkey FOREIGN KEY (current_message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: gmail_drafts gmail_drafts_pending_original_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gmail_drafts
    ADD CONSTRAINT gmail_drafts_pending_original_message_id_fkey FOREIGN KEY (pending_original_message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: gmail_drafts gmail_drafts_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gmail_drafts
    ADD CONSTRAINT gmail_drafts_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: identity_match_candidate_redirects identity_match_candidate_redirects_surviving_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_candidate_redirects
    ADD CONSTRAINT identity_match_candidate_redirects_surviving_candidate_id_fkey FOREIGN KEY (surviving_candidate_id) REFERENCES public.identity_match_candidates(id) ON DELETE CASCADE;


--
-- Name: identity_match_candidate_sources identity_match_candidate_sources_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_candidate_sources
    ADD CONSTRAINT identity_match_candidate_sources_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.identity_match_candidates(id) ON DELETE CASCADE;


--
-- Name: identity_match_candidate_sources identity_match_candidate_sources_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_candidate_sources
    ADD CONSTRAINT identity_match_candidate_sources_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: identity_match_candidates identity_match_candidates_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_candidates
    ADD CONSTRAINT identity_match_candidates_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.communication_services(id) ON DELETE SET NULL;


--
-- Name: identity_match_evidence identity_match_evidence_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_evidence
    ADD CONSTRAINT identity_match_evidence_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.identity_match_candidates(id) ON DELETE CASCADE;


--
-- Name: identity_match_evidence_sources identity_match_evidence_sources_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_evidence_sources
    ADD CONSTRAINT identity_match_evidence_sources_evidence_id_fkey FOREIGN KEY (evidence_id) REFERENCES public.identity_match_evidence(id) ON DELETE CASCADE;


--
-- Name: identity_match_evidence_sources identity_match_evidence_sources_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_evidence_sources
    ADD CONSTRAINT identity_match_evidence_sources_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: identity_match_review_decisions identity_match_review_decisions_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_review_decisions
    ADD CONSTRAINT identity_match_review_decisions_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.identity_match_candidates(id) ON DELETE CASCADE;


--
-- Name: identity_match_review_receipts identity_match_review_receipts_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.identity_match_review_receipts
    ADD CONSTRAINT identity_match_review_receipts_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.identity_match_candidates(id) ON DELETE CASCADE;


--
-- Name: imap_drafts imap_drafts_current_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_drafts
    ADD CONSTRAINT imap_drafts_current_message_id_fkey FOREIGN KEY (current_message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: imap_drafts imap_drafts_pending_original_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_drafts
    ADD CONSTRAINT imap_drafts_pending_original_message_id_fkey FOREIGN KEY (pending_original_message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: imap_drafts imap_drafts_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_drafts
    ADD CONSTRAINT imap_drafts_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: imap_folder_state imap_folder_state_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_folder_state
    ADD CONSTRAINT imap_folder_state_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: imap_message_memberships imap_message_memberships_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_message_memberships
    ADD CONSTRAINT imap_message_memberships_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: imap_message_memberships imap_message_memberships_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imap_message_memberships
    ADD CONSTRAINT imap_message_memberships_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: labels labels_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: mcp_event_message_refs mcp_event_message_refs_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_event_message_refs
    ADD CONSTRAINT mcp_event_message_refs_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: meeting_action_items meeting_action_items_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_action_items
    ADD CONSTRAINT meeting_action_items_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: meeting_details meeting_details_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_details
    ADD CONSTRAINT meeting_details_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_bodies message_bodies_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_bodies
    ADD CONSTRAINT message_bodies_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_labels message_labels_label_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_labels
    ADD CONSTRAINT message_labels_label_id_fkey FOREIGN KEY (label_id) REFERENCES public.labels(id) ON DELETE CASCADE;


--
-- Name: message_labels message_labels_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_labels
    ADD CONSTRAINT message_labels_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_raw message_raw_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_raw
    ADD CONSTRAINT message_raw_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_recipients message_recipients_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_recipients
    ADD CONSTRAINT message_recipients_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_recipients message_recipients_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_recipients
    ADD CONSTRAINT message_recipients_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id) ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: messages messages_reply_to_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_reply_to_message_id_fkey FOREIGN KEY (reply_to_message_id) REFERENCES public.messages(id);


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.participants(id);


--
-- Name: messages messages_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: organization_addresses organization_addresses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_addresses
    ADD CONSTRAINT organization_addresses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_attribute_values organization_attribute_values_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_attribute_values
    ADD CONSTRAINT organization_attribute_values_definition_id_fkey FOREIGN KEY (definition_id) REFERENCES public.attribute_definitions(id) ON DELETE RESTRICT;


--
-- Name: organization_attribute_values organization_attribute_values_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_attribute_values
    ADD CONSTRAINT organization_attribute_values_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_categories organization_categories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_categories
    ADD CONSTRAINT organization_categories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_contact_points organization_contact_points_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_contact_points
    ADD CONSTRAINT organization_contact_points_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_contact_points organization_contact_points_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_contact_points
    ADD CONSTRAINT organization_contact_points_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.communication_services(id) ON DELETE RESTRICT;


--
-- Name: organization_identifiers organization_identifiers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_identifiers
    ADD CONSTRAINT organization_identifiers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_media organization_media_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_media
    ADD CONSTRAINT organization_media_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_names organization_names_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization_names
    ADD CONSTRAINT organization_names_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organizations organizations_merged_into_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_merged_into_id_fkey FOREIGN KEY (merged_into_id) REFERENCES public.organizations(id) ON DELETE RESTRICT;


--
-- Name: participant_contact_observations participant_contact_observations_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_contact_observations
    ADD CONSTRAINT participant_contact_observations_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id) ON DELETE CASCADE;


--
-- Name: participant_contact_observations participant_contact_observations_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_contact_observations
    ADD CONSTRAINT participant_contact_observations_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.communication_services(id) ON DELETE SET NULL;


--
-- Name: participant_contact_observations participant_contact_observations_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_contact_observations
    ADD CONSTRAINT participant_contact_observations_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: participant_identifiers participant_identifiers_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_identifiers
    ADD CONSTRAINT participant_identifiers_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id) ON DELETE CASCADE;


--
-- Name: participant_identifiers participant_identifiers_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_identifiers
    ADD CONSTRAINT participant_identifiers_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.communication_services(id) ON DELETE SET NULL;


--
-- Name: participant_links participant_links_participant_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_links
    ADD CONSTRAINT participant_links_participant_a_fkey FOREIGN KEY (participant_a) REFERENCES public.participants(id) ON DELETE CASCADE;


--
-- Name: participant_links participant_links_participant_b_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.participant_links
    ADD CONSTRAINT participant_links_participant_b_fkey FOREIGN KEY (participant_b) REFERENCES public.participants(id) ON DELETE CASCADE;


--
-- Name: person_addresses person_addresses_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_addresses
    ADD CONSTRAINT person_addresses_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_attribute_values person_attribute_values_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_attribute_values
    ADD CONSTRAINT person_attribute_values_definition_id_fkey FOREIGN KEY (definition_id) REFERENCES public.attribute_definitions(id) ON DELETE RESTRICT;


--
-- Name: person_attribute_values person_attribute_values_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_attribute_values
    ADD CONSTRAINT person_attribute_values_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_brief_enrollments person_brief_enrollments_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_brief_enrollments
    ADD CONSTRAINT person_brief_enrollments_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_brief_evidence person_brief_evidence_brief_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_brief_evidence
    ADD CONSTRAINT person_brief_evidence_brief_id_fkey FOREIGN KEY (brief_id) REFERENCES public.person_briefs(id) ON DELETE CASCADE;


--
-- Name: person_brief_evidence person_brief_evidence_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_brief_evidence
    ADD CONSTRAINT person_brief_evidence_evidence_id_fkey FOREIGN KEY (evidence_id) REFERENCES public.person_fact_evidence(id) ON DELETE CASCADE;


--
-- Name: person_briefs person_briefs_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_briefs
    ADD CONSTRAINT person_briefs_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.person_fact_generations(id) ON DELETE CASCADE;


--
-- Name: person_briefs person_briefs_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_briefs
    ADD CONSTRAINT person_briefs_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_carddav_inference_state person_carddav_inference_state_approved_address_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_carddav_inference_state
    ADD CONSTRAINT person_carddav_inference_state_approved_address_book_id_fkey FOREIGN KEY (approved_address_book_id) REFERENCES public.carddav_address_books(id) ON DELETE SET NULL;


--
-- Name: person_carddav_inference_state person_carddav_inference_state_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_carddav_inference_state
    ADD CONSTRAINT person_carddav_inference_state_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_categories person_categories_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_categories
    ADD CONSTRAINT person_categories_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_contact_points person_contact_points_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_contact_points
    ADD CONSTRAINT person_contact_points_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_contact_points person_contact_points_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_contact_points
    ADD CONSTRAINT person_contact_points_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.communication_services(id) ON DELETE RESTRICT;


--
-- Name: person_contact_state person_contact_state_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_contact_state
    ADD CONSTRAINT person_contact_state_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_dates person_dates_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_dates
    ADD CONSTRAINT person_dates_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_attempt_citations person_enrichment_attempt_citations_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempt_citations
    ADD CONSTRAINT person_enrichment_attempt_citations_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.person_enrichment_attempts(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_attempt_citations person_enrichment_attempt_citations_citation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempt_citations
    ADD CONSTRAINT person_enrichment_attempt_citations_citation_id_fkey FOREIGN KEY (citation_id) REFERENCES public.person_enrichment_citations(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_attempt_identifiers person_enrichment_attempt_identifiers_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempt_identifiers
    ADD CONSTRAINT person_enrichment_attempt_identifiers_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.person_enrichment_attempts(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_attempt_sources person_enrichment_attempt_sources_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempt_sources
    ADD CONSTRAINT person_enrichment_attempt_sources_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.person_enrichment_attempts(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_attempts person_enrichment_attempts_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempts
    ADD CONSTRAINT person_enrichment_attempts_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_attempts person_enrichment_attempts_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempts
    ADD CONSTRAINT person_enrichment_attempts_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_enrichment_profiles(fingerprint);


--
-- Name: person_enrichment_attempts person_enrichment_attempts_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_attempts
    ADD CONSTRAINT person_enrichment_attempts_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.person_enrichment_runs(id) ON DELETE RESTRICT;


--
-- Name: person_enrichment_citations person_enrichment_citations_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_citations
    ADD CONSTRAINT person_enrichment_citations_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_consents person_enrichment_consents_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_consents
    ADD CONSTRAINT person_enrichment_consents_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_enrichment_profiles(fingerprint);


--
-- Name: person_enrichment_day_counters person_enrichment_day_counters_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_day_counters
    ADD CONSTRAINT person_enrichment_day_counters_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_enrichment_profiles(fingerprint);


--
-- Name: person_enrichment_manual_run_targets person_enrichment_manual_run_targets_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_manual_run_targets
    ADD CONSTRAINT person_enrichment_manual_run_targets_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_enrichment_profiles(fingerprint);


--
-- Name: person_enrichment_manual_run_targets person_enrichment_manual_run_targets_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_manual_run_targets
    ADD CONSTRAINT person_enrichment_manual_run_targets_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.person_enrichment_runs(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_person_day_counters person_enrichment_person_day_counters_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_person_day_counters
    ADD CONSTRAINT person_enrichment_person_day_counters_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_person_day_counters person_enrichment_person_day_counters_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_person_day_counters
    ADD CONSTRAINT person_enrichment_person_day_counters_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_enrichment_profiles(fingerprint);


--
-- Name: person_enrichment_profile_accounting person_enrichment_profile_accounting_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_profile_accounting
    ADD CONSTRAINT person_enrichment_profile_accounting_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_enrichment_profiles(fingerprint);


--
-- Name: person_enrichment_provider_identities person_enrichment_provider_identities_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_provider_identities
    ADD CONSTRAINT person_enrichment_provider_identities_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_run_counters person_enrichment_run_counters_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_run_counters
    ADD CONSTRAINT person_enrichment_run_counters_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.person_enrichment_runs(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_work person_enrichment_work_active_attempt_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_work
    ADD CONSTRAINT person_enrichment_work_active_attempt_fk FOREIGN KEY (active_attempt_id) REFERENCES public.person_enrichment_attempts(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: person_enrichment_work person_enrichment_work_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_work
    ADD CONSTRAINT person_enrichment_work_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_enrichment_work person_enrichment_work_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_work
    ADD CONSTRAINT person_enrichment_work_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_enrichment_profiles(fingerprint);


--
-- Name: person_enrichment_work person_enrichment_work_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_enrichment_work
    ADD CONSTRAINT person_enrichment_work_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.person_enrichment_runs(id) ON DELETE RESTRICT;


--
-- Name: person_fact_claim_evidence person_fact_claim_evidence_claim_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_claim_evidence
    ADD CONSTRAINT person_fact_claim_evidence_claim_id_fkey FOREIGN KEY (claim_id) REFERENCES public.person_fact_claims(id) ON DELETE CASCADE;


--
-- Name: person_fact_claim_evidence person_fact_claim_evidence_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_claim_evidence
    ADD CONSTRAINT person_fact_claim_evidence_evidence_id_fkey FOREIGN KEY (evidence_id) REFERENCES public.person_fact_evidence(id) ON DELETE CASCADE;


--
-- Name: person_fact_claims person_fact_claims_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_claims
    ADD CONSTRAINT person_fact_claims_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.person_fact_generations(id) ON DELETE CASCADE;


--
-- Name: person_fact_claims person_fact_claims_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_claims
    ADD CONSTRAINT person_fact_claims_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_fact_decisions person_fact_decisions_claim_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_decisions
    ADD CONSTRAINT person_fact_decisions_claim_id_fkey FOREIGN KEY (claim_id) REFERENCES public.person_fact_claims(id) ON DELETE CASCADE;


--
-- Name: person_fact_decisions person_fact_decisions_competing_claim_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_decisions
    ADD CONSTRAINT person_fact_decisions_competing_claim_id_fkey FOREIGN KEY (competing_claim_id) REFERENCES public.person_fact_claims(id) ON DELETE SET NULL;


--
-- Name: person_fact_decisions person_fact_decisions_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_decisions
    ADD CONSTRAINT person_fact_decisions_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_fact_decisions person_fact_decisions_resolution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_decisions
    ADD CONSTRAINT person_fact_decisions_resolution_id_fkey FOREIGN KEY (resolution_id) REFERENCES public.person_fact_resolutions(id) ON DELETE CASCADE;


--
-- Name: person_fact_evidence person_fact_evidence_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_evidence
    ADD CONSTRAINT person_fact_evidence_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_fact_evidence_status_events person_fact_evidence_status_events_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_evidence_status_events
    ADD CONSTRAINT person_fact_evidence_status_events_evidence_id_fkey FOREIGN KEY (evidence_id) REFERENCES public.person_fact_evidence(id) ON DELETE CASCADE;


--
-- Name: person_fact_evidence_status_events person_fact_evidence_status_events_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_evidence_status_events
    ADD CONSTRAINT person_fact_evidence_status_events_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.person_fact_generations(id) ON DELETE CASCADE;


--
-- Name: person_fact_evidence_status_events person_fact_evidence_status_events_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_evidence_status_events
    ADD CONSTRAINT person_fact_evidence_status_events_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_fact_generations person_fact_generations_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_generations
    ADD CONSTRAINT person_fact_generations_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_fact_pin_events person_fact_pin_events_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_pin_events
    ADD CONSTRAINT person_fact_pin_events_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_fact_resolutions person_fact_resolutions_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_resolutions
    ADD CONSTRAINT person_fact_resolutions_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.person_fact_generations(id) ON DELETE CASCADE;


--
-- Name: person_fact_resolutions person_fact_resolutions_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_fact_resolutions
    ADD CONSTRAINT person_fact_resolutions_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_inference_checks person_inference_checks_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_inference_checks
    ADD CONSTRAINT person_inference_checks_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_inference_profiles(fingerprint);


--
-- Name: person_inference_consents person_inference_consents_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_inference_consents
    ADD CONSTRAINT person_inference_consents_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_inference_profiles(fingerprint);


--
-- Name: person_match_judgment_work person_match_judgment_work_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_match_judgment_work
    ADD CONSTRAINT person_match_judgment_work_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.identity_match_candidates(id) ON DELETE CASCADE;


--
-- Name: person_media person_media_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_media
    ADD CONSTRAINT person_media_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_merge_participants person_merge_participants_merge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_participants
    ADD CONSTRAINT person_merge_participants_merge_id_fkey FOREIGN KEY (merge_id) REFERENCES public.person_merges(id) ON DELETE CASCADE;


--
-- Name: person_merge_participants person_merge_participants_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_participants
    ADD CONSTRAINT person_merge_participants_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id) ON DELETE RESTRICT;


--
-- Name: person_merge_participants person_merge_participants_split_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_participants
    ADD CONSTRAINT person_merge_participants_split_id_fkey FOREIGN KEY (split_id) REFERENCES public.person_splits(id) ON DELETE RESTRICT;


--
-- Name: person_merge_review_candidates person_merge_review_candidates_absorbed_value_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_review_candidates
    ADD CONSTRAINT person_merge_review_candidates_absorbed_value_id_fkey FOREIGN KEY (absorbed_value_id) REFERENCES public.person_attribute_values(id) ON DELETE RESTRICT;


--
-- Name: person_merge_review_candidates person_merge_review_candidates_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_review_candidates
    ADD CONSTRAINT person_merge_review_candidates_definition_id_fkey FOREIGN KEY (definition_id) REFERENCES public.attribute_definitions(id) ON DELETE RESTRICT;


--
-- Name: person_merge_review_candidates person_merge_review_candidates_merge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_review_candidates
    ADD CONSTRAINT person_merge_review_candidates_merge_id_fkey FOREIGN KEY (merge_id) REFERENCES public.person_merges(id) ON DELETE CASCADE;


--
-- Name: person_merge_review_candidates person_merge_review_candidates_resolution_value_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_review_candidates
    ADD CONSTRAINT person_merge_review_candidates_resolution_value_id_fkey FOREIGN KEY (resolution_value_id) REFERENCES public.person_attribute_values(id) ON DELETE RESTRICT;


--
-- Name: person_merge_review_candidates person_merge_review_candidates_survivor_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_review_candidates
    ADD CONSTRAINT person_merge_review_candidates_survivor_person_id_fkey FOREIGN KEY (survivor_person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_merge_review_candidates person_merge_review_candidates_survivor_value_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_review_candidates
    ADD CONSTRAINT person_merge_review_candidates_survivor_value_id_fkey FOREIGN KEY (survivor_value_id) REFERENCES public.person_attribute_values(id) ON DELETE RESTRICT;


--
-- Name: person_merge_row_person_refs person_merge_row_person_refs_merge_id_table_name_original__fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_row_person_refs
    ADD CONSTRAINT person_merge_row_person_refs_merge_id_table_name_original__fkey FOREIGN KEY (merge_id, table_name, original_row_key) REFERENCES public.person_merge_rows(merge_id, table_name, original_row_key) ON DELETE CASCADE;


--
-- Name: person_merge_rows person_merge_rows_merge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_rows
    ADD CONSTRAINT person_merge_rows_merge_id_fkey FOREIGN KEY (merge_id) REFERENCES public.person_merges(id) ON DELETE CASCADE;


--
-- Name: person_merge_rows person_merge_rows_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_rows
    ADD CONSTRAINT person_merge_rows_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id) ON DELETE RESTRICT;


--
-- Name: person_merge_rows person_merge_rows_split_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merge_rows
    ADD CONSTRAINT person_merge_rows_split_id_fkey FOREIGN KEY (split_id) REFERENCES public.person_splits(id) ON DELETE RESTRICT;


--
-- Name: person_merges person_merges_current_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_merges
    ADD CONSTRAINT person_merges_current_person_id_fkey FOREIGN KEY (current_person_id) REFERENCES public.persons(id) ON DELETE SET NULL;


--
-- Name: person_names person_names_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_names
    ADD CONSTRAINT person_names_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_participants person_participants_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_participants
    ADD CONSTRAINT person_participants_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id) ON DELETE CASCADE;


--
-- Name: person_participants person_participants_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_participants
    ADD CONSTRAINT person_participants_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_relationship_reviews person_relationship_reviews_accepted_relationship_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_relationship_reviews
    ADD CONSTRAINT person_relationship_reviews_accepted_relationship_id_fkey FOREIGN KEY (accepted_relationship_id) REFERENCES public.person_relationships(id) ON DELETE SET NULL;


--
-- Name: person_relationship_reviews person_relationship_reviews_matched_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_relationship_reviews
    ADD CONSTRAINT person_relationship_reviews_matched_person_id_fkey FOREIGN KEY (matched_person_id) REFERENCES public.persons(id) ON DELETE SET NULL;


--
-- Name: person_relationship_reviews person_relationship_reviews_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_relationship_reviews
    ADD CONSTRAINT person_relationship_reviews_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_relationships person_relationships_relationship_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_relationships
    ADD CONSTRAINT person_relationships_relationship_type_id_fkey FOREIGN KEY (relationship_type_id) REFERENCES public.relationship_types(id);


--
-- Name: person_relationships person_relationships_source_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_relationships
    ADD CONSTRAINT person_relationships_source_person_id_fkey FOREIGN KEY (source_person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_relationships person_relationships_target_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_relationships
    ADD CONSTRAINT person_relationships_target_person_id_fkey FOREIGN KEY (target_person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_semantic_embedding_consents person_semantic_embedding_consents_profile_fingerprint_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_semantic_embedding_consents
    ADD CONSTRAINT person_semantic_embedding_consents_profile_fingerprint_fkey FOREIGN KEY (profile_fingerprint) REFERENCES public.person_semantic_embedding_profiles(fingerprint);


--
-- Name: person_splits person_splits_merge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_splits
    ADD CONSTRAINT person_splits_merge_id_fkey FOREIGN KEY (merge_id) REFERENCES public.person_merges(id) ON DELETE CASCADE;


--
-- Name: person_sweep_attempts person_sweep_attempts_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_attempts
    ADD CONSTRAINT person_sweep_attempts_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.person_fact_generations(id) ON DELETE SET NULL;


--
-- Name: person_sweep_attempts person_sweep_attempts_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_attempts
    ADD CONSTRAINT person_sweep_attempts_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_sweep_attempts person_sweep_attempts_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_attempts
    ADD CONSTRAINT person_sweep_attempts_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.person_sweep_runs(id) ON DELETE CASCADE;


--
-- Name: person_sweep_batches person_sweep_batches_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_batches
    ADD CONSTRAINT person_sweep_batches_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.person_sweep_attempts(id) ON DELETE CASCADE;


--
-- Name: person_sweep_changes person_sweep_changes_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_changes
    ADD CONSTRAINT person_sweep_changes_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_sweep_cursors person_sweep_cursors_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_cursors
    ADD CONSTRAINT person_sweep_cursors_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_sweep_sync_publications person_sweep_sync_publications_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_sync_publications
    ADD CONSTRAINT person_sweep_sync_publications_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: person_sweep_sync_publications person_sweep_sync_publications_sync_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_sync_publications
    ADD CONSTRAINT person_sweep_sync_publications_sync_run_id_fkey FOREIGN KEY (sync_run_id) REFERENCES public.sync_runs(id) ON DELETE CASCADE;


--
-- Name: person_sweep_work person_sweep_work_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_sweep_work
    ADD CONSTRAINT person_sweep_work_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_tracking person_tracking_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_tracking
    ADD CONSTRAINT person_tracking_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: person_uid_aliases person_uid_aliases_surviving_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_uid_aliases
    ADD CONSTRAINT person_uid_aliases_surviving_person_id_fkey FOREIGN KEY (surviving_person_id) REFERENCES public.persons(id) ON DELETE SET NULL;


--
-- Name: reaction_source_events reaction_source_events_reaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reaction_source_events
    ADD CONSTRAINT reaction_source_events_reaction_id_fkey FOREIGN KEY (reaction_id) REFERENCES public.reactions(id) ON DELETE CASCADE;


--
-- Name: reaction_source_events reaction_source_events_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reaction_source_events
    ADD CONSTRAINT reaction_source_events_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: reactions reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: reactions reactions_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participants(id) ON DELETE CASCADE;


--
-- Name: relationship_types relationship_types_inverse_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relationship_types
    ADD CONSTRAINT relationship_types_inverse_type_id_fkey FOREIGN KEY (inverse_type_id) REFERENCES public.relationship_types(id) ON DELETE SET NULL;


--
-- Name: source_import_items source_import_items_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.source_import_items
    ADD CONSTRAINT source_import_items_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: sync_checkpoints sync_checkpoints_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_checkpoints
    ADD CONSTRAINT sync_checkpoints_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: sync_operations sync_operations_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_operations
    ADD CONSTRAINT sync_operations_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: sync_run_items sync_run_items_sync_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_run_items
    ADD CONSTRAINT sync_run_items_sync_run_id_fkey FOREIGN KEY (sync_run_id) REFERENCES public.sync_runs(id) ON DELETE CASCADE;


--
-- Name: sync_runs sync_runs_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_runs
    ADD CONSTRAINT sync_runs_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.sources(id) ON DELETE CASCADE;


--
-- Name: vcard_resource_envelopes vcard_resource_envelopes_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vcard_resource_envelopes
    ADD CONSTRAINT vcard_resource_envelopes_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(id) ON DELETE CASCADE;


--
-- Name: visual_obsolete_tokens visual_obsolete_tokens_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_obsolete_tokens
    ADD CONSTRAINT visual_obsolete_tokens_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.visual_generations(id) ON DELETE CASCADE;


--
-- Name: visual_publications visual_publications_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_publications
    ADD CONSTRAINT visual_publications_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.visual_generations(id) ON DELETE CASCADE;


--
-- Name: visual_publications visual_publications_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_publications
    ADD CONSTRAINT visual_publications_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: visual_work_claims visual_work_claims_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_work_claims
    ADD CONSTRAINT visual_work_claims_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.visual_generations(id) ON DELETE CASCADE;


--
-- Name: visual_work_claims visual_work_claims_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visual_work_claims
    ADD CONSTRAINT visual_work_claims_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict v6ZvQ0YTNkdqcGFc8g0pARCkzXZqOnmcoFf373ctyjZLtdBBS0imJ6r94MiYasE

